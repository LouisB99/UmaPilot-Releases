"""Local encrypted device identity and verified Steam-to-game binding."""
import base64
import json
import uuid

from .account_profiles import GameAccountProfile, _now
from .gameless_login import new_device


class PilotCredentialsError(ValueError):
    """Safe, actionable account-setup error that can be shown in the dashboard."""


def pilot_target(store, profile_id):
    games = store.list_game_accounts(profile_id)
    if not games:
        raise PilotCredentialsError('Save the Pilot Trainer ID and Link Password in Accounts before connecting')
    if len(games) != 1:
        raise PilotCredentialsError('Keep one Pilot target under this Steam profile before connecting')
    game = games[0]
    try:
        credentials = store.load_data_link(game.id)
    except (OSError, ValueError):
        raise PilotCredentialsError('Save the Pilot Trainer ID and Link Password again on this Windows machine before connecting') from None
    if store._fingerprint(credentials['trainerId']) != game.trainer_id_fingerprint:
        raise PilotCredentialsError('Saved Data Link credentials do not match the Pilot target; save them again in Accounts')
    return game, credentials


def device_for(store, profile_id):
    profile_id = store._validate_id(profile_id)
    path = store.root / 'portable-devices' / (profile_id + '.bin')
    with store.lock:
        if path.exists():
            return json.loads(store.protector.unprotect(base64.b64decode(path.read_bytes(), validate=True)))
        device = new_device()
        store._atomic_write(path, base64.b64encode(store.protector.protect(json.dumps(device).encode())))
        return device


def bind_verified(store, profile_id, viewer_id, name):
    profile_id = store._validate_id(profile_id)
    fingerprint = store._fingerprint(str(viewer_id))
    with store.lock:
        games = store._read_games()
        existing = [g for g in games if g.steam_profile_id == profile_id and g.status == 'linked-verified']
        if existing:
            if len(existing) != 1 or existing[0].trainer_id_fingerprint != fingerprint:
                raise ValueError('Verified game account does not match this Steam profile')
            return existing[0]
        timestamp = _now()
        pending = next((g for g in games if g.steam_profile_id == profile_id
                        and g.trainer_id_fingerprint == fingerprint), None)
        if pending:
            # Verify the saved target in place: its ID owns the encrypted password.
            pending.status = 'linked-verified'
            pending.updated_at = timestamp
            pending.label = store._clean_label(name or pending.label)
            store._write_games(games)
            return pending
        game = GameAccountProfile(id=uuid.uuid4().hex, steam_profile_id=profile_id,
            label=store._clean_label(name or 'Steam game account'),
            trainer_id_hint='****' + str(viewer_id)[-4:], trainer_id_fingerprint=fingerprint,
            status='linked-verified', created_at=timestamp, updated_at=timestamp)
        games.append(game)
        store._write_games(games)
        return game


def save_auth(store, profile_id, viewer_id, auth_key):
    profile_id = store._validate_id(profile_id)
    with store.lock:
        device = device_for(store, profile_id)
        device.update(viewerId=int(viewer_id), authKey=auth_key)
        store._atomic_write(store.root / 'portable-devices' / (profile_id + '.bin'),
            base64.b64encode(store.protector.protect(json.dumps(device).encode())))
