"""Permit one future seed-build preference without replacing active run state."""
from copy import deepcopy


def seed_option_only(prior, current):
    if not isinstance(current, dict):
        return False
    plan = prior.get('loopPlan') or {}
    if plan.get('method') != 'pair-closure' or plan.get('pairSeedPending') or prior.get('status') == 'completed':
        return False
    value = (current.get('loopPlan') or {}).get('buildSeedParent')
    if not isinstance(value, bool):
        return False
    expected = deepcopy(prior)
    expected['loopPlan']['buildSeedParent'] = value
    return current == expected
