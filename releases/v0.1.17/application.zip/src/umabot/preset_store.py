"""Account-scoped, portable cache of preset names and IDs, never credentials."""
import hashlib
import json
from umabot.update_client import atomic_json


def cache_path(root, account_key):
    if not account_key:
        return None
    name = hashlib.sha256(str(account_key).encode()).hexdigest()
    return root / 'work' / 'account-presets' / (name + '.json')


def save(root, account_key, catalog):
    path = cache_path(root, account_key)
    if path:
        atomic_json(path, catalog)


def read(root, account_key):
    path = cache_path(root, account_key)
    try:
        result = json.loads(path.read_text(encoding='utf-8')) if path else None
        return result if isinstance(result, dict) else None
    except (OSError, ValueError):
        return None
