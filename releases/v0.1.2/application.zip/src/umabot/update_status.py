"""Dashboard-safe update status: never return paths, keys or raw installer errors."""
import json
from pathlib import Path
import subprocess
import sys
import threading
import time


_check_lock = threading.Lock()
_processes = {}
_last_started = {}


def request_check(root: Path, *, force=False):
    """Check in the background; tabs share a cooldown and the tray's OS lock."""
    from .update_client import atomic_json
    root = root.resolve()
    with _check_lock:
        process = _processes.get(root)
        if process is not None and process.poll() is None:
            return read_status(root)
        _processes.pop(root, None)
        status = read_status(root)
        if status['state'] == 'ready':
            return status
        if (root / '.git').exists():
            return {**status, 'state': 'development'}
        if not (root / 'updates/channel.json').is_file():
            return {**status, 'state': 'disabled'}
        now = time.monotonic()
        if not force and now - _last_started.get(root, float('-inf')) < 60:
            return status
        work = root / 'work/updates'
        work.mkdir(parents=True, exist_ok=True)
        _last_started[root] = now
        try:
            with (work / 'check.log').open('ab') as log:
                _processes[root] = subprocess.Popen(
                    [sys.executable, '-B', '-m', 'umabot.update_client', '--root', str(root)],
                    cwd=root, stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except OSError:
            atomic_json(work / 'status.json', {'state': 'error', 'checkedAt': time.time(),
                'message': 'The update check could not start.'})
            return read_status(root)
        return {**read_status(root), 'state': 'checking'}


def read_status(root: Path):
    def read(relative):
        try:
            value = json.loads((root / relative).read_text(encoding='utf-8-sig'))
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError):
            return {}
    installed = read('updates/installed.json')
    status = read('work/updates/status.json')
    pending = read('work/updates/pending.json')
    state = status.get('state', 'current')
    if (root / '.git').exists():
        state = 'development'
    if pending.get('sequence', 0) > installed.get('sequence', 0):
        state = 'ready'
    if state not in {'checking', 'downloading', 'verifying', 'ready', 'current', 'error', 'failed', 'development', 'disabled'}:
        state = 'current'
    try:
        percent = max(0, min(100, int(status.get('percent', 0))))
    except (ValueError, TypeError):
        percent = 0
    return {'installedVersion': str(installed.get('version') or 'Development'),
            'state': state, 'percent': percent}
