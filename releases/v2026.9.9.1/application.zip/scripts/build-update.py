"""Prepare signed, code-only delta releases; publishing is a separate deliberate step.

Keep work/update-publisher: it contains the DPAPI signing key and release history.
Never upload a personal portable ZIP. Only upload the three files in public/.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import re
import zipfile

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from umabot.account_profiles import WindowsDpapiProtector
from umabot.update_client import ROOT, managed, digest, atomic_json

PUBLISHER = ROOT / "work/update-publisher"
BASELINE = "portable-2026-09-09"
REPO = "LouisB99/UmaPilot-Releases"
DOWNLOAD = "https://github.com/" + REPO + "/releases/download/"


def sign(value, key):
    payload = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return json.dumps({"payload": base64.b64encode(payload).decode(), "signature": base64.b64encode(
        key.sign(payload, padding.PKCS1v15(), hashes.SHA256())).decode()}).encode()


def signing_key():
    protected = PUBLISHER / "signing-key.dpapi"
    return serialization.load_pem_private_key(WindowsDpapiProtector().unprotect(protected.read_bytes()), password=None)


def initialize(package):
    PUBLISHER.mkdir(parents=True, exist_ok=True)
    if (PUBLISHER / "inventory-0.json").exists():
        raise ValueError("Publisher is already initialized; keep its existing signing key and history")
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    protected = WindowsDpapiProtector().protect(key.private_bytes(serialization.Encoding.PEM,
        serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    (PUBLISHER / "signing-key.dpapi").write_bytes(protected)
    updates = ROOT / "updates"
    updates.mkdir(exist_ok=True)
    (updates / "public-key.pem").write_bytes(key.public_key().public_bytes(serialization.Encoding.PEM, serialization.PublicFormat.SubjectPublicKeyInfo))
    numbers = key.public_key().public_numbers()
    enc = lambda n: base64.b64encode(n.to_bytes((n.bit_length() + 7) // 8, "big")).decode()
    (updates / "public-key.xml").write_text("<RSAKeyValue><Modulus>" + enc(numbers.n) + "</Modulus><Exponent>" + enc(numbers.e) + "</Exponent></RSAKeyValue>")
    with zipfile.ZipFile(package) as source:
        manifest = json.loads(source.read("UmaPilot/PACKAGE-MANIFEST.json"))
    atomic_json(PUBLISHER / "inventory-0.json", {f["path"]: f["sha256"] for f in manifest["files"] if managed(f["path"])})
    atomic_json(updates / "channel.json", {"enabled": True, "feedUrl": "https://github.com/" + REPO + "/releases/latest/download/update.json"})
    atomic_json(updates / "installed.json", {"baseline": BASELINE, "sequence": 0, "version": "2026.09.09-portable"})
    atomic_json(PUBLISHER / "index.json", {"format": 1, "baseline": BASELINE, "releases": []})
    print("Update channel initialized. The signing key is encrypted locally and excluded from releases.")


def build(version, ui_dist, include_dependencies=False):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,60}", version):
        raise ValueError("Use a simple immutable release version")
    key = signing_key()
    index = json.loads((PUBLISHER / "index.json").read_text())
    sequence = len(index["releases"]) + 1
    previous = json.loads((PUBLISHER / f"inventory-{sequence - 1}.json").read_text())
    from importlib.util import spec_from_file_location, module_from_spec
    spec = spec_from_file_location("portable_package", ROOT / "scripts/package-portable.py")
    package = module_from_spec(spec); spec.loader.exec_module(package)
    files = {}
    dependencies = (".runtime/", "ui/node_modules/", "Converter/node_modules/")
    def walk_application(folder):
        if include_dependencies:
            yield from package.walk(folder)
            return
        for base, dirs, names in os.walk(folder):
            dirs[:] = [d for d in dirs if d not in package.IGNORED and d != "node_modules" and not Path(base, d).is_junction()]
            for name in names:
                path = Path(base, name)
                if path.is_symlink(): raise ValueError("Unexpected symbolic link")
                if managed(path.relative_to(ROOT).as_posix()): yield path
    folders = ["src", "scripts", "launcher", "resources", "assets", "vendor", "Converter", "ui/public"]
    if include_dependencies: folders.extend([".runtime", "ui/node_modules"])
    for folder in folders:
        for path in walk_application(ROOT / folder):
            relative = path.relative_to(ROOT).as_posix()
            if managed(relative):
                files[relative] = path
    for path in package.walk(ui_dist):
        relative = "ui/dist/" + path.relative_to(ui_dist).as_posix()
        if managed(relative):
            files[relative] = path
    from umabot.update_client import EXACT
    for relative in EXACT:
        if (ROOT / relative).is_file():
            files[relative] = ROOT / relative
    inventory = {name: value for name, value in previous.items() if not include_dependencies and name.startswith(dependencies)}
    for number, (name, path) in enumerate(files.items(), 1):
        inventory[name] = digest(path)
        if number % 500 == 0: print(f"Verified {number} application files", flush=True)
    if not include_dependencies:
        for name in ("ui/package.json", "Converter/package.json", "requirements-portable.txt"):
            if name in previous and previous[name] != inventory.get(name):
                raise ValueError("Dependency requirements changed; rebuild with --include-dependencies")
    changed = sorted(name for name in set(previous) | set(inventory) if previous.get(name) != inventory.get(name))
    if not changed:
        raise ValueError("No application changes to publish")
    folder = PUBLISHER / version
    if folder.exists():
        raise ValueError("Release version already prepared; choose a new version or inspect the existing draft")
    public = folder / "public"; public.mkdir(parents=True)
    archive = public / "application.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for name in changed:
            if name in files:
                output.write(files[name], name)
    entries = [{"path": name, "before": previous.get(name), "after": inventory.get(name),
                "size": files[name].stat().st_size if name in files else 0} for name in changed]
    release = {"format": 1, "baseline": BASELINE, "baseSequence": sequence - 1, "sequence": sequence,
               "version": version, "files": entries, "zipSha256": digest(archive), "zipSize": archive.stat().st_size,
               "zipUrl": DOWNLOAD + version + "/application.zip"}
    (public / "manifest.json").write_bytes(sign(release, key))
    index["releases"].append({"sequence": sequence, "version": version, "manifestUrl": DOWNLOAD + version + "/manifest.json"})
    (public / "update.json").write_bytes(sign(index, key))
    atomic_json(folder / "inventory.json", inventory)
    atomic_json(folder / "index.json", index)
    atomic_json(folder / "review.json", {"version": version, "sequence": sequence, "files": entries,
        "zipMiB": round(archive.stat().st_size / 1024**2, 2), "personalDataIncluded": False})
    # Only advance publisher history AFTER the release is publicly verified.
    print(json.dumps({"publicFiles": str(public), "sequence": sequence, "changedFiles": len(changed), "zipMiB": round(archive.stat().st_size / 1024**2, 2)}))


def accept(version):
    folder = PUBLISHER / version
    index = json.loads((folder / "index.json").read_text())
    sequence = index["releases"][-1]["sequence"]
    (PUBLISHER / f"inventory-{sequence}.json").write_bytes((folder / "inventory.json").read_bytes())
    (PUBLISHER / "index.json").write_bytes((folder / "index.json").read_bytes())
    print("Publisher history advanced to verified release " + version)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    init = commands.add_parser("init"); init.add_argument("--baseline-package", type=Path, required=True)
    prepare = commands.add_parser("build"); prepare.add_argument("--version", required=True); prepare.add_argument("--ui-dist", type=Path, default=ROOT / "ui/dist"); prepare.add_argument("--include-dependencies", action="store_true")
    commit = commands.add_parser("accept-published"); commit.add_argument("--version", required=True)
    args = parser.parse_args()
    if args.command == "init": initialize(args.baseline_package)
    elif args.command == "build": build(args.version, args.ui_dist, args.include_dependencies)
    else: accept(args.version)
