"""Offline post-install check. Never import service modules or start automation."""
import json
from pathlib import Path
import subprocess
import traceback

ROOT = Path(__file__).resolve().parents[1]


def verify():
    import cryptography
    import msgpack
    import numpy
    for path in (ROOT / "src").rglob("*.py"):
        compile(path.read_bytes(), str(path), "exec")
    for name in ("UmaPilot.exe", "UmaPilotUpdater.exe", "resources/master.mdb",
                 "ui/dist/server/BUILD_ID", "ui/node_modules/vinext/dist/cli.js",
                 "Converter/node_modules/steam-user/package.json", "scripts/start-official.ps1"):
        if not (ROOT / name).is_file():
            raise RuntimeError("Missing portable component: " + name)
    node = ROOT / ".runtime/node/node-v24.14.0-win-x64/node.exe"
    subprocess.run([str(node), "--version"], check=True, capture_output=True, timeout=15,
                   creationflags=subprocess.CREATE_NO_WINDOW)
    json.loads((ROOT / "ui/node_modules/vinext/package.json").read_text())


if __name__ == "__main__":
    log = ROOT / "work/updates/validation.log"
    log.parent.mkdir(parents=True, exist_ok=True)
    try:
        verify()
    except Exception:
        log.write_text(traceback.format_exc(), encoding="utf-8")
        raise SystemExit(1)
    log.write_text("Python code, bundled libraries, Node runtime and required application files passed.\n", encoding="utf-8")
