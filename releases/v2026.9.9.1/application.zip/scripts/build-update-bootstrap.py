"""Package a signed first release as a small, windowless one-time installer."""
import argparse
import os
from pathlib import Path
import subprocess
import zipfile
from umabot.update_client import ROOT, digest


def build(release: Path, output: Path):
    destination = release / "bootstrap-payload.zip"
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.write(release / "public/manifest.json", "manifest.json")
        for name in ("public-key.pem", "channel.json"):
            z.write(ROOT / "updates" / name, name)
        with zipfile.ZipFile(release / "public/application.zip") as source:
            for name in source.namelist():
                z.writestr("files/" + name, source.read(name))
    exe = release / "Enable-Automatic-Updates.exe"
    compiler = Path(os.environ["WINDIR"]) / "Microsoft.NET/Framework64/v4.0.30319/csc.exe"
    subprocess.run([str(compiler), "/nologo", "/target:winexe", "/platform:x64", "/optimize+",
        "/reference:System.Windows.Forms.dll", "/reference:System.Web.Extensions.dll", "/reference:System.IO.Compression.dll",
        f"/resource:{ROOT / 'updates/public-key.xml'},UpdatePublicKey", f"/resource:{destination},BootstrapPayload",
        f"/win32icon:{ROOT / 'launcher/UmaPilot.ico'}", f"/win32manifest:{ROOT / 'launcher/app.manifest'}", f"/out:{exe}",
        str(ROOT / "launcher/EnableUpdates.cs"), str(ROOT / "launcher/UpdateSupport.cs")], check=True)
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(exe, exe.name)
        z.writestr("START-HERE.txt", "UmaPilot — enable automatic updates\n\n"
            "For the September 9, 2026 portable package. This is a one-time install.\n\n"
            "1. Quit UmaPilot using its tray icon. Close any older CMD launcher too.\n"
            "2. Extract this small ZIP. Double-click Enable-Automatic-Updates.exe.\n"
            "3. Select UmaPilot.exe inside your existing extracted UmaPilot folder.\n"
            "4. The installer verifies and updates the application, then opens UmaPilot.\n\n"
            "Your accounts, settings, projects, rosters and results are kept.\n"
            "Future published updates download automatically. Quit and reopen UmaPilot\n"
            "to install a downloaded update. Use the tray menu to check manually.\n\n"
            "If installation fails: work/updates/installer.log inside your UmaPilot folder.\n"
            "A failed update restores the previous application files.\n")
    output.with_suffix(".sha256").write_text(digest(output) + "  " + output.name + "\n")
    print(f"Bootstrap ready: {output} ({output.stat().st_size / 1024:.0f} KiB)")


if __name__ == "__main__":
    p = argparse.ArgumentParser();p.add_argument("--release", type=Path, required=True);p.add_argument("--output", type=Path, required=True)
    a = p.parse_args();build(a.release.resolve(), a.output.resolve())
