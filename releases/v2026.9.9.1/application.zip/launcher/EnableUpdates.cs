using System;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Windows.Forms;

// One-time installer for the original portable ZIP. This contains application
// files and a public verification key only; there is no private publisher key.
internal static class EnableUpdates {
    [STAThread] static int Main(string[] args) {
        Application.EnableVisualStyles();
        try {
            string root=AppDomain.CurrentDomain.BaseDirectory.TrimEnd('\\');
            if(args.Length>0) root=Path.GetFullPath(args[0]);
            if(!File.Exists(Path.Combine(root,"UmaPilot.exe"))) {
                using(var picker=new OpenFileDialog {Title="Select UmaPilot.exe in your existing installation",Filter="UmaPilot|UmaPilot.exe",CheckFileExists=true}) {
                    if(picker.ShowDialog()!=DialogResult.OK) return 0;
                    root=Path.GetDirectoryName(picker.FileName);
                }
            }
            if(Directory.Exists(Path.Combine(root,".git"))) throw new IOException("This is the development checkout. Enable updates on your portable VM copy instead.");
            if(!File.Exists(Path.Combine(root,".runtime","python","python.exe"))) throw new IOException("Select the complete extracted UmaPilot folder.");
            if(UpdateSupport.Installing(root) || !UpdateSupport.PortsFree()) throw new IOException("Quit UmaPilot first, including any CMD launcher, then run this installer again. No running bot has been stopped.");
            string state=Path.Combine(root,"updates","installed.json");
            if(File.Exists(state) && UpdateSupport.Number(UpdateSupport.Read(state),"sequence")>=1) {
                MessageBox.Show("Automatic updates are already enabled. Start UmaPilot.exe normally.","UmaPilot updates"); return 0;
            }
            string relative="bootstrap/"+Guid.NewGuid().ToString("N"), folder=UpdateSupport.SafePath(UpdateSupport.Work(root),relative);
            Directory.CreateDirectory(folder);
            using(var input=typeof(EnableUpdates).Assembly.GetManifestResourceStream("BootstrapPayload"))
            using(var archive=new ZipArchive(input,ZipArchiveMode.Read)) {
                foreach(var entry in archive.Entries) {
                    string name=entry.FullName;
                    if(name!="manifest.json" && name!="channel.json" && name!="public-key.pem" && !(name.StartsWith("files/") && UpdateSupport.Managed(name.Substring(6)))) throw new IOException("Unexpected bootstrap file");
                    string target=UpdateSupport.SafePath(folder,name); Directory.CreateDirectory(Path.GetDirectoryName(target));
                    using(var source=entry.Open()) using(var output=File.Create(target)) source.CopyTo(output);
                }
            }
            var manifest=UpdateSupport.Verify(Path.Combine(folder,"manifest.json"));
            if(UpdateSupport.Number(manifest,"sequence")!=1 || UpdateSupport.Number(manifest,"baseSequence")!=0) throw new IOException("Invalid bootstrap release");
            Directory.CreateDirectory(Path.Combine(root,"updates"));
            File.Copy(Path.Combine(folder,"public-key.pem"),Path.Combine(root,"updates","public-key.pem"),true);
            File.Copy(Path.Combine(folder,"channel.json"),Path.Combine(root,"updates","channel.json"),true);
            UpdateSupport.Write(state,new {baseline=manifest["baseline"],sequence=0,version="2026.09.09-portable"});
            UpdateSupport.Write(Path.Combine(UpdateSupport.Work(root),"pending.json"),new {sequence=1,version=manifest["version"],manifests=new[]{relative+"/manifest.json"}});
            // The helper runs outside the install directory's managed files, so
            // both launcher executables can be replaced after this process exits.
            Process.Start(new ProcessStartInfo(Path.Combine(folder,"files","UmaPilotUpdater.exe")) {Arguments=UpdateSupport.Quote(root)+" "+Process.GetCurrentProcess().Id+(Array.IndexOf(args,"--no-restart")>=0?" --no-restart":""),WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true});
            return 0;
        } catch(Exception error) {
            MessageBox.Show(error.Message,"UmaPilot — enable updates",MessageBoxButtons.OK,MessageBoxIcon.Error); return 1;
        }
    }
}
