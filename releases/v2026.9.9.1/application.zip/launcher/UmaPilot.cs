using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Windows.Forms;

// Small Windows GUI host. Python/Node remain portable, separately replaceable files.
internal static class Program {
    [STAThread] private static int Main(string[] args) {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        string root = AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
        bool smoke = Array.IndexOf(args, "--smoke-test") >= 0;
        if (!smoke && UpdateSupport.Installing(root)) return 0;
        string id;
        using (var hash = SHA256.Create()) id = BitConverter.ToString(hash.ComputeHash(Encoding.UTF8.GetBytes(root.ToUpperInvariant()))).Replace("-", "");
        bool created;
        using (var mutex = new Mutex(true, "Local\\UmaPilot-" + id, out created))
        using (var reopen = new EventWaitHandle(false, EventResetMode.AutoReset, "Local\\UmaPilot-Open-" + id)) {
            if (!created) { reopen.Set(); return 0; }
            try {
                if (!smoke && UpdateSupport.LaunchInstaller(root)) return 0;
                using (var app = new Launcher(root, reopen, Array.IndexOf(args, "--smoke-test") >= 0, Array.IndexOf(args, "--no-browser") >= 0))
                    Application.Run(app);
                return Environment.ExitCode;
            } catch (Exception ex) {
                if (Array.IndexOf(args, "--smoke-test") < 0)
                    MessageBox.Show("UmaPilot could not start.\n\n" + ex.Message, "UmaPilot", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 1;
            } finally { mutex.ReleaseMutex(); }
        }
    }
}

internal sealed class Launcher : ApplicationContext {
    readonly string root, logDir, stopFile;
    readonly bool smoke, noBrowser;
    readonly EventWaitHandle reopen;
    readonly NotifyIcon tray;
    readonly System.Windows.Forms.Timer timer;
    readonly object logLock = new object();
    readonly DateTime started = DateTime.UtcNow;
    Process host;
    OwnedProcessTree owned;
    volatile bool ready;
    bool announced, stopping, finished;
    DateTime stopStarted;
    string lastError = "";
    Process updateCheck;
    DateTime nextUpdateCheck = DateTime.MinValue;
    readonly ToolStripMenuItem updateStatus;
    string lastUpdateState = "";

    internal Launcher(string directory, EventWaitHandle openEvent, bool smokeTest, bool suppressBrowser) {
        root = directory; reopen = openEvent; smoke = smokeTest; noBrowser = suppressBrowser || smoke;
        logDir = Path.Combine(root, "work", "launcher");
        Directory.CreateDirectory(logDir);
        stopFile = Path.Combine(logDir, Guid.NewGuid().ToString("N") + ".stop");
        var menu = new ContextMenuStrip();
        menu.Items.Add("Open UmaPilot", null, delegate { OpenDashboard(); });
        menu.Items.Add("Open launcher logs", null, delegate { Process.Start(new ProcessStartInfo(logDir) { UseShellExecute = true }); });
        updateStatus = new ToolStripMenuItem("Updates: checking after startup") { Enabled = false };
        menu.Items.Add(updateStatus);
        menu.Items.Add("Check for updates", null, delegate { CheckUpdates(); });
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Quit UmaPilot", null, delegate { Stop(); });
        tray = new NotifyIcon { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath), Text = "UmaPilot — starting", ContextMenuStrip = menu, Visible = !smoke };
        tray.DoubleClick += delegate { OpenDashboard(); };
        timer = new System.Windows.Forms.Timer { Interval = 250 };
        timer.Tick += Tick;
        timer.Start();
        try { Start(); } catch (Exception ex) { Fail(ex.Message); }
    }

    void Start() {
        string[] required = { "scripts/start-official.ps1", ".runtime/python/python.exe", ".runtime/node/node-v24.14.0-win-x64/node.exe", "ui/node_modules/vinext/dist/cli.js", "ui/dist/server/BUILD_ID" };
        foreach (string relative in required)
            if (!File.Exists(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar))))
                throw new IOException("Missing " + relative + ". Extract the entire UmaPilot folder first; the EXE must stay inside it.");
        string powershell = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "WindowsPowerShell", "v1.0", "powershell.exe");
        var info = new ProcessStartInfo(powershell) {
            Arguments = "-NoProfile -NonInteractive -ExecutionPolicy Bypass -File " + Quote(Path.Combine(root, "scripts", "start-official.ps1")) + " -NoBrowser -BackendReplacementAware -LauncherStopFile " + Quote(stopFile),
            WorkingDirectory = root, UseShellExecute = false, CreateNoWindow = true, WindowStyle = ProcessWindowStyle.Hidden,
            RedirectStandardOutput = true, RedirectStandardError = true
        };
        Log("Starting UmaPilot from " + root);
        owned = new OwnedProcessTree();
        host = new Process { StartInfo = info };
        host.OutputDataReceived += delegate(object sender, DataReceivedEventArgs e) {
            if (e.Data == null) return;
            Log(e.Data);
            if (e.Data.StartsWith("UmaPilot Official ready:", StringComparison.Ordinal)) ready = true;
        };
        host.ErrorDataReceived += delegate(object sender, DataReceivedEventArgs e) {
            if (!String.IsNullOrWhiteSpace(e.Data)) { lastError = e.Data; Log(e.Data); }
        };
        host.Start();
        try { owned.Attach(host); } catch { host.Kill(); throw; }
        host.BeginOutputReadLine(); host.BeginErrorReadLine();
    }

    static string Quote(string value) { return "\"" + value.Replace("\"", "\\\"") + "\""; }
    void Log(string line) { lock (logLock) { try { File.AppendAllText(Path.Combine(logDir, "launcher.log"), DateTime.Now.ToString("s") + " " + line + Environment.NewLine); } catch (IOException) {} } }
    void OpenDashboard() {
        if (!ready) { tray.ShowBalloonTip(2500, "UmaPilot", "The dashboard is still starting.", ToolTipIcon.Info); return; }
        try { Process.Start(new ProcessStartInfo("http://localhost:3100") { UseShellExecute = true }); }
        catch (Exception ex) { Log(ex.Message); if (!smoke) MessageBox.Show("Open http://localhost:3100 in your browser.", "UmaPilot"); }
    }
    void Stop() {
        if (stopping) return;
        stopping = true; stopStarted = DateTime.UtcNow; tray.Text = "UmaPilot — stopping";
        try { File.WriteAllText(stopFile, "stop"); } catch (IOException) { Finish(1, "Could not request shutdown"); }
    }
    void CheckUpdates() {
        if (smoke || stopping || (updateCheck != null && !updateCheck.HasExited)) return;
        nextUpdateCheck = DateTime.UtcNow.AddMinutes(15);
        if (!File.Exists(Path.Combine(root,"updates","channel.json"))) { updateStatus.Text="Updates: not configured";return; }
        if (Directory.Exists(Path.Combine(root,".git"))) { updateStatus.Text="Updates: development checkout";return; }
        try {
            if(updateCheck!=null) updateCheck.Dispose();
            updateCheck=Process.Start(new ProcessStartInfo(Path.Combine(root,".runtime","python","python.exe")) {
                Arguments="-B -m umabot.update_client --root "+Quote(root),WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden });
            updateStatus.Text="Updates: checking…";
        } catch(Exception ex) { Log("Update check: "+ex.Message); updateStatus.Text="Update check could not start"; }
    }
    void ReadUpdateStatus() {
        string path=Path.Combine(UpdateSupport.Work(root),"status.json");
        if(!File.Exists(path)) return;
        try {
            var status=UpdateSupport.Read(path);string state=(string)status["state"];
            updateStatus.Text=(string)status["message"];
            if(state=="ready" && lastUpdateState!="ready") tray.ShowBalloonTip(6000,"UmaPilot update ready","Quit UmaPilot, then open it again to install. Your saved data will be kept.",ToolTipIcon.Info);
            lastUpdateState=state;
        } catch(Exception ex) { Log("Update status: "+ex.Message); }
    }
    void Tick(object sender, EventArgs args) {
        if (finished) { ExitThread(); return; }
        if (reopen.WaitOne(0) && !noBrowser) OpenDashboard();
        bool exited = host == null || host.HasExited;
        if (exited && host != null) host.WaitForExit(); // Drain redirected readiness/error lines.
        if (ready && !announced) {
            announced = true; tray.Text = "UmaPilot — running";
            if (!noBrowser) OpenDashboard();
            if (smoke) Stop();
        }
        if(ready && !smoke && !stopping && DateTime.UtcNow>=nextUpdateCheck) CheckUpdates();
        if(updateCheck!=null && updateCheck.HasExited) { ReadUpdateStatus(); updateCheck.Dispose();updateCheck=null; }
        if (stopping) {
            if (exited || (DateTime.UtcNow - stopStarted).TotalSeconds > 20) Finish(0, "Stopped");
        } else if (exited && (!ready || host.ExitCode != 0)) {
            Fail("The launcher stopped before the services were ready.\n" + lastError + "\n\nDetails: " + Path.Combine(logDir, "launcher.log"));
        } else if (!ready && (DateTime.UtcNow - started).TotalSeconds > 240) {
            Fail("Startup took too long. Check work\\launcher\\launcher.log.");
        }
        // A successful launcher that reused existing services may exit normally.
        // Keep the tray available; never terminate services owned by another launcher.
    }
    void Fail(string message) {
        Log("ERROR: " + message);
        if (!smoke) MessageBox.Show(message, "UmaPilot — startup failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        Finish(1, message);
    }
    void Finish(int code, string message) {
        if (finished) return;
        finished = true; Environment.ExitCode = code;
        if (smoke) File.WriteAllText(Path.Combine(logDir, "smoke-result.txt"), "exit=" + code + "\nready=" + ready + "\n" + message);
        if (owned != null) { owned.Dispose(); owned = null; }
    }
    protected override void Dispose(bool disposing) {
        if (disposing) {
            timer.Stop(); timer.Dispose(); tray.Visible = false; tray.Dispose();
            if (owned != null) owned.Dispose();
            if (host != null) host.Dispose();
            if (updateCheck != null) { if(!updateCheck.HasExited) updateCheck.Kill();updateCheck.Dispose(); }
            try { File.Delete(stopFile); } catch (IOException) {}
        }
        base.Dispose(disposing);
    }
}

// A Windows job owns only processes created by this launcher. Closing it also
// cleans up Python workers; reused services and the user's browser stay outside.
internal sealed class OwnedProcessTree : IDisposable {
    IntPtr handle;
    [StructLayout(LayoutKind.Sequential)] struct BasicLimits { public long PerProcess, PerJob; public uint Flags; public UIntPtr MinWorkingSet, MaxWorkingSet; public uint ActiveProcessLimit; public UIntPtr Affinity; public uint PriorityClass, SchedulingClass; }
    [StructLayout(LayoutKind.Sequential)] struct IoCounters { public ulong ReadOps, WriteOps, OtherOps, ReadBytes, WriteBytes, OtherBytes; }
    [StructLayout(LayoutKind.Sequential)] struct ExtendedLimits { public BasicLimits Basic; public IoCounters Io; public UIntPtr ProcessMemory, JobMemory, PeakProcessMemory, PeakJobMemory; }
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)] static extern IntPtr CreateJobObject(IntPtr attributes, string name);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool SetInformationJobObject(IntPtr job, int infoClass, ref ExtendedLimits limits, uint size);
    [DllImport("kernel32.dll", SetLastError=true)] static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
    [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
    internal OwnedProcessTree() {
        handle = CreateJobObject(IntPtr.Zero, null);
        var limits = new ExtendedLimits(); limits.Basic.Flags = 0x2000; // KILL_ON_JOB_CLOSE
        if (handle == IntPtr.Zero || !SetInformationJobObject(handle, 9, ref limits, (uint)Marshal.SizeOf(typeof(ExtendedLimits)))) {
            Dispose(); throw new IOException("Windows could not create the background process group.");
        }
    }
    internal void Attach(Process process) { if (!AssignProcessToJobObject(handle, process.Handle)) throw new IOException("Windows could not manage the launcher process safely."); }
    public void Dispose() { if (handle != IntPtr.Zero) { CloseHandle(handle); handle = IntPtr.Zero; } }
}
