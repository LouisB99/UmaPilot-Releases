$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
Add-Type -AssemblyName System.Drawing
# Package the supplied emblem at standard Windows icon sizes, preserving alpha.
$source=[System.Drawing.Image]::FromFile((Join-Path $root 'assets/UmaPilot.png'))
$sizes=@(16,24,32,48,64,128,256)
$frames=@()
try {
 foreach($size in $sizes){
  $bitmap=New-Object System.Drawing.Bitmap $size,$size
  $graphics=[System.Drawing.Graphics]::FromImage($bitmap)
  $stream=New-Object System.IO.MemoryStream
  try {
   $graphics.Clear([System.Drawing.Color]::Transparent)
   $graphics.InterpolationMode=[System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
   $graphics.PixelOffsetMode=[System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
   $scale=[Math]::Min($size/$source.Width,$size/$source.Height)
   $width=[int]($source.Width*$scale);$height=[int]($source.Height*$scale)
   $graphics.DrawImage($source,[int](($size-$width)/2),[int](($size-$height)/2),$width,$height)
   $bitmap.Save($stream,[System.Drawing.Imaging.ImageFormat]::Png)
   $frames+=,@($stream.ToArray())
  } finally {$stream.Dispose();$graphics.Dispose();$bitmap.Dispose()}
 }
 $output=[IO.File]::Create((Join-Path $root 'launcher/UmaPilot.ico'))
 $writer=New-Object IO.BinaryWriter $output
 try {
  $writer.Write([uint16]0);$writer.Write([uint16]1);$writer.Write([uint16]$sizes.Count)
  $offset=6+16*$sizes.Count
  for($i=0;$i -lt $sizes.Count;$i++){
   $dimension=if($sizes[$i] -eq 256){0}else{$sizes[$i]}
   $writer.Write([byte]$dimension);$writer.Write([byte]$dimension)
   $writer.Write([byte]0);$writer.Write([byte]0);$writer.Write([uint16]1);$writer.Write([uint16]32)
   $writer.Write([uint32]$frames[$i].Length);$writer.Write([uint32]$offset)
   $offset+=$frames[$i].Length
  }
  foreach($frame in $frames){$writer.Write([byte[]]$frame)}
 } finally {$writer.Dispose();$output.Dispose()}
 Copy-Item -LiteralPath (Join-Path $root 'launcher/UmaPilot.ico') -Destination (Join-Path $root 'ui/public/favicon.ico')
} finally {$source.Dispose()}
