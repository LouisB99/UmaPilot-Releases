$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$compiler=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
if(-not(Test-Path -LiteralPath $compiler)){throw 'Windows .NET Framework 4 compiler is required to build the launcher.'}
& (Join-Path $PSScriptRoot 'build-icons.ps1')
$iconPath=Join-Path $root 'launcher/UmaPilot.ico'
$publicKey=Join-Path $root 'updates/public-key.xml'
if(-not(Test-Path -LiteralPath $publicKey)){throw 'Initialize the update publisher before building the signed-update launcher.'}
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll ("/resource:"+$publicKey+',UpdatePublicKey') ("/win32icon:"+$iconPath) ("/win32manifest:"+(Join-Path $root 'launcher/app.manifest')) ("/out:"+(Join-Path $root 'UmaPilot.exe')) (Join-Path $root 'launcher/UmaPilot.cs') (Join-Path $root 'launcher/UpdateSupport.cs') (Join-Path $root 'launcher/StartupUpdateWindow.cs') (Join-Path $root 'launcher/DashboardWindow.cs')
if($LASTEXITCODE -ne 0){throw 'Launcher compilation failed'}
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Web.Extensions.dll ("/resource:"+$publicKey+',UpdatePublicKey') ("/win32icon:"+$iconPath) ("/win32manifest:"+(Join-Path $root 'launcher/app.manifest')) ("/out:"+(Join-Path $root 'UmaPilotUpdater.exe')) (Join-Path $root 'launcher/UmaPilotUpdater.cs') (Join-Path $root 'launcher/UpdateSupport.cs')
if($LASTEXITCODE -ne 0){throw 'Updater compilation failed'}
Write-Host 'Built UmaPilot.exe (Windows GUI, no console window).'
