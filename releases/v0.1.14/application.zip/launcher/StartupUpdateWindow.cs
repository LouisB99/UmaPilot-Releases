using System;
using System.Drawing;
using System.Threading;
using System.Windows.Forms;

internal sealed class StartupUpdateWindow : Form {
    readonly Label message;
    readonly ProgressBar progress;
    readonly Button cancel;
    volatile bool cancelled;
    bool finished;
    internal StartupUpdateWindow(string root) {
        Icon=Icon.ExtractAssociatedIcon(Application.ExecutablePath);
        Text="UmaPilot";ClientSize=new Size(390,155);FormBorderStyle=FormBorderStyle.FixedDialog;
        StartPosition=FormStartPosition.CenterScreen;MaximizeBox=false;MinimizeBox=false;
        BackColor=Color.FromArgb(24,32,32);ForeColor=Color.White;
        Font=new Font("Segoe UI",10);
        message=new Label{Text="Checking for updates before starting…",Left=22,Top=22,Width=346,Height=28};
        progress=new ProgressBar{Left=22,Top=58,Width=346,Height=12,Style=ProgressBarStyle.Marquee};
        cancel=new Button{Text="Cancel startup",Left=242,Top=96,Width=126,Height=32,FlatStyle=FlatStyle.Flat};
        cancel.Click+=delegate{Close();};Controls.Add(message);Controls.Add(progress);Controls.Add(cancel);
        Shown+=delegate {
            ThreadPool.QueueUserWorkItem(delegate {
                bool proceed=UpdateSupport.CheckBeforeStart(root, delegate(string state,int percent) {
                    if(IsDisposed) return;
                    BeginInvoke((Action)delegate {
                        if(cancelled) return;
                        message.Text=state=="downloading"?"Downloading update — "+percent+"%":state=="verifying"?"Verifying update…":state=="error"?"Opening the installed version…":"Checking for updates before starting…";
                        progress.Style=state=="downloading"?ProgressBarStyle.Continuous:ProgressBarStyle.Marquee;
                        if(state=="downloading")progress.Value=Math.Max(0,Math.Min(100,percent));
                    });
                },delegate{return cancelled;});
                BeginInvoke((Action)delegate {finished=true;DialogResult=proceed?DialogResult.OK:DialogResult.Cancel;Close();});
            });
        };
        FormClosing+=delegate(object sender,FormClosingEventArgs e) {
            if(!finished){e.Cancel=true;cancelled=true;cancel.Enabled=false;message.Text="Cancelling startup…";}
        };
    }
    internal static bool Run(string root) {
        using(var window=new StartupUpdateWindow(root))return window.ShowDialog()==DialogResult.OK;
    }
}
