using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading;

internal sealed class Change {
    public string path, before, after, source;
}
internal static class Updater {
    static string root, work;
    static void Log(string message) { File.AppendAllText(Path.Combine(work,"installer.log"), DateTime.UtcNow.ToString("s")+" "+message+Environment.NewLine); }
    [STAThread] static int Main(string[] args) {
        if(args.Length<2) return 2;
        root=Path.GetFullPath(args[0]).TrimEnd('\\'); work=UpdateSupport.Work(root); Directory.CreateDirectory(work);
        bool created, restart=Array.IndexOf(args,"--no-restart")<0;
        int code=0;
        using(var gate=new Mutex(true,"Local\\UmaPilotInstall-"+UpdateSupport.Id(root),out created)) {
            if(!created) return 2;
            try {
                using(var ready=EventWaitHandle.OpenExisting("Local\\UmaPilotInstallReady-"+UpdateSupport.Id(root))) ready.Set();
            } catch(WaitHandleCannotBeOpenedException) {}
            try {
                int parent=Int32.Parse(args[1]);
                if(parent>0) { try { using(var process=Process.GetProcessById(parent)) if(!process.WaitForExit(30000)) throw new IOException("Original launcher is still running"); } catch(ArgumentException) {} }
                if(!UpdateSupport.PortsFree()) throw new IOException("UmaPilot services are still running. Update postponed.");
                if(File.Exists(Path.Combine(work,"transaction.json"))) { Rollback(); Log("Recovered an interrupted update"); }
                else Install();
            } catch(Exception ex) {
                code=1; Log(ex.ToString());
                try { if(File.Exists(Path.Combine(work,"transaction.json"))) Rollback(); }
                catch(Exception rollback) { restart=false; Log("ROLLBACK NEEDS ATTENTION: "+rollback); }
                UpdateSupport.Write(Path.Combine(work,"status.json"),new {state="failed",message="Update was not installed. See work/updates/installer.log."});
            } finally { gate.ReleaseMutex(); }
        }
        if(restart) Process.Start(new ProcessStartInfo(Path.Combine(root,"UmaPilot.exe")){UseShellExecute=true,WorkingDirectory=root});
        return code;
    }
    static List<Change> Changes(Dictionary<string,object> pending, Dictionary<string,object> installed) {
        var changes=new Dictionary<string,Change>(StringComparer.OrdinalIgnoreCase);
        int previous=UpdateSupport.Number(installed,"sequence");
        foreach(string relative in (IEnumerable)pending["manifests"]) {
            string manifest=UpdateSupport.SafePath(work,relative);
            var release=UpdateSupport.Verify(manifest);
            if(UpdateSupport.Number(release,"format")!=1 || UpdateSupport.Number(release,"baseSequence")!=previous || UpdateSupport.Number(release,"sequence")!=previous+1 || (string)release["baseline"]!=(string)installed["baseline"]) throw new IOException("Update sequence does not match this installation");
            var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach(Dictionary<string,object> file in (IEnumerable)release["files"]) {
                string name=(string)file["path"]; UpdateSupport.SafePath(root,name);
                if(!UpdateSupport.Managed(name)||!seen.Add(name)) throw new IOException("Unmanaged or duplicate update path: "+name);
                string before=(string)file["before"],after=(string)file["after"];
                foreach(string hash in new[]{before,after}) if(hash!=null && !System.Text.RegularExpressions.Regex.IsMatch(hash,"^[0-9a-f]{64}$")) throw new IOException("Invalid signed hash");
                Change existing;
                if(changes.TryGetValue(name,out existing)) { if(existing.after!=before) throw new IOException("Broken file history: "+name); existing.after=after; }
                else { existing=new Change{path=name,before=before,after=after};changes.Add(name,existing); }
                existing.source=after==null?null:UpdateSupport.SafePath(Path.Combine(Path.GetDirectoryName(manifest),"files"),name);
                if(after!=null && (UpdateSupport.Hash(existing.source)!=after || new FileInfo(existing.source).Length!=Convert.ToInt64(file["size"]))) throw new IOException("Staged file failed verification: "+name);
            }
            previous++;
        }
        if(previous!=UpdateSupport.Number(pending,"sequence") || previous<=UpdateSupport.Number(installed,"sequence")) throw new IOException("Invalid target version");
        // A file added and removed between skipped releases never existed locally.
        // Likewise a file restored to its original hash needs no filesystem work.
        return new List<Change>(changes.Values).FindAll(c => c.before != c.after);
    }
    static void Install() {
        string pendingPath=Path.Combine(work,"pending.json"); if(!File.Exists(pendingPath)) return;
        var pending=UpdateSupport.Read(pendingPath);var installed=UpdateSupport.Read(Path.Combine(root,"updates","installed.json"));
        List<Change> changes;
        try { changes=Changes(pending,installed); }
        catch { File.Delete(pendingPath);throw; }
        string backup=Path.Combine(work,"backups",Guid.NewGuid().ToString("N")); Directory.CreateDirectory(backup);
        // Validate every original before mutating anything. A locally edited file is preserved.
        foreach(var c in changes) {
            string path=UpdateSupport.SafePath(root,c.path);
            if(UpdateSupport.Hash(path)!=c.before) { File.Delete(pendingPath); UpdateSupport.Write(Path.Combine(work,"failed.json"),new {sequence=pending["sequence"]});throw new IOException("Local file differs from the published base: "+c.path); }
            if(c.before!=null) { string copy=UpdateSupport.SafePath(backup,c.path); Directory.CreateDirectory(Path.GetDirectoryName(copy));File.Copy(path,copy); }
        }
        UpdateSupport.Write(Path.Combine(work,"transaction.json"),new {backup=backup,files=changes,installed=installed,target=pending["sequence"]});
        try {
            foreach(var c in changes) {
                string path=UpdateSupport.SafePath(root,c.path);
                if(c.after==null) { if(File.Exists(path)) File.Delete(path); }
                else Replace(c.source,path);
            }
            Log("Application files installed; checking code and portable dependencies without starting bots");
            using(var probe=Process.Start(new ProcessStartInfo(Path.Combine(root,".runtime","python","python.exe")){Arguments="-B "+UpdateSupport.Quote(Path.Combine(root,"scripts","verify-update.py")),WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true})) {
                if(!probe.WaitForExit(120000)) { probe.Kill(); probe.WaitForExit(); throw new IOException("Updated application validation timed out"); }
                if(probe.ExitCode!=0) throw new IOException("Updated application failed validation; see work/updates/validation.log");
            }
            UpdateSupport.Write(Path.Combine(root,"updates","installed.json"),new {sequence=pending["sequence"],version=pending["version"],baseline=installed["baseline"]});
            File.Delete(Path.Combine(work,"transaction.json"));File.Delete(pendingPath);File.Delete(Path.Combine(work,"failed.json"));
            UpdateSupport.Write(Path.Combine(work,"status.json"),new {state="current",version=pending["version"],message="Update installed successfully."});
            Log("Update complete: "+pending["version"]);
        } catch { Rollback(); throw; }
    }
    static void Replace(string source,string destination) {
        Directory.CreateDirectory(Path.GetDirectoryName(destination));string temporary=destination+".update-new";
        File.Copy(source,temporary,true);
        if(File.Exists(destination)) File.Replace(temporary,destination,null); else File.Move(temporary,destination);
    }
    static void Rollback() {
        var journal=UpdateSupport.Read(Path.Combine(work,"transaction.json"));
        string backup=(string)journal["backup"];
        if(!backup.StartsWith(Path.Combine(work,"backups")+"\\",StringComparison.OrdinalIgnoreCase)) throw new IOException("Invalid rollback backup");
        var files=(IEnumerable)journal["files"];
        foreach(Dictionary<string,object> c in files) {
            string name=(string)c["path"],before=(string)c["before"],after=(string)c["after"];
            if(!UpdateSupport.Managed(name)) throw new IOException("Invalid rollback file");
            string path=UpdateSupport.SafePath(root,name),current=UpdateSupport.Hash(path);
            if(current!=before && current!=after) throw new IOException("A file changed during rollback: "+name);
            if(before==null) { if(File.Exists(path)) File.Delete(path); }
            else { string copy=UpdateSupport.SafePath(backup,name);if(UpdateSupport.Hash(copy)!=before) throw new IOException("Rollback backup failed verification");Replace(copy,path); }
        }
        UpdateSupport.Write(Path.Combine(root,"updates","installed.json"),journal["installed"]);
        UpdateSupport.Write(Path.Combine(work,"failed.json"),new {sequence=journal["target"]});
        File.Delete(Path.Combine(work,"pending.json"));File.Delete(Path.Combine(work,"transaction.json"));Log("Previous application version restored; user data untouched");
    }
}
