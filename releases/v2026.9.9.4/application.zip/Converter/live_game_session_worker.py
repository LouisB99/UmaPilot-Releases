"""Open one parked, read-only Uma account session for the local dashboard.

The process owns all ticket and SID material in memory.  It performs exactly
Pre-signup/signup on first login, then Start -> load, and serves the serialized API runtime over local stdin/stdout.
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import secrets
import re
import subprocess
import sys
import threading
import time
import msgpack
from pathlib import Path

from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from umabot.gameless_login import GamelessLogin, DataLinkError
from umabot.gameless_profiles import device_for, bind_verified, save_auth, pilot_target, PilotCredentialsError
import hashlib
from umabot.api_navigation import SessionNavigator
from umabot.account_profiles import AccountProfileStore
def _b64(value, name):
    if not isinstance(value, str):
        raise ValueError('Missing encrypted Steam response field')
    return base64.b64decode(value, validate=True)


def _random_logon_id():
    return secrets.randbelow(2**32 - 1) + 1



def _write(value: dict[str, object]) -> None:
    sys.stdout.write(json.dumps(value, separators=(",", ":")) + "\n")
    sys.stdout.flush()


def run(args: argparse.Namespace) -> int:
    if os.environ.get("UMAPILOT_ALLOW_GAME_SESSION") != "YES":
        raise RuntimeError("parked game session refused: explicit authorization is absent")
    if not 0.2 <= args.transition_delay <= 2:
        raise ValueError("transition delay must be between 0.2 and 2 seconds")

    root = Path(__file__).resolve().parents[1]
    store = AccountProfileStore(args.account_vault)
    profile = store.get(args.profile_id)
    if profile is None or profile.status != 'ready' or not profile.has_saved_session:
        raise ValueError('Select a ready Steam profile')
    if profile.assigned_function != 'pilot':
        raise ValueError('This Steam profile is assigned to Janus, not Pilot')
    from umabot.profile_lease import ProfileLease
    secret = store.load_steam_session(args.profile_id)
    refresh_token = str(secret.get('refreshToken') or '')
    # This claim supplies the ID only; the freshly minted ticket independently
    # verifies the same identity before any game request is sent.
    part = refresh_token.split('.')[1]
    steam_id = str(json.loads(base64.urlsafe_b64decode(part + '=' * (-len(part) % 4)))['sub'])
    expected_steam_fingerprint = profile.steam_id_fingerprint
    if hashlib.sha256(steam_id.encode()).hexdigest()[:12] != expected_steam_fingerprint:
        raise ValueError('Steam credential identity does not match saved profile')
    game, data_link = pilot_target(store, args.profile_id)
    expected_viewer = game.trainer_id_fingerprint
    profile_lease = ProfileLease(root,args.profile_id)
    login = GamelessLogin(json.loads((root / 'resources/protocol.json').read_text()),
        device_for(store, args.profile_id), steam_id)
    credential_source = '--stdin-token'
    auth_data_directory = args.auth_data_directory or args.account_vault / 'steam-data' / args.profile_id
    auth_data_directory.mkdir(parents=True, exist_ok=True)

    ipc_key = secrets.token_bytes(32)
    worker_env = os.environ.copy()
    worker_env["UMAPILOT_ALLOW_STEAM_LOGIN"] = "YES"
    worker_env["UMAPILOT_IPC_KEY"] = ipc_key.hex()
    steam_worker = subprocess.Popen(
        [
            str(args.node),
            str(args.worker.resolve()),
            credential_source,
            str(auth_data_directory.resolve()),
            str(args.node_modules.resolve()),
            str(_random_logon_id()),
        ],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=worker_env,
        text=True,
        encoding="utf-8",
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    heartbeat_stop = threading.Event()
    write_lock = threading.Lock()

    def send_to_steam(message: str) -> None:
        with write_lock:
            if steam_worker.stdin is None or steam_worker.poll() is not None:
                raise RuntimeError("Steam ticket worker is no longer running")
            steam_worker.stdin.write(message + "\n")
            steam_worker.stdin.flush()

    def heartbeat() -> None:
        while not heartbeat_stop.wait(20):
            try:
                send_to_steam("ping")
            except (OSError, RuntimeError):
                return

    heartbeat_thread: threading.Thread | None = None
    established = False
    try:
        if refresh_token is not None:
            credential_nonce = secrets.token_bytes(12)
            encrypted = AESGCM(ipc_key).encrypt(
                credential_nonce, refresh_token.encode("utf-8"), None
            )
            send_to_steam(json.dumps({
                "type": "credential",
                "nonce": base64.b64encode(credential_nonce).decode("ascii"),
                "ciphertext": base64.b64encode(encrypted[:-16]).decode("ascii"),
                "tag": base64.b64encode(encrypted[-16:]).decode("ascii"),
            }, separators=(",", ":")))
            refresh_token = None
        if steam_worker.stdout is None:
            raise RuntimeError("Steam ticket worker has no output pipe")
        line = steam_worker.stdout.readline()
        if not line:
            error = steam_worker.stderr.read(400) if steam_worker.stderr else ""
            raise RuntimeError(f"Steam ticket worker stopped: {error.strip()}")
        ready = json.loads(line)
        if ready.get("type") != "ready":
            raise RuntimeError("Steam ticket worker returned an unexpected message")
        ticket = AESGCM(ipc_key).decrypt(
            _b64(ready.get("nonce"), "nonce"),
            _b64(ready.get("ciphertext"), "ciphertext")
            + _b64(ready.get("tag"), "tag"),
            None,
        )
        if ready.get("steamIdSha256Prefix") != expected_steam_fingerprint:
            raise RuntimeError("minted Steam ticket identity does not match the profile")

        if not all(ready.get(k) is True for k in ('ticketAppIdMatches', 'ticketHasValidSignature', 'ticketIsValid')):
            raise RuntimeError('Steam ticket validation failed')
        restored_sid, restored_opener = login.restore_data_link(ticket, data_link, allow_network=True,
            timeout=args.timeout, save_auth=lambda viewer, key: save_auth(store,args.profile_id,viewer,key))
        data_link.clear()
        load_data, sid, contract, opener = login.connect(ticket, allow_network=True,
            expected_viewer_fingerprint=expected_viewer, timeout=args.timeout, start_sid=restored_sid, opener=restored_opener,
            save_auth=lambda viewer, key: save_auth(store, args.profile_id, viewer, key))
        bind_verified(store, args.profile_id, login.viewer_id,
            (load_data.get('user_info') or {}).get('name') or 'Steam game account')
        navigator = SessionNavigator(codec=login.codec, common_template=login.common,
            header=login.header(), ticket=ticket, request_sid=sid, contract=contract,
            opener=opener, capture_session=root / 'work/session-ownership',
            timeout=args.timeout, delay=args.transition_delay)
        from umabot.api_runtime import ApiRuntime, serve
        heartbeat_thread = threading.Thread(target=heartbeat, daemon=True)
        heartbeat_thread.start()
        runtime = ApiRuntime(navigator, load_data, root)
        runtime.bootstrap_count = login.request_count
        established = True
        serve(runtime, sys.stdin, sys.stdout)
        return 0
    finally:
        heartbeat_stop.set()
        if heartbeat_thread is not None:
            heartbeat_thread.join(timeout=2)
        if steam_worker.poll() is None:
            try:
                send_to_steam("close")
            except (OSError, RuntimeError):
                pass
        try:
            steam_worker.wait(timeout=15)
        except subprocess.TimeoutExpired:
            steam_worker.terminate()
            steam_worker.wait(timeout=5)
        profile_lease.close()
        if established:
            _write({"type": "closed", "status": "disconnected"})


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--node", required=True)
    parser.add_argument("--worker", required=True, type=Path)
    parser.add_argument("--account-vault", required=True, type=Path)
    parser.add_argument("--profile-id", required=True)
    parser.add_argument("--auth-data-directory", type=Path)
    parser.add_argument("--node-modules", required=True, type=Path)
    parser.add_argument("--lookup-root", required=True, type=Path)
    parser.add_argument("--unity-version", required=True)
    parser.add_argument("--transition-delay", type=float, default=0.28)
    parser.add_argument("--timeout", type=float, default=15.0)
    args = parser.parse_args()
    args.refresh_token = None
    try:
        return run(args)
    except (PilotCredentialsError, DataLinkError) as exc:
        _write({'type': 'error', 'status': 'disconnected', 'connectionError': str(exc)})
        return 2
    except Exception as exc:
        code = re.search(r'response_code=(\d{1,6})', str(exc))
        message = f"Official game connection rejected (response code {code.group(1)})" if code else f"Saved account connection failed ({type(exc).__name__}); verify its login in Accounts"
        _write({'type': 'error', 'status': 'disconnected', 'connectionError': message})
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
