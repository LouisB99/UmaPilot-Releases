"""Dashboard-safe update status: never return paths, keys or raw installer errors."""
import json
from pathlib import Path


def read_status(root: Path):
    def read(relative):
        try:
            value = json.loads((root / relative).read_text(encoding='utf-8-sig'))
            return value if isinstance(value, dict) else {}
        except (OSError, ValueError):
            return {}
    installed = read('updates/installed.json')
    status = read('work/updates/status.json')
    pending = read('work/updates/pending.json')
    state = status.get('state', 'current')
    if pending.get('sequence', 0) > installed.get('sequence', 0):
        state = 'ready'
    if state not in {'checking', 'downloading', 'verifying', 'ready', 'current', 'error', 'failed', 'development', 'disabled'}:
        state = 'current'
    try:
        percent = max(0, min(100, int(status.get('percent', 0))))
    except (ValueError, TypeError):
        percent = 0
    return {'installedVersion': str(installed.get('version') or 'Development'),
            'state': state, 'percent': percent}
