"""Steam game bootstrap built from protocol fields, with no capture or game I/O.

Device UUID -> ASCII hex IV and salted initial SID were checked against twelve
official Start exchanges. Only the application-wide 52-byte prefix is packaged.
Tickets, device state and returned authentication keys are never public output.
"""
from __future__ import annotations

import base64
import hashlib
import secrets
import uuid
import re

import msgpack

from .api_bootstrap import (PreparedAuthRequest, PreparedStartRequest,
    PreparedLoadIndexRequest, PRE_SIGNUP_ENDPOINT, SIGNUP_ENDPOINT, START_ENDPOINT,
    LOAD_INDEX_ENDPOINT)
from .api_session import SESSION_ID_MD5_SUFFIX
from .api_transport import (AuthHttpContract, AuthOnlyHttpTransport, StartHttpContract,
    StartOnlyHttpTransport, LoadIndexHttpContract, LoadIndexOnlyHttpTransport,
    with_server_resource_version)
from .wire_codec import GameWireCodec


def new_device() -> dict:
    return {'uuid': str(uuid.uuid4()), 'deviceId': secrets.token_hex(20)}


class DataLinkError(RuntimeError):
    """Credential-free error suitable for the account connection UI."""


def data_link_password(password: str, password_format=None) -> str:
    # Global client literal, confirmed against the successful official lookup capture.
    # Older vaults contain the captured wire value; new form submissions are tagged plain.
    if password_format == 'wire' or (password_format is None and re.fullmatch(r'[0-9a-fA-F]{32}', password)):
        return password.lower()
    return hashlib.md5((password + 'co!=Y;(UQCGxJ_n82').encode('utf-8')).hexdigest()


class GamelessLogin:
    def __init__(self, config: dict, device: dict, steam_id: str):
        self.config = dict(config)
        self.uuid = uuid.UUID(device['uuid'])
        self.prefix = bytes.fromhex(config['applicationHeaderHex'])
        if len(self.prefix) != 52:
            raise ValueError('Invalid application protocol header')
        if not steam_id.isdigit() or len(steam_id) != 17:
            raise ValueError('Invalid authenticated Steam identity')
        self.codec = GameWireCodec(self.uuid.hex[:16].encode('ascii'))
        self.common = dict(viewer_id=0, device=4, device_id=device['deviceId'],
            device_name='UmaPilot Portable', graphics_device_name='', ip_address='',
            platform_os_version='Windows 11 (64bit)', carrier='', keychain=0,
            locale='JPN', button_info='', dmm_viewer_id=None, dmm_onetime_token=None,
            steam_id=steam_id, steam_session_ticket='')
        self.auth = base64.b64decode(device['authKey'], validate=True) if device.get('authKey') else b''
        self.viewer_id = int(device.get('viewerId') or 0)
        if bool(self.auth) != bool(self.viewer_id) or (self.auth and len(self.auth) != 48):
            raise ValueError('Saved game authentication is incomplete')
        self.request_count = 0

    def initial_sid(self) -> str:
        return hashlib.md5((str(self.viewer_id) + str(self.uuid) +
            SESSION_ID_MD5_SUFFIX).encode()).hexdigest()

    def header(self) -> bytes:
        return (b'\0' * 4 + self.prefix + bytes.fromhex(self.initial_sid()) +
            self.uuid.bytes + b'\0' * 32 + self.auth)

    def prepare(self, endpoint: str, ticket: bytes, sid: str | None = None):
        if len(ticket) != 234:
            raise ValueError('Unexpected Steam ticket length')
        payloads = {
            PRE_SIGNUP_ENDPOINT: dict(attestation_type=1, device_token=None),
            SIGNUP_ENDPOINT: dict(credential='', error_code=0, error_message='',
                attestation_type=1, optin_user_birth=self.config.get('signupBirth',0), dma_state=self.config.get('signupDma',0), country=self.config.get('signupCountry','')),
            START_ENDPOINT: dict(attestation_type=0, device_token=None),
            LOAD_INDEX_ENDPOINT: dict(adid=''),
        }
        if endpoint not in payloads:
            raise ValueError('Unsupported login step')
        logical = msgpack.packb({**payloads[endpoint], **self.common,
            'viewer_id': self.viewer_id, 'steam_session_ticket': ticket.hex().upper()}, use_bin_type=True)
        request_sid = sid or self.initial_sid()
        wire = self.codec.encode_request(logical, self.header(), sid=request_sid)
        args = (endpoint, 'gameless', wire, logical, request_sid,
            hashlib.sha256(ticket).hexdigest()[:12])
        if endpoint == START_ENDPOINT:
            return PreparedStartRequest(*args)
        if endpoint == LOAD_INDEX_ENDPOINT:
            return PreparedLoadIndexRequest(*args)
        return PreparedAuthRequest(*args)

    def contract(self, endpoint: str):
        routes = {PRE_SIGNUP_ENDPOINT: 'tool/pre_signup', SIGNUP_ENDPOINT: 'tool/signup',
            START_ENDPOINT: 'tool/start_session', LOAD_INDEX_ENDPOINT: 'load/index'}
        args = dict(url='https://api.games.umamusume.com/umamusume/' + routes[endpoint],
            app_version=self.config['appVersion'], resource_version=self.config['resourceVersion'],
            unity_version=self.config['unityVersion'], viewer_id=str(self.viewer_id),
            device='4', device_subtype='1')
        if endpoint in (PRE_SIGNUP_ENDPOINT, SIGNUP_ENDPOINT):
            return AuthHttpContract(endpoint=endpoint, **args)
        return (StartHttpContract if endpoint == START_ENDPOINT else LoadIndexHttpContract)(**args)

    def restore_data_link(self, ticket, credentials, *, allow_network=False, opener=None, timeout=15, save_auth=None):
        """Captured account lookup/chain sequence; no reset, signup or retries."""
        import urllib.request
        from .api_transport import _post_logical
        from .api_session import derive_request_sid
        target = str(credentials.get('trainerId') or '')
        password = str(credentials.get('linkPassword') or '')
        if not target.isdigit() or not password:
            raise ValueError('Save the Pilot Trainer ID and Link Password in Accounts first')
        password = data_link_password(password, credentials.get('passwordFormat'))
        if len(ticket) != 234:
            raise ValueError('Unexpected Steam ticket length')
        if not allow_network:
            raise ValueError('Data Link network access is not enabled')
        transport = AuthOnlyHttpTransport(self.codec, allow_network=True, opener=opener, timeout=timeout)
        sid = self.initial_sid()
        for route, extra in [
            ('account/index', {'cygames_id_client_sdk_version':'v2'}),
            ('account/get_by_transition_code', {'input_viewer_id':int(target), 'password':password}),
            ('account/chain_by_transition_code', {'input_viewer_id':int(target), 'password':password}),
        ]:
            step = {'account/index':'opening Data Link',
                    'account/get_by_transition_code':'checking the Trainer ID and password',
                    'account/chain_by_transition_code':'linking the Pilot account'}[route]
            payload = {**self.common, **extra, 'viewer_id':self.viewer_id, 'steam_session_ticket':ticket.hex().upper()}
            logical = msgpack.packb(payload, use_bin_type=True)
            request = urllib.request.Request('https://api.games.umamusume.com/umamusume/'+route,
                data=self.codec.encode_request(logical,self.header(),sid=sid),
                headers=self.contract(START_ENDPOINT).headers(sid),method='POST')
            try:
                _, result = _post_logical(self.codec,transport.opener,request,timeout,route)
            except Exception as exc:
                raise DataLinkError(f'Data Link failed while {step} ({type(exc).__name__}); the response was uncertain, so no retry was sent') from None
            self.request_count += 1
            headers = result.get('data_headers') or {}
            if result.get('response_code') != 1 or headers.get('result_code') != 1:
                def safe_code(value):
                    return str(value) if isinstance(value, int) else 'unknown'
                raise DataLinkError(f'Data Link rejected while {step} (response code {safe_code(result.get("response_code"))}, result code {safe_code(headers.get("result_code"))})')
            if headers.get('sid'):
                sid = derive_request_sid(headers['sid'])
            data = result.get('data') or {}
            if route.endswith('get_by_transition_code') and str(data.get('target_viewer_id')) != target:
                raise DataLinkError('Data Link lookup returned a different target; linking cancelled')
            if route.endswith('chain_by_transition_code'):
                if str(data.get('chained_viewer_id')) != target:
                    raise DataLinkError('Data Link returned a different account; Pilot stopped')
                auth = base64.b64decode(data.get('auth_key') or '',validate=True)
                if len(auth) != 48:
                    raise DataLinkError('Data Link returned invalid authentication; Pilot stopped')
                self.auth = auth
                self.viewer_id = int(target)
                self.common['viewer_id'] = self.viewer_id
                if save_auth:
                    save_auth(self.viewer_id,data['auth_key'])
        return sid, transport.opener

    def connect(self, ticket: bytes, *, allow_network=False, opener=None,
                expected_viewer_fingerprint: str | None = None, timeout=15, save_auth=None, start_sid=None, before_request=None):
        auth_transport = AuthOnlyHttpTransport(self.codec, allow_network=allow_network,
            opener=opener, timeout=timeout)
        if self.viewer_id and expected_viewer_fingerprint and hashlib.sha256(
                str(self.viewer_id).encode()).hexdigest()[:12] != expected_viewer_fingerprint:
            raise RuntimeError('Saved game authentication belongs to a different account')
        for endpoint in (() if self.auth else (PRE_SIGNUP_ENDPOINT, SIGNUP_ENDPOINT)):
            if before_request:before_request()
            response = auth_transport.send(self.prepare(endpoint, ticket), self.contract(endpoint))
            self.request_count += 1
            if endpoint == SIGNUP_ENDPOINT:
                if not response.viewer_id or not response.auth_key:
                    raise RuntimeError('Game login returned no account authentication')
                fingerprint = hashlib.sha256(str(response.viewer_id).encode()).hexdigest()[:12]
                if expected_viewer_fingerprint and fingerprint != expected_viewer_fingerprint:
                    raise RuntimeError('Game login resolved to a different account; stopped before Start')
                self.auth = base64.b64decode(response.auth_key, validate=True)
                if len(self.auth) != 48:
                    raise RuntimeError('Game login returned an invalid authentication key')
                self.viewer_id = int(response.viewer_id)
                self.common['viewer_id'] = self.viewer_id
                if save_auth:
                    save_auth(self.viewer_id, response.auth_key)
        if before_request:before_request()
        start = StartOnlyHttpTransport(self.codec, allow_network=allow_network,
            opener=auth_transport.opener, timeout=timeout).send(
                self.prepare(START_ENDPOINT, ticket, start_sid), self.contract(START_ENDPOINT))
        self.request_count += 1
        if start.response_code != 1:
            raise RuntimeError(f'Game Start rejected (response_code={start.response_code})')
        contract = with_server_resource_version(self.contract(LOAD_INDEX_ENDPOINT),
            msgpack.unpackb(start.logical_body, raw=False, strict_map_key=False))
        if before_request:before_request()
        load = LoadIndexOnlyHttpTransport(self.codec, allow_network=allow_network,
            opener=auth_transport.opener, timeout=timeout).send(
                self.prepare(LOAD_INDEX_ENDPOINT, ticket, start.next_request_sid), contract)
        self.request_count += 1
        data = msgpack.unpackb(load.logical_body, raw=False, strict_map_key=False)['data']
        if int((data.get('user_info') or {}).get('viewer_id') or 0) != self.viewer_id:
            raise RuntimeError('Loaded game identity does not match login')
        self.common['viewer_id'] = self.viewer_id
        return data, load.next_request_sid, contract, auth_transport.opener
