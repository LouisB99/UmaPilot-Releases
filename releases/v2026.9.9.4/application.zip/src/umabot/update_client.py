"""Signed, sequential application updates. Download only; never stop a running bot.

The windowless installer re-verifies signatures and applies the staged changes
before the next launch. User state is deliberately outside the managed paths.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import time
import urllib.parse
import urllib.request
import zipfile

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

ROOT = Path(__file__).resolve().parents[2]
PREFIXES = ("src/", "scripts/", "launcher/", "resources/", "assets/", "vendor/",
            "Converter/", ".runtime/", "ui/dist/", "ui/node_modules/", "ui/public/data/planner/",
            "ui/public/janus/", "ui/public/uma-tools/", "ui/public/umalator/", "ui/public/images/")
EXACT = {"UmaPilot.exe", "UmaPilotUpdater.exe", "requirements-portable.txt", "pyproject.toml",
         "START-UMA-PILOT.cmd", "START-JANUS.cmd", "START-MERCURY.cmd", "CHECK-PORTABILITY.cmd",
         "ui/public/data/sparks.json", "ui/public/data/umas.json", "ui/package.json"}
FORBIDDEN = {".git", "__pycache__", ".cache", ".pytest_cache", ".next", ".wrangler", ".vinext"}


def managed(path: str) -> bool:
    if not isinstance(path, str) or not path or "\\" in path or ":" in path:
        return False
    parts = path.split("/")
    if any(p in ("", ".", "..") or p in FORBIDDEN or p.rstrip(". ") != p or
           p.lower().startswith(".env") or re.fullmatch(r"(?i)(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?", p)
           for p in parts):
        return False
    if path.lower().endswith((".log", ".pyc", ".pyo", ".sqlite", ".db", ".dpapi")):
        return False
    return path in EXACT or path.startswith(PREFIXES)


def digest(path: Path) -> str:
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def safe_path(base: Path, relative: str) -> Path:
    if not relative or "\\" in relative or ":" in relative or any(p in ("", ".", "..") for p in relative.split("/")):
        raise ValueError("Invalid update staging path")
    target = base / relative
    for path in (target, *target.parents):
        if path.is_symlink() or path.is_junction():
            raise ValueError("Update paths must not contain links")
    return target


def atomic_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def verified(raw: bytes, key):
    envelope = json.loads(raw)
    payload = base64.b64decode(envelope["payload"], validate=True)
    signature = base64.b64decode(envelope["signature"], validate=True)
    key.verify(signature, payload, padding.PKCS1v15(), hashes.SHA256())
    return json.loads(payload)


def https_url(url):
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme != "https" or parsed.username or parsed.password or not parsed.hostname:
        raise ValueError("Updates require a public HTTPS URL")
    return url


def download(url, target: Path, maximum: int, progress=None):
    request = urllib.request.Request(https_url(url), headers={"User-Agent": "UmaPilot-Updater/1"})
    with urllib.request.urlopen(request, timeout=60) as response, target.open("wb") as output:
        https_url(response.url)
        count = 0
        while chunk := response.read(64 * 1024):
            count += len(chunk)
            if count > maximum:
                raise ValueError("Update download exceeds its declared size")
            output.write(chunk)
            if progress:
                progress(count)


def validate_release(release, previous):
    if release.get("format") != 1 or release.get("baseSequence") != previous or release.get("sequence") != previous + 1:
        raise ValueError("Incomplete or incompatible update sequence")
    seen = set()
    for entry in release["files"]:
        name = entry["path"]
        if not managed(name) or name.lower() in seen:
            raise ValueError("Unsafe or duplicate update path: " + name)
        seen.add(name.lower())
        for field in ("before", "after"):
            if entry[field] is not None and not re.fullmatch("[0-9a-f]{64}", entry[field]):
                raise ValueError("Invalid file hash")
        if entry["before"] == entry["after"] or not isinstance(entry["size"], int) or not 0 <= entry["size"] <= 2**31:
            raise ValueError("Invalid file change")


def extract_payload(archive: Path, release, destination: Path):
    expected = {f["path"]: f for f in release["files"] if f["after"] is not None}
    with zipfile.ZipFile(archive) as source:
        infos = source.infolist()
        if len(infos) != len(expected) or {i.filename for i in infos} != set(expected):
            raise ValueError("ZIP does not match the signed file list")
        for info in infos:
            entry = expected[info.filename]
            if info.file_size != entry["size"] or (info.external_attr >> 16) & 0o170000 == 0o120000:
                raise ValueError("Invalid ZIP member")
            if not managed(info.filename):
                raise ValueError("Unsafe ZIP path")
            target = safe_path(destination, info.filename)
            target.parent.mkdir(parents=True, exist_ok=True)
            with source.open(info) as incoming, target.open("wb") as output:
                shutil.copyfileobj(incoming, output)
            if digest(target) != entry["after"]:
                raise ValueError("Downloaded application file failed verification")


def check(root: Path, fetch=download, progress=None):
    work = safe_path(root, "work/updates")
    work.mkdir(parents=True, exist_ok=True)
    config = json.loads((root / "updates/channel.json").read_text(encoding="utf-8-sig"))
    if (root / ".git").exists():
        return {"state": "development", "message": "Automatic updates are disabled in the development checkout."}
    if not config.get("enabled", True):
        return {"state": "disabled", "message": "Automatic updates are disabled."}
    key = serialization.load_pem_public_key((root / "updates/public-key.pem").read_bytes())
    installed = json.loads((root / "updates/installed.json").read_text(encoding="utf-8-sig"))
    current = installed["sequence"]
    feed = work / "feed.download"
    report = progress or (lambda value: None)
    report({"state": "checking", "message": "Checking for updates…"})
    fetch(config["feedUrl"], feed, 4 * 1024 * 1024)
    index = verified(feed.read_bytes(), key)
    if index.get("format") != 1 or index["baseline"] != installed["baseline"]:
        raise ValueError("This update channel requires a different base installation")
    releases = index["releases"]
    if [r["sequence"] for r in releases] != list(range(1, len(releases) + 1)):
        raise ValueError("Update feed is missing a release")
    latest = len(releases)
    if latest < current:
        raise ValueError("Update feed is older than the installed version")
    if latest == current:
        return {"state": "current", "version": installed["version"], "message": "UmaPilot is up to date."}
    failed = work / "failed.json"
    if failed.exists() and json.loads(failed.read_text()).get("sequence") == latest:
        return {"state": "failed", "message": "The last update failed and was rolled back. Waiting for a newer release."}
    stage = work / "staged"
    if stage.exists():
        # Recheck/downloads are resumable. Never follow a substituted junction.
        if stage.is_symlink() or stage.is_junction():
            raise ValueError("Invalid update staging directory")
    stage.mkdir(exist_ok=True)
    pending = work / "pending.json"
    pending.unlink(missing_ok=True)
    manifests = []
    prepared = []
    for item in releases[current:]:
        sequence = item["sequence"]
        folder = safe_path(stage, str(sequence))
        folder.mkdir(exist_ok=True)
        manifest = folder / "manifest.json"
        fetch(item["manifestUrl"], manifest, 32 * 1024 * 1024)
        release = verified(manifest.read_bytes(), key)
        validate_release(release, sequence - 1)
        if release.get("baseline") != installed["baseline"]:
            raise ValueError("Release baseline does not match this installation")
        prepared.append((folder, release))
    total = sum(release['zipSize'] for _, release in prepared)
    completed = 0
    for folder, release in prepared:
        def downloading(count):
            downloaded = completed + count
            report({"state": "downloading", "version": releases[-1]['version'],
                    "downloadedBytes": downloaded, "totalBytes": total,
                    "percent": min(100, int(downloaded * 100 / max(1, total))),
                    "message": "Downloading update…"})
        downloading(0)
        payload = folder / "payload.zip"
        if not payload.exists() or digest(payload) != release["zipSha256"]:
            if fetch is download:
                download(release["zipUrl"], payload, release["zipSize"], downloading)
            else:
                fetch(release["zipUrl"], payload, release["zipSize"])
        if payload.stat().st_size != release["zipSize"] or digest(payload) != release["zipSha256"]:
            raise ValueError("Downloaded update failed verification")
        downloading(release['zipSize'])
        completed += release['zipSize']
        report({"state": "verifying", "version": releases[-1]['version'],
                "message": "Verifying update…", "percent": min(100, int(completed * 100 / max(1, total)))})
        extract_payload(payload, release, folder / "files")
        manifests.append("staged/" + str(release['sequence']) + "/manifest.json")
    atomic_json(pending, {"sequence": latest, "version": releases[-1]["version"], "manifests": manifests})
    return {"state": "ready", "version": releases[-1]["version"],
            "message": "Update downloaded. Quit UmaPilot, then open it again to install."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    args = parser.parse_args()
    work = args.root / "work/updates"
    work.mkdir(parents=True, exist_ok=True)
    # OS lock is released after a crash; a stale PID never blocks future checks.
    import msvcrt
    with (work / "check.lock").open("a+b") as lock:
        try:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError:
            return
        try:
            def report(value):
                atomic_json(work / "status.json", {**value, "checkedAt": time.time()})
            status = check(args.root.resolve(), progress=report)
        except Exception as error:
            status = {"state": "error", "message": "Update check failed: " + str(error)}
        status["checkedAt"] = time.time()
        atomic_json(work / "status.json", status)


if __name__ == "__main__":
    main()
