from __future__ import annotations

import base64
import ctypes
import hashlib
import json
import os
import tempfile
import threading
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Protocol


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class SecretProtector(Protocol):
    def protect(self, value: bytes) -> bytes: ...

    def unprotect(self, value: bytes) -> bytes: ...


class _DataBlob(ctypes.Structure):
    _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


class WindowsDpapiProtector:
    """Encrypt secrets for the current Windows user with DPAPI."""

    _entropy = b"UmaPilotAPI/account-profile/v1"

    def __init__(self) -> None:
        if os.name != "nt":
            raise OSError("Windows DPAPI is only available on Windows")

    @staticmethod
    def _blob(value: bytes) -> tuple[_DataBlob, Any]:
        buffer = (ctypes.c_ubyte * len(value)).from_buffer_copy(value)
        return _DataBlob(len(value), buffer), buffer

    def protect(self, value: bytes) -> bytes:
        source, source_buffer = self._blob(value)
        entropy, entropy_buffer = self._blob(self._entropy)
        output = _DataBlob()
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        if not crypt32.CryptProtectData(
            ctypes.byref(source),
            "UmaPilot Steam session",
            ctypes.byref(entropy),
            None,
            None,
            0x01,
            ctypes.byref(output),
        ):
            raise ctypes.WinError()
        try:
            return ctypes.string_at(output.pbData, output.cbData)
        finally:
            kernel32.LocalFree(output.pbData)
            del source_buffer, entropy_buffer

    def unprotect(self, value: bytes) -> bytes:
        source, source_buffer = self._blob(value)
        entropy, entropy_buffer = self._blob(self._entropy)
        output = _DataBlob()
        crypt32 = ctypes.windll.crypt32
        kernel32 = ctypes.windll.kernel32
        if not crypt32.CryptUnprotectData(
            ctypes.byref(source),
            None,
            ctypes.byref(entropy),
            None,
            None,
            0x01,
            ctypes.byref(output),
        ):
            raise ctypes.WinError()
        try:
            return ctypes.string_at(output.pbData, output.cbData)
        finally:
            kernel32.LocalFree(output.pbData)
            del source_buffer, entropy_buffer


@dataclass(slots=True)
class AccountProfile:
    id: str
    label: str
    status: str = "signed-out"
    steam_account_hint: str | None = None
    steam_id_fingerprint: str | None = None
    has_saved_session: bool = False
    created_at: str = ""
    updated_at: str = ""
    last_authenticated_at: str | None = None
    assigned_function: str = "pilot"

    def public(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "label": self.label,
            "status": self.status,
            "steamAccountHint": self.steam_account_hint,
            "steamIdFingerprint": self.steam_id_fingerprint,
            "hasSavedSession": self.has_saved_session,
            "createdAt": self.created_at,
            "updatedAt": self.updated_at,
            "lastAuthenticatedAt": self.last_authenticated_at,
            "assignedFunction": self.assigned_function,
        }


@dataclass(slots=True)
class GameAccountProfile:
    id: str
    steam_profile_id: str
    label: str
    trainer_id_hint: str
    trainer_id_fingerprint: str
    status: str = "stored-unverified"
    has_device_profile: bool = False
    device_profile_fingerprint: str | None = None
    device_profile_captured_at: str | None = None
    created_at: str = ""
    updated_at: str = ""

    def public(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "steamProfileId": self.steam_profile_id,
            "label": self.label,
            "trainerIdHint": self.trainer_id_hint,
            "trainerIdFingerprint": self.trainer_id_fingerprint,
            "status": self.status,
            "hasDeviceProfile": self.has_device_profile,
            "deviceProfileFingerprint": self.device_profile_fingerprint,
            "deviceProfileCapturedAt": self.device_profile_captured_at,
            "createdAt": self.created_at,
            "updatedAt": self.updated_at,
        }


class AccountProfileStore:
    """Persist non-secret profile metadata and separately protected Steam secrets."""

    def __init__(self, root: Path, protector: SecretProtector | None = None) -> None:
        self.root = root
        self.metadata_path = root / "profiles.json"
        self.game_metadata_path = root / "game-accounts.json"
        self.secrets_dir = root / "secrets"
        self.data_link_secrets_dir = root / "data-link-secrets"
        self.device_profiles_dir = root / "device-profiles"
        self.protector = protector or WindowsDpapiProtector()
        self.lock = threading.RLock()

    @staticmethod
    def _validate_id(profile_id: str) -> str:
        try:
            return uuid.UUID(profile_id).hex
        except (ValueError, AttributeError) as exc:
            raise ValueError("Invalid account profile id") from exc

    @staticmethod
    def _clean_label(label: str) -> str:
        cleaned = " ".join(str(label).split())
        if not 1 <= len(cleaned) <= 48:
            raise ValueError("Profile label must be between 1 and 48 characters")
        return cleaned

    @staticmethod
    def _account_hint(account_name: str) -> str:
        value = account_name.strip()
        if len(value) <= 3:
            return "*" * len(value)
        return f"{value[:2]}{'*' * min(8, len(value) - 3)}{value[-1]}"

    @staticmethod
    def _fingerprint(value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest()[:12]

    def _read(self) -> list[AccountProfile]:
        if not self.metadata_path.exists():
            return []
        raw = json.loads(self.metadata_path.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise ValueError("Account profile registry is malformed")
        allowed = set(AccountProfile.__dataclass_fields__)
        return [AccountProfile(**{key: value for key, value in item.items() if key in allowed}) for item in raw]

    def _atomic_write(self, path: Path, value: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        handle, temporary = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
        try:
            with os.fdopen(handle, "wb") as stream:
                stream.write(value)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)

    def _write(self, profiles: list[AccountProfile]) -> None:
        body = json.dumps([asdict(profile) for profile in profiles], indent=2).encode("utf-8")
        self._atomic_write(self.metadata_path, body)

    def _read_games(self) -> list[GameAccountProfile]:
        if not self.game_metadata_path.exists():
            return []
        raw = json.loads(self.game_metadata_path.read_text(encoding="utf-8"))
        if not isinstance(raw, list):
            raise ValueError("Game account registry is malformed")
        allowed = set(GameAccountProfile.__dataclass_fields__)
        return [
            GameAccountProfile(**{key: value for key, value in item.items() if key in allowed})
            for item in raw
        ]

    def _write_games(self, profiles: list[GameAccountProfile]) -> None:
        body = json.dumps([asdict(profile) for profile in profiles], indent=2).encode("utf-8")
        self._atomic_write(self.game_metadata_path, body)

    def list(self) -> list[AccountProfile]:
        with self.lock:
            return self._read()

    def get(self, profile_id: str) -> AccountProfile | None:
        normalized = self._validate_id(profile_id)
        with self.lock:
            return next((profile for profile in self._read() if profile.id == normalized), None)

    def create(self, label: str) -> AccountProfile:
        timestamp = _now()
        profile = AccountProfile(
            id=uuid.uuid4().hex,
            label=self._clean_label(label),
            created_at=timestamp,
            updated_at=timestamp,
        )
        with self.lock:
            profiles = self._read()
            profiles.append(profile)
            self._write(profiles)
        return profile

    def assign_function(self, profile_id: str, function: str) -> AccountProfile:
        if function not in {'pilot', 'janus'}:
            raise ValueError('Choose Pilot or Janus')
        normalized = self._validate_id(profile_id)
        with self.lock:
            profiles = self._read()
            profile = next((p for p in profiles if p.id == normalized), None)
            if profile is None:
                raise ValueError('Steam profile not found')
            profile.assigned_function = function
            profile.updated_at = _now()
            self._write(profiles)
            return profile

    def update_status(self, profile_id: str, status: str) -> AccountProfile:
        normalized = self._validate_id(profile_id)
        with self.lock:
            profiles = self._read()
            profile = next((item for item in profiles if item.id == normalized), None)
            if profile is None:
                raise KeyError("Account profile not found")
            profile.status = status
            profile.updated_at = _now()
            self._write(profiles)
            return profile

    def save_steam_session(
        self,
        profile_id: str,
        *,
        account_name: str,
        steam_id: str,
        refresh_token: str,
        machine_token: str | None,
    ) -> AccountProfile:
        normalized = self._validate_id(profile_id)
        if not refresh_token or refresh_token.count(".") != 2:
            raise ValueError("Steam did not return a valid refresh token")
        secret = json.dumps(
            {"refreshToken": refresh_token, "machineToken": machine_token},
            separators=(",", ":"),
        ).encode("utf-8")
        protected = self.protector.protect(secret)
        envelope = b"UMAPILOT-DPAPI-1\n" + base64.b64encode(protected)
        with self.lock:
            profiles = self._read()
            profile = next((item for item in profiles if item.id == normalized), None)
            if profile is None:
                raise KeyError("Account profile not found")
            self._atomic_write(self.secrets_dir / f"{normalized}.bin", envelope)
            timestamp = _now()
            profile.status = "ready"
            profile.steam_account_hint = self._account_hint(account_name)
            profile.steam_id_fingerprint = self._fingerprint(steam_id)
            profile.has_saved_session = True
            profile.last_authenticated_at = timestamp
            profile.updated_at = timestamp
            self._write(profiles)
            return profile

    def load_steam_session(self, profile_id: str) -> dict[str, Any]:
        normalized = self._validate_id(profile_id)
        envelope = (self.secrets_dir / f"{normalized}.bin").read_bytes()
        marker = b"UMAPILOT-DPAPI-1\n"
        if not envelope.startswith(marker):
            raise ValueError("Unknown Steam session secret format")
        clear = self.protector.unprotect(base64.b64decode(envelope[len(marker) :], validate=True))
        value = json.loads(clear)
        if not isinstance(value, dict) or not value.get("refreshToken"):
            raise ValueError("Steam session secret is malformed")
        return value

    def delete(self, profile_id: str) -> None:
        normalized = self._validate_id(profile_id)
        with self.lock:
            profiles = self._read()
            if not any(profile.id == normalized for profile in profiles):
                raise KeyError("Account profile not found")
            games = self._read_games()
            removed_games = [game for game in games if game.steam_profile_id == normalized]
            self._write([profile for profile in profiles if profile.id != normalized])
            self._write_games([game for game in games if game.steam_profile_id != normalized])
            (self.secrets_dir / f"{normalized}.bin").unlink(missing_ok=True)
            (self.root / "portable-devices" / f"{normalized}.bin").unlink(missing_ok=True)
            for game in removed_games:
                (self.data_link_secrets_dir / f"{game.id}.bin").unlink(missing_ok=True)
                (self.device_profiles_dir / f"{game.id}.bin").unlink(missing_ok=True)

    def list_game_accounts(self, steam_profile_id: str | None = None) -> list[GameAccountProfile]:
        normalized = self._validate_id(steam_profile_id) if steam_profile_id else None
        with self.lock:
            games = self._read_games()
        return [game for game in games if normalized is None or game.steam_profile_id == normalized]

    def save_data_link(
        self,
        steam_profile_id: str,
        *,
        label: str,
        trainer_id: str,
        link_password: str,
    ) -> GameAccountProfile:
        normalized = self._validate_id(steam_profile_id)
        trainer_id = trainer_id.strip()
        if not 9 <= len(trainer_id) <= 32 or any(character.isspace() for character in trainer_id):
            raise ValueError("Trainer ID must be between 9 and 32 characters without spaces")
        if not 8 <= len(link_password) <= 128:
            raise ValueError("Link password must be between 8 and 128 characters")
        with self.lock:
            steam_profile = next(
                (profile for profile in self._read() if profile.id == normalized), None
            )
            if steam_profile is None:
                raise KeyError("Steam profile not found")
            if not steam_profile.has_saved_session:
                raise RuntimeError("Finish Steam authentication before adding a game account")
            games = self._read_games()
            if sum(game.steam_profile_id == normalized for game in games) >= 12:
                raise RuntimeError("This Steam profile already has 12 game accounts")
            timestamp = _now()
            game = GameAccountProfile(
                id=uuid.uuid4().hex,
                steam_profile_id=normalized,
                label=self._clean_label(label),
                trainer_id_hint=(
                    f"{'*' * max(0, len(trainer_id) - 4)}{trainer_id[-4:]}"
                ),
                trainer_id_fingerprint=self._fingerprint(trainer_id),
                created_at=timestamp,
                updated_at=timestamp,
            )
            clear = json.dumps(
                {"trainerId": trainer_id, "linkPassword": link_password, "passwordFormat": "plain"},
                separators=(",", ":"),
            ).encode("utf-8")
            protected = self.protector.protect(clear)
            envelope = b"UMAPILOT-DATALINK-DPAPI-1\n" + base64.b64encode(protected)
            self._atomic_write(self.data_link_secrets_dir / f"{game.id}.bin", envelope)
            prior = next((g for g in games if g.steam_profile_id == normalized and g.trainer_id_fingerprint == game.trainer_id_fingerprint),None)
            if prior:
                # Updating recovery credentials preserves the verified target and its history.
                self._atomic_write(self.data_link_secrets_dir / f"{prior.id}.bin", envelope)
                (self.data_link_secrets_dir / f"{game.id}.bin").unlink(missing_ok=True)
                prior.updated_at = timestamp
                game = prior
            else:
                games.append(game)
            self._write_games(games)
            return game

    def load_data_link(self, game_account_id: str) -> dict[str, str]:
        normalized = self._validate_id(game_account_id)
        envelope = (self.data_link_secrets_dir / f"{normalized}.bin").read_bytes()
        marker = b"UMAPILOT-DATALINK-DPAPI-1\n"
        if not envelope.startswith(marker):
            raise ValueError("Unknown Data Link secret format")
        clear = self.protector.unprotect(
            base64.b64decode(envelope[len(marker) :], validate=True)
        )
        value = json.loads(clear)
        if not isinstance(value, dict) or not value.get("trainerId") or not value.get("linkPassword"):
            raise ValueError("Data Link secret is malformed")
        result = {"trainerId": str(value["trainerId"]), "linkPassword": str(value["linkPassword"])}
        if value.get('passwordFormat') in ('plain', 'wire'):
            result['passwordFormat'] = value['passwordFormat']
        return result

    def mark_data_link_verified(self, game_account_id: str) -> GameAccountProfile:
        normalized = self._validate_id(game_account_id)
        with self.lock:
            games = self._read_games()
            game = next((item for item in games if item.id == normalized), None)
            if game is None:
                raise KeyError("Game account not found")
            game.status = "linked-verified"
            game.updated_at = _now()
            self._write_games(games)
            return game

    @staticmethod
    def _validate_game_database(value: bytes) -> None:
        if not isinstance(value, bytes):
            raise TypeError("Game database must be bytes")
        if not value.startswith(b"SQLite format 3\x00"):
            raise ValueError("Game database is not a SQLite 3 database")
        if not 512 <= len(value) <= 16 * 1024 * 1024:
            raise ValueError("Game database size is outside the accepted safety range")

    def save_device_profile(
        self, game_account_id: str, database: bytes
    ) -> GameAccountProfile:
        """Store an encrypted SaveData.db snapshot for one game account."""

        normalized = self._validate_id(game_account_id)
        self._validate_game_database(database)
        protected = self.protector.protect(database)
        envelope = b"UMAPILOT-SAVEDB-DPAPI-1\n" + base64.b64encode(protected)
        with self.lock:
            games = self._read_games()
            game = next((item for item in games if item.id == normalized), None)
            if game is None:
                raise KeyError("Game account not found")
            self._atomic_write(self.device_profiles_dir / f"{normalized}.bin", envelope)
            timestamp = _now()
            game.has_device_profile = True
            game.device_profile_fingerprint = hashlib.sha256(database).hexdigest()[:12]
            game.device_profile_captured_at = timestamp
            game.updated_at = timestamp
            self._write_games(games)
            return game

    def load_device_profile(self, game_account_id: str) -> bytes:
        normalized = self._validate_id(game_account_id)
        envelope = (self.device_profiles_dir / f"{normalized}.bin").read_bytes()
        marker = b"UMAPILOT-SAVEDB-DPAPI-1\n"
        if not envelope.startswith(marker):
            raise ValueError("Unknown game database secret format")
        database = self.protector.unprotect(
            base64.b64decode(envelope[len(marker) :], validate=True)
        )
        self._validate_game_database(database)
        return database

    def delete_game_account(self, game_account_id: str) -> None:
        normalized = self._validate_id(game_account_id)
        with self.lock:
            games = self._read_games()
            if not any(game.id == normalized for game in games):
                raise KeyError("Game account not found")
            self._write_games([game for game in games if game.id != normalized])
            (self.data_link_secrets_dir / f"{normalized}.bin").unlink(missing_ok=True)
            (self.device_profiles_dir / f"{normalized}.bin").unlink(missing_ok=True)
