"""Remember connection intent independently of career automation."""
import json
from pathlib import Path

class ConnectionPreference:
    def __init__(self, root: Path):
        self.path = root / 'work/pilot-connection.json'

    def read(self):
        try:
            value = json.loads(self.path.read_text(encoding='utf-8'))
            return value if isinstance(value, dict) else {'enabled': False}
        except FileNotFoundError:
            return None
        except (OSError, ValueError):
            return {'enabled': False}

    def remember(self, profile_id):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temporary = self.path.with_suffix('.tmp')
        temporary.write_text(json.dumps({'enabled': bool(profile_id), 'profileId': profile_id}), encoding='utf-8')
        temporary.replace(self.path)

    def target(self, store, previous_profile=None):
        value = self.read()
        profile_id = (value.get('profileId') if value.get('enabled') else None) if value is not None else previous_profile
        if not profile_id:
            return None
        try:
            profile_id = store._validate_id(profile_id)
            profile = store.get(profile_id)
            if profile and profile.status == 'ready' and profile.has_saved_session and profile.assigned_function == 'pilot':
                return profile_id
        except (ValueError, OSError):
            pass
        return None
