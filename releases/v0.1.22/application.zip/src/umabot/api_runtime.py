"""Persistent account navigation with a single session owner and no UI dependency."""
from __future__ import annotations
import json
import os
import secrets
import time
from pathlib import Path
import msgpack
from umabot.account_snapshot import build_account_snapshot
from umabot.api_navigation import ApiNavigationError, career_state, preset_catalog, training_summary
from umabot.api_project import resolve_project
from umabot.api_launch import compile_launch
from umabot.api_guest import prepare_guest
from umabot.run_details import RunDetails, launch_details
from umabot.api_skills import plan_skills
from umabot.capture_catalog import shape
from umabot.portable_paths import master_database
from umabot import launch_diagnostic
from umabot import preset_store


class RuntimeCheckError(ValueError):
    """A deliberate, credential-free validation message safe for the dashboard."""


class ApiRuntime:
    def __init__(self, navigator, load: dict, root: Path):
        self.navigator = navigator
        self.load = load
        self.root = root
        self.pending = None
        self.run_details = RunDetails(root, getattr(navigator, "account_key", None))
        self.committed = False
        self.bootstrap_count = 0
        self.chara = None
        self.last_finished_id = None
        self.read_routes = []
        for endpoint in ('mission/index', 'team_stadium/index', 'friend/index', 'daily_race/resume'):
            try:
                if not navigator._fields(endpoint):
                    self.read_routes.append(endpoint)
            except (ApiNavigationError, AttributeError):
                pass

    def status(self) -> dict:
        valid = self.navigator.check_ownership()
        training = training_summary(self.load)
        if training:
            training['runDetails'] = self.run_details.current(training)
        return {'status': 'idle' if valid else 'handoff-required',
                'accountKey': getattr(self.navigator, 'account_key', None),
                'screen': career_state(self.load)['screen'], 'readOnly': not self.committed,
                'requestCount': self.navigator.request_count + self.bootstrap_count, 'sessionValid': valid,
                'executionBackend': 'api', 'training': training, 'readRoutes': self.read_routes}

    def snapshot(self) -> dict:
        snapshot = build_account_snapshot(msgpack.packb({'data': self.load}, use_bin_type=True),
                                      self.root / 'uma_api_capture/lookups')
        from datetime import datetime
        from umabot.training_watch import TrainingWatch, timestamp
        key = getattr(self.navigator, 'account_key', None)
        today = datetime.now().astimezone().date()
        runs = TrainingWatch(self.root / 'work/training-watch.json').read()['runs'].values()
        snapshot['account']['botRunsToday'] = sum(1 for run in runs if run.get('profileId') == key and run.get('state') == 'complete' and timestamp(run.get('completedAt') or run['checkAt']).astimezone().date() == today)
        snapshot['account']['accountKey'] = key
        return snapshot

    def execute(self, control: dict) -> dict:
        kind = control.get('type')
        if kind == 'saved-presets':
            if not self.navigator.check_ownership():
                raise ValueError('Reconnect the account before loading its presets')
            key = getattr(self.navigator, 'account_key', None)
            # Never invalidate a prepared launch or enter preparation during a career.
            if not self.pending:
                self.load = self.navigator.request('load/index')
            if self.pending or career_state(self.load)['active']:
                cached = preset_store.read(self.root, key)
                result = {**preset_catalog(self.load, {}), 'agendas': (cached or {}).get('agendas', []), 'mode': 'cached',
                    'message': ('Saved presets from this account. Refresh after the career ends to check for changes.'
                        if cached else 'Race agendas have not been loaded on this account yet. Refresh when the current career is collected.')}
            else:
                scenario = int(control.get('scenarioId') or 3)
                if scenario not in (self.load.get('single_mode_scenario_id_array') or []):
                    raise ValueError('The selected scenario is unavailable on this account')
                self.navigator.request('pre_single_mode/index')
                pre_start = self.navigator.request('idle_single_mode/pre_start', {'scenario_id': scenario},
                    authorized_effects=frozenset({'prepare'}))
                result = {**preset_catalog(self.load, pre_start), 'mode': 'live'}
                preset_store.save(self.root, key, result)
            return {'type': kind, 'data': result, **self.status()}
        if kind == 'test-tp-bottle':
            if control.get('authorizeOneBottle') is not True:
                raise ValueError('One TP bottle requires explicit authorization')
            from umabot.tp_refill import refill
            self.pending = None
            self.load = self.navigator.request('load/index')
            self.load, result = refill(self.navigator, self.load, {'enabled': True, 'source': 'bottles'})
            return {'type': kind, 'data': result, **self.status()}
        if kind == 'refill-tp':
            from umabot.tp_refill import settings, refill
            self.pending = None
            self.load = self.navigator.request('load/index')
            self.load, result = refill(self.navigator, self.load, settings(self.root))
            return {'type': kind, 'data': result, **self.status()}
        if kind == 'status':
            return {'type': kind, **self.status()}
        if kind == 'snapshot':
            return {'type': kind, 'data': self.snapshot(), **self.status()}
        if kind == 'refresh':
            self.pending = None
            self.load = self.navigator.request('load/index')
            return {'type': kind, 'data': self.snapshot(), **self.status()}
        if kind in {'career-presets', 'project-draft'}:
            policy_path = self.root / 'work/legacy-rental-policy.json'
            allow_paid_rentals = policy_path.exists() and json.loads(policy_path.read_text(encoding='utf-8')).get('allowMoniesRentals') is True
            self.pending = None
            self.load = self.navigator.request('load/index')
            if career_state(self.load)['active']:
                raise ValueError('A career is already active; refresh its state before preparing another')
            if control.get('authorizePrepare') is not True:
                raise ValueError('Career preparation has not been authorized')
            scenario = int(control.get('scenarioId') or 0)
            if scenario not in (self.load.get('single_mode_scenario_id_array') or []):
                raise ValueError('Scenario is unavailable on this account')
            choices = self.navigator.request('pre_single_mode/index')
            if kind == 'project-draft':
                choices = prepare_guest(self.navigator, control['project'], control.get('trainees') or [],
                    control.get('guests') or [], self.load, choices, allow_paid_rentals=allow_paid_rentals)
            pre_start = self.navigator.request('idle_single_mode/pre_start', {'scenario_id': scenario},
                                               authorized_effects=frozenset({'prepare'}))
            preset_store.save(self.root, getattr(self.navigator, 'account_key', None),
                preset_catalog(self.load, pre_start))
            if kind == 'career-presets':
                result = {**preset_catalog(self.load, pre_start), 'mode': 'live'}
            else:
                result = resolve_project(control['project'], control.get('trainees') or [],
                    control.get('guests') or [], self.load, choices, pre_start, self.root / 'ui/public/data', allow_paid_rentals=allow_paid_rentals)
                result['blockers'].remove('Live launch compilation has not been checked')
                try:
                    master = master_database()
                    payload = compile_launch(control['project'], control.get('trainees') or [],
                        control.get('guests') or [], self.load, choices, pre_start, master, allow_paid_rentals=allow_paid_rentals)
                    if not result['blockers']:
                        token = secrets.token_urlsafe(24)
                        try:
                            diagnostic = launch_diagnostic.describe(payload, self.load, choices)
                            try:
                                diagnostic = launch_diagnostic.describe(payload, self.load, choices,
                                    project=control['project'], pre_start=pre_start, master=master)
                            except Exception:
                                diagnostic['contextAvailable'] = False
                        except (ValueError, TypeError, KeyError, AttributeError, OSError):
                            diagnostic = None
                        self.pending = {'token': token, 'expires': time.monotonic() + 120,
                            'payload': payload, 'projectRevision': result['projectRevision'],
                            'diagnostic': diagnostic,
                            'runDetails': launch_details(control['project'], control.get('trainees') or [],
                                control.get('guests') or [], self.load, choices, payload, allow_paid_rentals=allow_paid_rentals)}
                        result.update(launchToken=token, launchExpiresInSeconds=120,
                            launchCost={'tp': 30, 'monies': None if allow_paid_rentals and payload['single_mode_start_request_common']['start_chara']['rental_succession_trained_chara']['viewer_id'] else 0, 'premium': 0},
                            finalRaceCount=len(payload['start_info']['race_array']))
                except (ValueError, OSError, KeyError) as exc:
                    # Compiler errors contain only local policy descriptions, never session data.
                    if getattr(exc, 'retry_seconds', None) and not result['blockers']:
                        result['resourceRetrySeconds'] = exc.retry_seconds
                    result['blockers'].append(str(exc) if isinstance(exc, ValueError)
                                              else 'Live setup data or game master data is incomplete')
                result['readyForStart'] = not result['blockers']
                if choices.get('_pilotVerifiedGuest'):
                    result['verifiedGuest'] = choices['_pilotVerifiedGuest']
            return {'type': kind, 'data': result, **self.status()}
        if kind == 'start-project':
            pending = self.pending
            if (control.get('authorizeStart') is not True or not pending or
                    not secrets.compare_digest(str(control.get('launchToken') or ''), pending['token']) or
                    control.get('projectRevision') != pending['projectRevision'] or
                    time.monotonic() > pending['expires']):
                raise ValueError('Prepare the current project again before starting')
            # Consume before sending. A timeout must never replay the start.
            self.pending = None
            self.committed = True
            diagnostic = pending.get('diagnostic')
            launch_diagnostic.save(self.root, diagnostic, 'sending')
            try:
                data = self.navigator.request('idle_single_mode/start', pending['payload'],
                                              authorized_effects=frozenset({'commit'}))
            except Exception:
                response = getattr(self.navigator, 'last_response_summary', None)
                launch_diagnostic.save(self.root, diagnostic, 'rejected' if response else 'outcome-unknown', response)
                if response and response.get('responseCode') == 205:
                    raise ApiNavigationError('Game rejected the training setup (205). Download the start diagnostic from the Pilot log for the exact selected setup.') from None
                raise
            launch_diagnostic.save(self.root, diagnostic, 'accepted', getattr(self.navigator, 'last_response_summary', None))
            progress = data.get('progress_info') or {}
            if not progress:
                self.navigator.valid = False
                raise ValueError('Start outcome needs reconciliation; do not launch again')
            self.load['idle_single_mode_load_info'] = progress
            self.load['tp_info'] = data.get('tp_info', self.load.get('tp_info'))
            self.run_details.save(training_summary(self.load), pending.get('runDetails'))
            return {'type': kind, 'data': {'started': True, 'projectRevision': pending['projectRevision'],
                    'startTime': progress.get('start_time'), 'endTime': progress.get('end_time')}, **self.status()}
        if kind == 'read-navigation':
            endpoint = control.get('endpoint')
            if endpoint not in self.read_routes:
                raise ValueError('Navigation read is not available')
            data = self.navigator.request(endpoint)
            return {'type': kind, 'data': {'endpoint': endpoint, 'shape': shape(data)}, **self.status()}
        if kind == 'collect-career':
            if control.get('authorizeComplete') is not True:
                raise RuntimeCheckError('Completed-training collection is not authorized')
            self.load=self.navigator.request('load/index')
            summary=training_summary(self.load)
            if not summary or not summary['scheduledEndReached']:
                raise RuntimeCheckError('Independent Training has not reached its end time')
            light=(self.load.get('idle_single_mode_load_info') or {}).get('single_mode_chara_light') or {}
            if light.get('turn') != 78:
                self.navigator.request('idle_single_mode/end',authorized_effects=frozenset({'complete-training'}))
                self.load=self.navigator.request('load/index')
            return {'type':kind,**self.status()}
        if kind == 'finish-untracked':
            if control.get('authorizeFinish') is not True:
                raise RuntimeCheckError('Standalone career completion is not authorized')
            self.load = self.navigator.request('load/index')
            summary = training_summary(self.load) or {}
            if (summary.get('cardId') != control.get('expectedCardId') or
                    summary.get('startTime') != control.get('expectedStartTime') or
                    not summary.get('scheduledEndReached') or summary.get('scenarioId') not in (1, 3)):
                raise RuntimeCheckError('The ended career does not match the authorized standalone run')
            self.execute({'type': 'collect-career', 'authorizeComplete': True})
            result = self.navigator.request('idle_single_mode/result')
            end = result.get('end_info') or {}
            chara = end.get('chara_info') or {}
            if chara.get('card_id') != summary['cardId'] or chara.get('scenario_id') != summary['scenarioId']:
                raise RuntimeCheckError('Standalone career result identity changed')
            from umabot.api_finish import finish_career
            self.committed = True
            completed = finish_career(self.navigator, chara, end, allowed_scenarios=(1, 3))
            self.load = completed.pop('load')
            self.chara = None
            return {'type': kind, 'data': {'verified': completed['verified'],
                'cardId': chara['card_id'], 'veteranId': completed['veteran']['trained_chara_id'],
                'retainedSkills': len(completed['skillIds']), 'unusedSkillPoints': completed['remainingSkillPoints']}, **self.status()}
        if kind == 'finish-career':
            if control.get('authorizeFinish') is not True:
                raise RuntimeCheckError('Career finalization is not authorized')
            check=self.execute({'type':'plan-skills','project':control['project']})
            if check['data']['skills']:
                raise RuntimeCheckError('Affordable skills remain; complete the skill policy first')
            from umabot.api_finish import finish_career
            latest=self.navigator.request('idle_single_mode/result')
            end=latest.get('end_info') or {}
            chara=end.get('chara_info') or {}
            if chara != self.chara:
                raise RuntimeCheckError('Career state changed before finalization')
            self.committed=True
            completed=finish_career(self.navigator,chara,end)
            self.load=completed.pop('load')
            self.last_finished_id = completed['veteran']['trained_chara_id']
            self.chara=None
            return {'type':kind,'data':completed,**self.status()}
        if kind == 'mark-project-veteran':
            veteran_id = control.get('veteranId')
            if (control.get('authorizeSticker') is not True or
                    veteran_id != self.last_finished_id or not veteran_id):
                raise RuntimeCheckError('Only the just-verified veteran can receive the configured project sticker')
            from umabot.api_veteran import protect_veteran
            self.load = protect_veteran(self.navigator, self.load, veteran_id, control.get('sticker', 'carrot'))
            return {'type': kind, 'data': {'stickerApplied': True}, **self.status()}
        if kind in {'plan-skills','buy-skills'}:
            self.load = self.navigator.request('load/index')
            light = (self.load.get('single_mode_chara_light') or
                     (self.load.get('idle_single_mode_load_info') or {}).get('single_mode_chara_light') or {})
            if self.load.get('idle_single_mode_load_info') and int(light.get('turn') or 0) == 78:
                result = self.navigator.request('idle_single_mode/result')
                self.chara = (result.get('end_info') or {}).get('chara_info')
            if not self.chara or any(self.chara.get(k) != light.get(k) for k in
                    ('single_mode_chara_id','card_id','turn','skill_point')):
                fields = [k for k in ('single_mode_chara_id','card_id','turn','skill_point')
                          if not self.chara or self.chara.get(k) != light.get(k)]
                raise RuntimeCheckError('Fresh full career state is required; mismatch in ' + ', '.join(fields))
            master = master_database()
            plan = plan_skills(control['project'], self.chara, master, self.root/'ui/public/data')
            if kind == 'plan-skills':
                return {'type':kind,'data':plan, **self.status()}
            if control.get('authorizeSkillPoints') is not True:
                raise ValueError('Career skill-point spending is not authorized')
            if not plan['skills']:
                return {'type':kind,'data':{**plan,'learned':[]}, **self.status()}
            payload = {'gain_skill_info_array':[{'skill_id':s['skillId'],'level':s['level']} for s in plan['skills']],
                       'current_turn':plan['currentTurn']}
            self.committed = True
            data = self.navigator.request('single_mode_live/gain_skills', payload,
                                          authorized_effects=frozenset({'learn-skills'}))
            updated = data.get('chara_info') or {}
            if (updated.get('single_mode_chara_id') != self.chara.get('single_mode_chara_id') or
                    not {s['skillId'] for s in plan['skills'] if not s['prerequisite']}.issubset(
                        {s['skill_id'] for s in updated.get('skill_array') or []})):
                self.navigator.valid = False
                raise RuntimeCheckError('Skill purchase outcome needs reconciliation; do not retry')
            before = int(self.chara['skill_point'])
            self.chara = updated
            return {'type':kind,'data':{'learned':plan['skills'],'skillPointsBefore':before,
                    'skillPointsAfter':updated['skill_point'],'spent':before-updated['skill_point']}, **self.status()}
        raise ValueError('Unknown API runtime command')


def serve(runtime: ApiRuntime, incoming, outgoing):
    def emit(value):
        outgoing.write(json.dumps(value, separators=(',', ':')) + '\n')
        outgoing.flush()
    runtime.navigator.on_retry = emit
    emit({'type': 'ready', **runtime.status(), 'snapshotSummary': runtime.snapshot()['counts']})
    for line in incoming:
        try:
            control = json.loads(line)
            if not isinstance(control, dict):
                raise ValueError('Command must be an object')
            if control.get('type') == 'close':
                break
            emit(runtime.execute(control))
        except Exception as exc:
            emit({'type': 'error', 'error': str(exc) if isinstance(exc, (RuntimeCheckError, ApiNavigationError)) else 'API operation stopped; check session ownership and reviewed request data',
                  **runtime.status()})
    emit({'type': 'closed', 'status': 'disconnected'})
