"""Allowlisted start diagnostics: game choices, never authentication material."""
import json
import hashlib
import sqlite3
import uuid
from datetime import datetime, timezone
from pathlib import Path
from umabot.runtime_version import source_version

def numbers(record, fields):
    return {key: record[key] for key in fields if type(record.get(key)) in (int, bool)}

def veteran(record):
    value = numbers(record, ('trained_chara_id', 'card_id', 'rank_score', 'use_type', 'position_id'))
    value['win_saddle_id_array'] = [v for v in record.get('win_saddle_id_array', []) if type(v) is int]
    value['parents'] = [veteran_parent(v) for v in record.get('succession_chara_array', []) if v.get('position_id') in (10, 20)]
    return value

def veteran_parent(record):
    value = numbers(record, ('trained_chara_id', 'card_id', 'position_id'))
    value['win_saddle_id_array'] = [v for v in record.get('win_saddle_id_array', []) if type(v) is int]
    return value

def describe(payload, load, choices, *, project=None, pre_start=None, master=None):
    common = payload.get('single_mode_start_request_common') or {}
    start = common.get('start_chara') or {}
    info = payload.get('start_info') or {}
    rental = start.get('rental_succession_trained_chara') or {}
    friend = start.get('friend_support_card_info') or {}
    own = load.get('trained_chara') or []
    guests = (choices.get('succession_trained_chara_data') or {}).get('succession_trained_chara_array') or []
    parents = []
    for position in (1, 2):
        owned_id = start.get(f'succession_trained_chara_id_{position}')
        matches = ([v for v in own if v.get('trained_chara_id') == owned_id] if owned_id else
            [v for v in guests if v.get('trained_chara_id') == rental.get('trained_chara_id') and
             (v.get('viewer_id') or v.get('owner_viewer_id')) == rental.get('viewer_id')])
        parents.append({'position': position, 'borrowed': not bool(owned_id), 'matches': [veteran(v) for v in matches]})
    report = {'schemaVersion': 2, 'attemptId': uuid.uuid4().hex,
        'preparedAt': datetime.now(timezone.utc).isoformat(),
        'version': source_version(), 'phase': 'prepared',
        'startChara': {**numbers(start, ('card_id', 'scenario_id', 'select_deck_id', 'running_style',
            'succession_trained_chara_id_1', 'succession_trained_chara_id_2', 'boost_story_event_id',
            'boost_factor_research_event_id', 'is_play_training_challenge', 'training_challenge_mode')),
            'support_card_ids': [v for v in start.get('support_card_ids', []) if type(v) is int],
            'friend_support_card_info': numbers(friend, ('support_card_id',)),
            'rental_succession_trained_chara': numbers(rental, ('trained_chara_id', 'is_circle_member', 'is_event_rental')),
            'selected_difficulty_info': numbers(start.get('selected_difficulty_info') or {}, ('difficulty_id', 'difficulty', 'is_boost'))},
        'resources': {**numbers(common, ('current_money', 'use_tp', 'current_succession_rank_point')),
            'tp_info': numbers(common.get('tp_info') or {}, ('current_tp', 'max_tp', 'recovery_time', 'max_recovery_time'))},
        'startInfo': {**numbers(info, ('training_policy_ground_type', 'training_policy_param_rate_set_id')),
            'priority_skill_array': [numbers(v, ('priority', 'skill_id')) for v in info.get('priority_skill_array', [])],
            'race_array': [numbers(v, ('year', 'program_id')) for v in info.get('race_array', [])]},
        'parents': parents,
        'ownedSupports': [numbers(v, ('support_card_id', 'limit_break_count', 'exp')) for v in load.get('support_card_list', []) if v.get('support_card_id') in start.get('support_card_ids', [])],
        'borrowedSupport': [numbers(v, ('support_card_id', 'limit_break_count', 'exp')) for v in
            (choices.get('friend_support_card_data') or {}).get('support_card_data_array', [])
            if v.get('support_card_id') == friend.get('support_card_id') and v.get('viewer_id') == friend.get('viewer_id')]}

    report['trainee'] = [numbers(v, ('card_id', 'rarity', 'talent_level'))
                         for v in load.get('card_list', []) if v.get('card_id') == start.get('card_id')]
    report['selectionChecks'] = {
        'ownedParentMatchCounts': [len(p['matches']) for p in parents],
        'borrowedSupportMatchCount': len(report['borrowedSupport']),
        'supportCount': len(start.get('support_card_ids') or []),
        'distinctSupportCount': len(set(start.get('support_card_ids') or [])),
        'scenarioAvailable': start.get('scenario_id') in (load.get('single_mode_scenario_id_array') or []),
    }
    if project is not None:
        plan = project.get('loopPlan') or {}
        report['loopState'] = numbers(plan, ('pairStep', 'pairCycle', 'currentSlot', 'buildSeedParent', 'pairSeedPending'))
        report['loopState']['role'] = (project.get('checkpoint') or {}).get('role') if (project.get('checkpoint') or {}).get('role') in ('A', 'B', 'C', 'D') else None
    if project is not None and pre_start is not None:
        from umabot.api_navigation import resolve_project_presets
        presets = resolve_project_presets(project, load, pre_start)
        report['savedAgenda'] = [numbers(v, ('year', 'program_id')) for v in presets['savedRaceArray']]
    if master is not None:
        report['masterSha256'] = hashlib.sha256(Path(master).read_bytes()).hexdigest()
        with sqlite3.connect(Path(master).resolve().as_uri() + '?mode=ro', uri=True) as db:
            db.row_factory = sqlite3.Row
            program_fields = ('id', 'base_program_id', 'program_group', 'race_instance_id', 'race_permission', 'month', 'half')
            report['racePrograms'] = [numbers(dict(v), program_fields) for race in info.get('race_array', [])
                for v in db.execute('select * from single_mode_program where id=?', (race.get('program_id'),))]
            report['goalRoutes'] = [numbers(dict(v), ('race_set_id', 'sort_id', 'turn', 'condition_id',
                'determine_race', 'determine_race_for_generate', 'scenario_group_id', 'target_type'))
                for v in db.execute('select r.* from single_mode_route_race r join single_mode_route t on r.race_set_id=t.race_set_id where t.chara_id=? and t.scenario_id in (0,?) and r.target_type=1 order by r.sort_id',
                                    (int(start.get('card_id') or 0)//100, start.get('scenario_id')))]
    return report


def save(root: Path, report, phase, response=None):
    if report is None:
        return
    report.update(phase=phase, recordedAt=datetime.now(timezone.utc).isoformat())
    if response:
        report['response'] = numbers(response, ('responseCode', 'resultCode'))
    path = root / 'work/diagnostics/last-pilot-start.json'
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix('.tmp')
        temp.write_text(json.dumps(report, indent=2), encoding='utf-8')
        temp.replace(path)
        # Keep each attempt, including successful starts, for later comparison.
        attempt = report.get('attemptId')
        if isinstance(attempt, str) and len(attempt) == 32 and all(c in '0123456789abcdef' for c in attempt):
            history = path.parent / 'starts'
            history.mkdir(exist_ok=True)
            destination = history / (attempt + '.json')
            pending = destination.with_suffix('.tmp')
            pending.write_text(json.dumps(report, indent=2), encoding='utf-8')
            pending.replace(destination)
    except OSError:
        pass  # Diagnostics cannot change or replay the outcome of a start.
