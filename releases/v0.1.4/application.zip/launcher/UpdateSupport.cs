using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.NetworkInformation;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Web.Script.Serialization;

internal static class UpdateSupport {
    internal static readonly JavaScriptSerializer Json = new JavaScriptSerializer { MaxJsonLength = 48 * 1024 * 1024 };
    internal static string Id(string root) { using (var h=SHA256.Create()) return BitConverter.ToString(h.ComputeHash(Encoding.UTF8.GetBytes(root.ToUpperInvariant()))).Replace("-", ""); }
    internal static string Work(string root) { return Path.Combine(root, "work", "updates"); }
    internal static Dictionary<string,object> Read(string path) { return Json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path)); }
    internal static int Number(Dictionary<string,object> value, string field) { return Convert.ToInt32(value[field]); }
    internal static string Hash(string path) { if (!File.Exists(path)) return null; using(var s=File.OpenRead(path)) using(var h=SHA256.Create()) return BitConverter.ToString(h.ComputeHash(s)).Replace("-", "").ToLowerInvariant(); }
    internal static string Quote(string s) { return "\"" + s.Replace("\"", "\\\"") + "\""; }
    internal static bool PortsFree() { foreach(var endpoint in IPGlobalProperties.GetIPGlobalProperties().GetActiveTcpListeners()) if (endpoint.Port==3100 || endpoint.Port==8767 || endpoint.Port==8769 || endpoint.Port==8770) return false; return true; }
    internal static bool Installing(string root) { Mutex m; if (!Mutex.TryOpenExisting("Local\\UmaPilotInstall-" + Id(root), out m)) return false; m.Dispose(); return true; }
    internal static void Write(string path, object value) {
        Directory.CreateDirectory(Path.GetDirectoryName(path));
        string temp=path + ".new"; File.WriteAllText(temp, Json.Serialize(value), new UTF8Encoding(false));
        if(File.Exists(path)) File.Replace(temp,path,null); else File.Move(temp,path);
    }
    internal static string SafePath(string root, string relative) {
        if(String.IsNullOrEmpty(relative) || relative.Contains("\\") || relative.Contains(":")) throw new IOException("Invalid update path");
        foreach(string part in relative.Split('/')) {
            if(part=="" || part=="." || part==".." || part.TrimEnd('.', ' ')!=part || System.Text.RegularExpressions.Regex.IsMatch(part,@"^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$",System.Text.RegularExpressions.RegexOptions.IgnoreCase)) throw new IOException("Invalid update path");
        }
        string result=Path.GetFullPath(Path.Combine(root,relative.Replace('/',Path.DirectorySeparatorChar)));
        if(!result.StartsWith(Path.GetFullPath(root).TrimEnd('\\')+"\\",StringComparison.OrdinalIgnoreCase)) throw new IOException("Update path escapes installation");
        string probe=result;
        while(probe!=null) {
            if((File.Exists(probe)||Directory.Exists(probe)) && (File.GetAttributes(probe)&FileAttributes.ReparsePoint)!=0) throw new IOException("Update path contains a link");
            if(String.Equals(probe,Path.GetPathRoot(probe),StringComparison.OrdinalIgnoreCase)) break;
            probe=Path.GetDirectoryName(probe);
        }
        return result;
    }
    internal static bool Managed(string name) {
        string[] exact={"UmaPilot.exe","UmaPilotUpdater.exe","requirements-portable.txt","pyproject.toml","START-UMA-PILOT.cmd","START-JANUS.cmd","START-MERCURY.cmd","CHECK-PORTABILITY.cmd","ui/public/data/sparks.json","ui/public/data/umas.json","ui/package.json"};
        string[] prefixes={"src/","scripts/","launcher/","resources/","assets/","vendor/","Converter/",".runtime/","ui/dist/","ui/node_modules/","ui/public/data/planner/","ui/public/janus/","ui/public/uma-tools/","ui/public/umalator/","ui/public/images/"};
        foreach(string part in name.Split('/')) if(part.StartsWith(".env",StringComparison.OrdinalIgnoreCase) || Array.IndexOf(new[]{".git","__pycache__",".cache",".pytest_cache",".next",".wrangler",".vinext"},part)>=0) return false;
        foreach(string suffix in new[]{".log",".pyc",".pyo",".sqlite",".db",".dpapi"}) if(name.EndsWith(suffix,StringComparison.OrdinalIgnoreCase)) return false;
        if(Array.IndexOf(exact,name)>=0) return true;
        foreach(string prefix in prefixes) if(name.StartsWith(prefix,StringComparison.Ordinal)) return true;
        return false;
    }
    internal static Dictionary<string,object> Verify(string path) {
        var envelope=Read(path); byte[] body=Convert.FromBase64String((string)envelope["payload"]), signature=Convert.FromBase64String((string)envelope["signature"]);
        using(var rsa=new RSACryptoServiceProvider()) {
            using(var stream=typeof(UpdateSupport).Assembly.GetManifestResourceStream("UpdatePublicKey"))
            using(var reader=new StreamReader(stream)) rsa.FromXmlString(reader.ReadToEnd());
            if(!rsa.VerifyData(body,CryptoConfig.MapNameToOID("SHA256"),signature)) throw new IOException("Update signature is invalid");
        }
        return Json.Deserialize<Dictionary<string,object>>(Encoding.UTF8.GetString(body));
    }
    internal static bool CanCheckBeforeStart(string root) {
        if(Directory.Exists(Path.Combine(root,".git")) || !PortsFree()) return false;
        string config=Path.Combine(root,"updates","channel.json");
        if(!File.Exists(config)) return false;
        try { var channel=Read(config); return !channel.ContainsKey("enabled") || Convert.ToBoolean(channel["enabled"]); }
        catch { return false; }
    }
    internal static bool CheckBeforeStart(string root, Action<string,int> progress, Func<bool> cancelled, int timeoutMilliseconds=120000) {
        if(!CanCheckBeforeStart(root)) return true;
        string work=Work(root);Directory.CreateDirectory(work);
        Process check=null;
        try {
            progress("checking",0);
            check=Process.Start(new ProcessStartInfo(Path.Combine(root,".runtime","python","python.exe")) {
                Arguments="-B -m umabot.update_client --root "+Quote(root)+" --wait-for-lock 60",
                WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden
            });
            var elapsed=Stopwatch.StartNew();
            while(!check.WaitForExit(150)) {
                if(cancelled()) { check.Kill();check.WaitForExit();return false; }
                if(elapsed.ElapsedMilliseconds>=timeoutMilliseconds) {
                    check.Kill();check.WaitForExit();throw new IOException("Startup update check timed out; opening the installed version.");
                }
                try {
                    var status=Read(Path.Combine(work,"status.json"));string state=(string)status["state"];
                    if(state=="checking"||state=="downloading"||state=="verifying")
                        progress(state,status.ContainsKey("percent")?Number(status,"percent"):0);
                } catch(IOException) {} catch(ArgumentException) {} catch(KeyNotFoundException) {}
            }
            if(cancelled()) return false;
            if(check.ExitCode!=0) throw new IOException("Startup update check failed; opening the installed version.");
            return true;
        } catch(Exception ex) {
            File.AppendAllText(Path.Combine(work,"startup.log"),DateTime.UtcNow.ToString("s")+" "+ex.Message+Environment.NewLine);
            Write(Path.Combine(work,"status.json"),new {state="error",message="Update check failed. The installed version is starting."});
            progress("error",0);
            return !cancelled();
        } finally { if(check!=null) check.Dispose(); }
    }
    // Installation happens before services start; reused/CMD services are never stopped.
    internal static bool LaunchInstaller(string root) {
        string work=Work(root);
        if(Directory.Exists(Path.Combine(root,".git"))) return false;
        bool recovery=File.Exists(Path.Combine(work,"transaction.json"));
        if(!File.Exists(Path.Combine(root,"UmaPilotUpdater.exe"))) {
            if(recovery) throw new IOException("The initial updater setup was interrupted. Run Enable-Automatic-Updates.exe again to recover.");
            return false;
        }
        if(!recovery && !File.Exists(Path.Combine(work,"pending.json"))) return false;
        if(!PortsFree()) return false;
        string helper=Path.Combine(work,"helper",Guid.NewGuid().ToString("N")); Directory.CreateDirectory(helper);
        string exe=Path.Combine(helper,"UmaPilotUpdater.exe"); File.Copy(Path.Combine(root,"UmaPilotUpdater.exe"),exe);
        using(var handshake=new EventWaitHandle(false,EventResetMode.AutoReset,"Local\\UmaPilotInstallReady-"+Id(root))) {
            Process.Start(new ProcessStartInfo(exe) { Arguments=Quote(root)+" "+Process.GetCurrentProcess().Id, UseShellExecute=false,CreateNoWindow=true,WindowStyle=ProcessWindowStyle.Hidden,WorkingDirectory=root });
            if(!handshake.WaitOne(10000)) throw new IOException("The update installer did not start. See work\\updates\\installer.log.");
        }
        return true;
    }
}
