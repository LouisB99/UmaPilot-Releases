$ErrorActionPreference='Stop'
$root=Split-Path -Parent $PSScriptRoot
$compiler=Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
if(-not(Test-Path -LiteralPath $compiler)){throw 'Windows .NET Framework 4 compiler is required to build the launcher.'}
Add-Type -AssemblyName System.Drawing
$bitmap=New-Object System.Drawing.Bitmap 64,64
$graphics=[System.Drawing.Graphics]::FromImage($bitmap)
$graphics.SmoothingMode=[System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$graphics.Clear([System.Drawing.Color]::FromArgb(24,32,32))
$pen=New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(130,205,181)),4
$graphics.DrawRectangle($pen,15,22,34,27)
$graphics.DrawLine($pen,32,14,32,22)
$graphics.DrawEllipse($pen,29,8,6,6)
$graphics.DrawLine($pen,9,30,15,30);$graphics.DrawLine($pen,49,30,55,30)
$brush=New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(130,205,181))
$graphics.FillEllipse($brush,22,30,5,5);$graphics.FillEllipse($brush,37,30,5,5)
$graphics.DrawLine($pen,25,42,39,42)
$icon=[System.Drawing.Icon]::FromHandle($bitmap.GetHicon())
$iconPath=Join-Path $root 'launcher/UmaPilot.ico'
$stream=[System.IO.File]::Create($iconPath)
try{$icon.Save($stream)}finally{$stream.Dispose();$icon.Dispose();$brush.Dispose();$pen.Dispose();$graphics.Dispose();$bitmap.Dispose()}
$publicKey=Join-Path $root 'updates/public-key.xml'
if(-not(Test-Path -LiteralPath $publicKey)){throw 'Initialize the update publisher before building the signed-update launcher.'}
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:System.Web.Extensions.dll ("/resource:"+$publicKey+',UpdatePublicKey') ("/win32icon:"+$iconPath) ("/win32manifest:"+(Join-Path $root 'launcher/app.manifest')) ("/out:"+(Join-Path $root 'UmaPilot.exe')) (Join-Path $root 'launcher/UmaPilot.cs') (Join-Path $root 'launcher/UpdateSupport.cs') (Join-Path $root 'launcher/StartupUpdateWindow.cs')
if($LASTEXITCODE -ne 0){throw 'Launcher compilation failed'}
& $compiler /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Web.Extensions.dll ("/resource:"+$publicKey+',UpdatePublicKey') ("/win32icon:"+$iconPath) ("/win32manifest:"+(Join-Path $root 'launcher/app.manifest')) ("/out:"+(Join-Path $root 'UmaPilotUpdater.exe')) (Join-Path $root 'launcher/UmaPilotUpdater.cs') (Join-Path $root 'launcher/UpdateSupport.cs')
if($LASTEXITCODE -ne 0){throw 'Updater compilation failed'}
Write-Host 'Built UmaPilot.exe (Windows GUI, no console window).'
