"""Authoritative dashboard files, with optimistic concurrency across browsers."""
import base64
import hashlib
import json
from pathlib import Path

from .account_profiles import WindowsDpapiProtector
from .project_repository import ProjectRepository

PROJECT_KEYS = {'uma-pilot-official:projects:v2': 'store',
    'uma-pilot-official:trainees:v1': 'trainees', 'uma-pilot-official:guests:v1': 'guests'}
SECRET_KEY = 'uma-pilot-official:uma-moe-api-key'


class StorageConflict(ValueError):
    pass


class DashboardStorage:
    def __init__(self, root: Path, protector=None):
        self.path = root / 'work/dashboard-data.json'
        self.projects = ProjectRepository(root / 'work/project-backups')
        self.protector = protector or WindowsDpapiProtector()

    def _bundle(self):
        try:
            return self.projects.load()
        except FileNotFoundError:
            return {'store': {'projects': [], 'activeProjectId': None}, 'trainees': [], 'guests': []}

    def read(self):
        with self.projects.lock:
            values = json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else {}
            encrypted_secret = values.get(SECRET_KEY)
            secret_status = 'missing'
            if SECRET_KEY in values:
                try:
                    values[SECRET_KEY] = self.protector.unprotect(base64.b64decode(values[SECRET_KEY])).decode()
                    secret_status = 'saved' if values[SECRET_KEY].strip() else 'missing'
                except (OSError, ValueError):
                    # A moved workspace must still open on another Windows user.
                    values.pop(SECRET_KEY)
                    secret_status = 'unavailable'
            bundle = self._bundle()
            for key, field in PROJECT_KEYS.items():
                values[key] = json.dumps(bundle[field], ensure_ascii=False, separators=(',', ':'))
            revision = hashlib.sha256(json.dumps([values, encrypted_secret], sort_keys=True).encode()).hexdigest()
            return {'values': values, 'revision': revision, 'umaMoeKeyStatus': secret_status}

    def write(self, payload, save_project):
        with self.projects.lock:
            state = self.read()
            if payload.get('revision') != state['revision']:
                raise StorageConflict('Local files changed in another session. Reload saved data before editing again.')
            changes = payload.get('changes')
            if not isinstance(changes, dict) or len(changes) > 1000:
                raise ValueError('Invalid dashboard changes')
            values = dict(state['values'])
            bundle = self._bundle()
            for key, value in changes.items():
                if not isinstance(key, str) or len(key) > 256 or not (key.startswith('uma-pilot-official:') or key == 'uma-pilot-theme-v2'):
                    raise ValueError('Unsupported dashboard key')
                if value is not None and not isinstance(value, str):
                    raise ValueError('Dashboard values must be text or null')
                if key == SECRET_KEY:
                    if value is None or not value.strip():
                        raise ValueError('An empty value cannot remove the saved uma.moe API key')
                    value = value.strip()
                if key in PROJECT_KEYS:
                    if value is None:
                        raise ValueError('Project data cannot be removed as a storage key')
                    bundle[PROJECT_KEYS[key]] = json.loads(value)
                if value is None:
                    values.pop(key, None)
                else:
                    values[key] = value
            disk = {k: v for k, v in values.items() if k not in PROJECT_KEYS}
            if SECRET_KEY in changes:
                disk[SECRET_KEY] = base64.b64encode(self.protector.protect(disk[SECRET_KEY].encode())).decode()
            elif self.path.exists():
                # Project/settings saves must never rewrite an unrelated credential.
                # Preserve even a key encrypted by another Windows user or machine.
                prior = json.loads(self.path.read_text(encoding='utf-8'))
                if SECRET_KEY in prior:
                    disk[SECRET_KEY] = prior[SECRET_KEY]
            encoded = json.dumps(disk, ensure_ascii=False).encode('utf-8')
            if len(encoded) > 32 * 1024 * 1024:
                raise ValueError('Dashboard caches exceed 32 MB')
            if any(k in PROJECT_KEYS for k in changes):
                save_project(bundle)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix('.tmp')
            temporary.write_bytes(encoded)
            temporary.replace(self.path)
            return self.read()
