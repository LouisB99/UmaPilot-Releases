"""Opt-in Discord notifications. Secrets stay encrypted in the local service."""
import base64
import json
import re
import threading
import uuid
import urllib.request
import urllib.error
from datetime import datetime, timezone
from umabot.account_profiles import WindowsDpapiProtector
from umabot.pilot_notifications import event_message, career_message, sample_message, encode_message

EVENTS = {'career-started', 'career-finished', 'attention', 'project-complete', 'resource-wait'}
_lock = threading.RLock()


def validate_url(url):
    if not isinstance(url, str) or not re.fullmatch(r'https://discord[.]com/api/(?:v10/)?webhooks/[0-9]+/[A-Za-z0-9_-]+', url):
        raise ValueError('Use a Discord channel webhook URL from discord.com')
    return url


def _read(root):
    p = root / 'work/discord-notifications.json'
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'webhooks': [], 'sent': []}


def _save(root, data):
    p = root / 'work/discord-notifications.json'
    p.parent.mkdir(parents=True, exist_ok=True)
    temp = p.with_suffix('.tmp')
    temp.write_text(json.dumps(data), encoding='utf-8')
    temp.replace(p)


def _url(row):
    return validate_url(WindowsDpapiProtector().unprotect(base64.b64decode(row['secret'])).decode())


def _public(row):
    public = {k: v for k, v in row.items() if k != 'secret'}
    try:
        _url(row)
        public['credentialStatus'] = 'saved'
    except (OSError, ValueError, KeyError):
        public['credentialStatus'] = 'unavailable'
    return public


def settings(root, values=None):
    with _lock:
        data = _read(root)
        if values is not None:
            rows = values.get('webhooks')
            if not isinstance(rows, list) or len(rows) > 5:
                raise ValueError('Configure up to five Discord webhooks')
            old = {r['id']: r for r in data['webhooks']}
            updated = []
            seen = set()
            for row in rows:
                identifier = row.get('id') or uuid.uuid4().hex
                if identifier in seen or (row.get('id') and identifier not in old):
                    raise ValueError('Invalid or duplicate webhook identity')
                seen.add(identifier)
                if type(row.get('enabled')) is not bool or not isinstance(row.get('events'), list) or not set(row['events']) <= EVENTS:
                    raise ValueError('Choose valid notification events')
                name = str(row.get('name') or '').strip()
                if not 1 <= len(name) <= 80:
                    raise ValueError('Give each webhook a name of 1 to 80 characters')
                record = {**old.get(identifier, {}), 'id': identifier, 'name': name, 'enabled': row['enabled'], 'events': row['events']}
                passed_only = row.get('passedCareersOnly', record.get('passedCareersOnly', False))
                if type(passed_only) is not bool:
                    raise ValueError('Choose whether to notify only for accepted veterans')
                record['passedCareersOnly'] = passed_only
                if row.get('url'):
                    url = validate_url(row['url'].strip())
                    record['secret'] = base64.b64encode(WindowsDpapiProtector().protect(url.encode())).decode()
                if not record.get('secret'):
                    raise ValueError('A new webhook needs its Discord URL')
                updated.append(record)
            data['webhooks'] = updated
            _save(root, data)
        return {'webhooks': [_public(row) for row in data['webhooks']]}


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def _deliver(root, identifier, content):
    with _lock:
        row = next((r for r in _read(root)['webhooks'] if r['id'] == identifier), None)
    if not row:
        return
    status = 'Delivered'
    try:
        url = _url(row)
    except (OSError, ValueError, KeyError):
        status = 'Delivery failed: Windows cannot unlock the saved webhook. Paste its URL again on this computer and save.'
    else:
        try:
          message = content if isinstance(content, dict) else event_message('update', content)
          body, content_type = encode_message(root, message)
          request = urllib.request.Request(url+'?wait=true', data=body, headers={'Content-Type': content_type, 'User-Agent': 'UmaPilot/1.0'}, method='POST')
          with urllib.request.build_opener(NoRedirect()).open(request, timeout=10) as response:
              if response.status != 200:
                  raise ValueError('Unconfirmed delivery')
        except urllib.error.HTTPError as exc:
          reason = {401: 'webhook authorization rejected', 403: 'webhook access denied',
                    404: 'webhook no longer exists', 429: 'Discord rate limit reached',
                    400: 'Discord rejected the message format'}.get(exc.code, 'Discord request failed')
          status = f'Delivery failed: {reason} (HTTP {exc.code}). Try the styled test after correcting it.'
        except (urllib.error.URLError, TimeoutError):
          status = 'Delivery failed: could not reach Discord. Check this computer’s network and try the styled test.'
        except Exception:
          # Never expose token-bearing URLs or raw HTTP exception bodies.
          status = 'Delivery failed; check the webhook or try the test again'
    with _lock:
        data = _read(root)
        for current in data['webhooks']:
            if current['id'] == identifier:
                current.update(lastStatus=status, lastAttemptAt=datetime.now(timezone.utc).isoformat())
        _save(root, data)


def send(root, event, key, content, *, career_passed=False):
    content = content if isinstance(content, dict) else event_message(event, content)
    with _lock:
        data = _read(root)
        for row in data['webhooks']:
            stamp = row['id'] + ':' + key
            if not row['enabled'] or event not in row['events'] or stamp in data['sent']:
                continue
            if event == 'career-finished' and row.get('passedCareersOnly') and career_passed is not True:
                continue
            # Reserve before delivery: uncertain sends never get replayed.
            data['sent'] = [*data['sent'], stamp][-300:]
            _save(root, data)
            threading.Thread(target=_deliver, args=(root,row['id'],content), daemon=True).start()


def test(root, identifier):
    if not any(r['id'] == identifier for r in settings(root)['webhooks']):
        raise ValueError('Save the webhook before testing it')
    _deliver(root, identifier, sample_message())
    return settings(root)


def job_finished(root, job):
    result = job.result or {}
    project = result.get('updatedProject') or {}
    recap = project.get('lastRunRecap') or {}
    if job.status == 'failed':
        # Do not forward exception traces, account fields or transport payloads.
        send(root, 'attention', job.id, 'UmaPilot needs attention. Open the dashboard to review the stopped operation.')
    elif recap and not result.get('alreadyRecorded'):
        accepted = recap.get('passed') is True and result.get('progressionBlocked') is not True
        send(root, 'career-finished', 'veteran:'+str(project.get('id'))+':'+str(recap.get('veteranId')), career_message(project, recap), career_passed=accepted)
        if project.get('status') == 'completed':
            send(root,'project-complete','project:'+project['id'],project.get('name','Project')+' is complete.')
    elif 'Independent Training started' in (job.stage or ''):
        send(root,'career-started',job.id,'UmaPilot started the next project career. Automatic completion is scheduled.')
    elif 'Waiting for natural resources:' in (job.stage or ''):
        # Repeated resource checks do not repeat the same notification each time.
        send(root,'resource-wait','wait:'+job.stage,job.stage)
