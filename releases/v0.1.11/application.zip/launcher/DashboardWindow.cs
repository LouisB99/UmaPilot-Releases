using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32;

// A separate Chromium profile keeps the dashboard process independent of the
// user's regular browser. Only this process tree belongs to the launcher.
internal sealed class DashboardWindow : IDisposable {
    readonly string root;
    Process browser;
    OwnedProcessTree owned;
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr handle);
    [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr handle, int command);

    internal DashboardWindow(string directory) { root = directory; }
    internal static string FindBrowser() {
        string preferred = "";
        using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice"))
            if (key != null) preferred = Convert.ToString(key.GetValue("ProgId"));
        string[] names = { "brave.exe", "msedge.exe", "chrome.exe" };
        if (preferred.IndexOf("Chrome", StringComparison.OrdinalIgnoreCase) >= 0) names = new[] { "chrome.exe", "brave.exe", "msedge.exe" };
        else if (preferred.IndexOf("Edge", StringComparison.OrdinalIgnoreCase) >= 0) names = new[] { "msedge.exe", "brave.exe", "chrome.exe" };
        foreach (string name in names) {
            foreach (RegistryKey hive in new[] { Registry.CurrentUser, Registry.LocalMachine }) {
                using (var key = hive.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\App Paths\" + name)) {
                    string path = key == null ? null : key.GetValue(null) as string;
                    if (!String.IsNullOrEmpty(path) && File.Exists(path.Trim('"'))) return path.Trim('"');
                }
            }
            string relative = name == "brave.exe" ? @"BraveSoftware\Brave-Browser\Application\brave.exe" : name == "chrome.exe" ? @"Google\Chrome\Application\chrome.exe" : @"Microsoft\Edge\Application\msedge.exe";
            foreach (var folder in new[] { Environment.SpecialFolder.ProgramFiles, Environment.SpecialFolder.ProgramFilesX86, Environment.SpecialFolder.LocalApplicationData }) {
                string path = Path.Combine(Environment.GetFolderPath(folder), relative);
                if (File.Exists(path)) return path;
            }
        }
        throw new IOException("Install Brave, Chrome, or Edge to open the managed UmaPilot dashboard window.");
    }

    internal static ProcessStartInfo StartInfo(string directory, string executable) {
        string profile = Path.Combine(directory, "work", "dashboard-browser");
        return new ProcessStartInfo(executable) {
            Arguments = "--app=http://localhost:3100 --user-data-dir=" + UpdateSupport.Quote(profile) + " --no-first-run --no-default-browser-check --disable-background-mode",
            WorkingDirectory = directory, UseShellExecute = false
        };
    }

    internal void Open() {
        if (browser != null && !browser.HasExited) {
            browser.Refresh();
            if (browser.MainWindowHandle != IntPtr.Zero) {
                ShowWindow(browser.MainWindowHandle, 9);
                SetForegroundWindow(browser.MainWindowHandle);
                return;
            }
        }
        Dispose();
        owned = new OwnedProcessTree();
        try {
            browser = Process.Start(StartInfo(root, FindBrowser()));
            owned.Attach(browser);
        } catch { Dispose(); throw; }
    }

    public void Dispose() {
        if (browser != null) {
            try { if (!browser.HasExited) { browser.CloseMainWindow(); browser.WaitForExit(1000); } }
            catch (InvalidOperationException) { }
        }
        if (owned != null) { owned.Dispose(); owned = null; }
        if (browser != null) { browser.Dispose(); browser = null; }
    }
}
