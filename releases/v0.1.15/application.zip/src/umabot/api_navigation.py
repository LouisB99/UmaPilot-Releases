"""Session-bound API navigation. No screen capture, input injection or OCR.

Only explicitly classified, reviewed routes can execute. A transport failure
invalidates the client: replaying a timed-out mutation is never automatic.
"""
from __future__ import annotations

import copy
import hashlib
import json
import threading
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import msgpack

from umabot.api_session import SessionSidState
from umabot.api_contracts import COMMON_FIELDS, PAYLOAD_FIELDS, common_fields
from umabot.api_transport import MAX_LOAD_INDEX_RESPONSE_BYTES, _post_logical, with_server_resource_version


ROUTES = {
    'user/change_name':'janus-setup', 'user/change_sex':'janus-setup',
    'tutorial/skip':'janus-setup', 'mission/receive':'janus-rewards',
    'present/index':'read', 'present/receive_all':'janus-rewards',
    'gacha/index':'read', 'gacha/exec':'janus-pull',
    'account/index':'read', 'account/publish_transition_code':'janus-recovery',
    'account/steam_chain_disconnect':'janus-reset',
    'item/use_recovery_item': 'refill-tp',
    'user/recovery_trainer_point': 'refill-tp',

    "single_mode/factor_select": "generate-factors",
    "single_mode/finish": "finish-career",
    "trained_chara/change_lock_multi": "protect-veteran",
    "load/index": "read",
    "read_info/index": "read",
    "pre_single_mode/index": "read",
    "pre_single_mode/friend_support_card_reload": "read",
    "idle_single_mode/pre_start": "prepare",
    "idle_single_mode/start": "commit",
    "idle_single_mode/end": "complete-training",
    "idle_single_mode/result": "read",
    "idle_single_mode/check_progress_log": "acknowledge-log",
    "single_mode_live/gain_skills": "learn-skills",
    "single_mode_live/factor_select": "generate-factors",
    "single_mode_live/finish": "finish-career",
    "friend/index": "read",
    "friend/search": "read",
    "friend/follow": "follow-guest",
    "team_stadium/index": "read",
    "daily_race/resume": "read",
    "mission/index": "read",
}

# 394 is not yet classified as transient. A decoded rejection can still be
# retried on reviewed reads, using its validated account and successor SID.
READ_REJECTION_RETRY_DELAYS = (3, 6)


class ApiNavigationError(RuntimeError):
    pass


class CaptureOwnership:
    """Yield only when the official client resumes this API account.

    Other Steam accounts may create capture sessions without taking ownership.
    Unidentifiable new requests fail closed; credentials are never retained here.
    """
    def __init__(self, directory: Path, viewer_id: int, steam_id: str = ''):
        if not int(viewer_id):
            raise ValueError('Session ownership requires an authenticated account')
        self.directory = directory
        self.viewer_id = int(viewer_id)
        self.steam_id = str(steam_id)
        self.watermark = self._current()
        self.revoked = False

    def _current(self):
        paths = set(self.directory.parent.glob('session_*/*_Q_*.msgpack'))
        paths.update(self.directory.glob('*_Q_*.msgpack'))
        return {p: (p.stat().st_size, p.stat().st_mtime_ns) for p in paths}

    def unchanged(self) -> bool:
        if self.revoked:
            return False
        try:
            current = self._current()
            for path, stamp in current.items():
                if self.watermark.get(path) == stamp:
                    continue
                request = msgpack.unpackb(path.read_bytes(), raw=False, strict_map_key=False)
                viewer = int(request.get('viewer_id') or 0)
                steam = str(request.get('steam_id') or '')
                if viewer == self.viewer_id or (self.steam_id and steam == self.steam_id):
                    self.revoked = True
                    break
                if not viewer and not (self.steam_id and steam):
                    self.revoked = True
                    break
            self.watermark = current
        except (OSError, ValueError, TypeError, AttributeError, msgpack.UnpackException):
            self.revoked = True
        return not self.revoked


class SessionNavigator:
    def __init__(self, *, codec, common_template: dict[str, Any], header: bytes,
                 ticket: bytes, request_sid: str, contract, opener,
                 capture_session: Path, timeout: float = 15, delay: float = .28,
                 ownership: CaptureOwnership | None = None):
        self.codec = codec
        self._common = copy.deepcopy(common_template)
        self.account_key = hashlib.sha256(str(common_template["viewer_id"]).encode()).hexdigest()[:12]
        self._header = header
        self._ticket = ticket
        self._sid = request_sid
        self._contract = contract
        self._opener = opener
        self.capture_session = capture_session
        self.timeout = timeout
        self.delay = delay
        self.valid = True
        self.request_count = 0
        self._last_response = 0.0
        self._lock = threading.Lock()
        self.ownership = ownership
        self.last_response_summary = None
        self.on_retry = None

    def check_ownership(self) -> bool:
        if self.ownership is not None and not self.ownership.unchanged():
            self.valid = False
        return self.valid

    def __repr__(self):
        return f"SessionNavigator(valid={self.valid}, request_count={self.request_count})"

    def _fields(self, endpoint: str) -> set[str]:
        if endpoint not in ROUTES or endpoint not in PAYLOAD_FIELDS:
            raise ApiNavigationError('Endpoint is not classified for API execution')
        # Contracts are reviewed package data. Development metadata validation
        # remains available separately; the runtime does not need the game.
        return set(PAYLOAD_FIELDS[endpoint])

    def request(self, endpoint: str, payload: dict[str, Any] | None = None,
                *, authorized_effects: frozenset[str] = frozenset()) -> dict[str, Any]:
        endpoint = endpoint.removeprefix("umamusume/")
        effect = ROUTES.get(endpoint)
        if effect is None:
            raise ApiNavigationError("Endpoint is not classified for API execution")
        if effect != "read" and effect not in authorized_effects:
            raise ApiNavigationError(f"{endpoint} requires explicit {effect} authorization")
        payload = payload or {}
        if not isinstance(payload, dict) or set(payload) & (COMMON_FIELDS | {'adid'}):
            raise ApiNavigationError("Payload cannot replace session or account fields")
        if endpoint in {'single_mode/finish', 'single_mode_live/finish'} and payload.get('is_force_delete') is not False:
            raise ApiNavigationError('Career deletion is never authorized by the finish route')
        if endpoint == 'trained_chara/change_lock_multi':
            ids = payload.get('trained_chara_id_array')
            if (payload.get('lock_flag') != 1 or type(payload.get('icon_type')) is not int or payload['icon_type'] not in range(15) or
                    not isinstance(ids, list) or len(ids) != 1 or type(ids[0]) is not int or ids[0] <= 0):
                raise ApiNavigationError('Only protecting one veteran with a supported project sticker is enabled')
        if endpoint in {'item/use_recovery_item', 'user/recovery_trainer_point'}:
            if type(payload.get('client_own_num')) is not int or payload['client_own_num'] <= 0:
                raise ApiNavigationError('Refill requires a current positive resource balance')
            if endpoint == 'item/use_recovery_item' and (payload.get('item_id') != 32 or payload.get('item_num') != 1):
                raise ApiNavigationError('Only one TP bottle may be used per refill')
            if endpoint == 'user/recovery_trainer_point' and payload.get('count') != 1:
                raise ApiNavigationError('Only one carat TP refill may be requested')
        allowed = self._fields(endpoint)
        if endpoint in {'friend/search', 'friend/follow'}:
            if type(payload.get('friend_viewer_id')) is not int or payload['friend_viewer_id'] <= 0:
                raise ApiNavigationError('Guest lookup requires a valid trainer ID')
            if endpoint == 'friend/search' and payload.get('deleted_response_type') != 0:
                raise ApiNavigationError('Only active guest profiles may be searched')
        if set(payload) != allowed:
            raise ApiNavigationError(f"Payload fields do not match the reviewed {endpoint} contract")
        if not self._lock.acquire(blocking=False):
            raise ApiNavigationError("Another request already owns this game session")
        try:
            attempt = 0
            read_retries = 0
            resource_retried = False
            while True:
                attempt += 1
                if not self.check_ownership():
                    raise ApiNavigationError("Session outcome is unknown; reconnect before continuing")
                request_delay = self.delay() if callable(self.delay) else self.delay
                wait = request_delay - (time.monotonic() - self._last_response)
                if wait > 0:
                    time.sleep(wait)
                if not self.check_ownership():
                    raise ApiNavigationError("Session ownership changed while waiting; reconnect before continuing")
                fields = common_fields(endpoint)
                body = {key: copy.deepcopy(value) for key, value in self._common.items() if key in fields}
                body.update(copy.deepcopy(payload))
                body["steam_session_ticket"] = self._ticket.hex().upper()
                logical = msgpack.packb(body, use_bin_type=True)
                wire = self.codec.encode_request(logical, self._header, sid=self._sid)
                if self.codec.decode_request(wire) != logical:
                    raise ApiNavigationError("Request codec round trip failed")
                request = urllib.request.Request(
                    f"https://api.games.umamusume.com/umamusume/{endpoint}",
                    data=wire, headers=self._contract.headers(self._sid), method="POST")
                self.request_count += 1
                self.last_response_summary = None
                try:
                    _logical, result = _post_logical(self.codec, self._opener, request,
                        self.timeout, endpoint, MAX_LOAD_INDEX_RESPONSE_BYTES)
                    headers = result.get("data_headers") or {}
                    self.last_response_summary = {'endpoint':endpoint,
                        'responseCode':result.get('response_code') if isinstance(result.get('response_code'),int) else None,
                        'resultCode':headers.get('result_code') if isinstance(headers.get('result_code'),int) else None,
                        'dataFields':sorted(result.get('data') or {}) if isinstance(result.get('data'),dict) else []}
                    if headers.get("viewer_id") not in (None, self._common.get("viewer_id")):
                        raise ApiNavigationError("Response account mismatch")
                    self._sid = SessionSidState(self._sid).advance(str(headers.get("sid") or ""))
                    if result.get('response_code') == 214 and endpoint == 'load/index' and not resource_retried:
                        resource_retried = True
                        self._contract = with_server_resource_version(self._contract, result)
                        self._last_response = time.monotonic()
                        continue  # One read-only retry, with the server's new SID and resource version.
                    if (effect == 'read' and result.get('response_code') == 394
                            and headers.get('result_code') == 394
                            and headers.get('viewer_id') == self._common.get('viewer_id')
                            and read_retries < len(READ_REJECTION_RETRY_DELAYS)):
                        if not self.check_ownership():
                            raise ApiNavigationError("Official client resumed during the request")
                        pause = READ_REJECTION_RETRY_DELAYS[read_retries]
                        read_retries += 1
                        if self.on_retry:
                            label = 'Account refresh' if endpoint == 'load/index' else 'Game data check'
                            self.on_retry({'type':'api-retry', 'retry':read_retries,
                                'delaySeconds':pause, 'responseCode':394,
                                'message':f'{label} rejected (code 394). Retrying in {pause}s '
                                          f'({read_retries}/{len(READ_REJECTION_RETRY_DELAYS)} retries).'})
                        self._last_response = time.monotonic()
                        time.sleep(pause)
                        continue
                    if result.get("response_code") == 1 and result.get('data') is None and endpoint in {'account/publish_transition_code','account/steam_chain_disconnect'}:
                        result['data']={}
                    if result.get("response_code") != 1 or not isinstance(result.get("data"), dict):
                        raise ApiNavigationError("Game returned an unsuccessful response")
                    self._last_response = time.monotonic()
                    if not self.check_ownership():
                        raise ApiNavigationError("Official client resumed during the request")
                    return result["data"]
                except Exception as exc:
                    self.valid = False
                    summary = self.last_response_summary or {}
                    attempts = 'without retry' if attempt == 1 else f'after {attempt} attempts'
                    raise ApiNavigationError(f"{endpoint} failed; session stopped {attempts} "
                        f"(responseCode={summary.get('responseCode')}, resultCode={summary.get('resultCode')}, "
                        f"errorType={type(exc).__name__})") from None
        finally:
            self._lock.release()


def career_state(load: dict[str, Any]) -> dict[str, Any]:
    idle = load.get("idle_single_mode_load_info")
    normal = load.get("single_mode_chara_light")
    if idle:
        return {"screen": "independent-training", "active": True, "data": idle}
    if normal:
        return {"screen": "normal-career", "active": True, "data": normal}
    return {"screen": "main-menu", "active": False}


def training_summary(load: dict[str, Any]) -> dict[str, Any] | None:
    idle = load.get('idle_single_mode_load_info')
    if not isinstance(idle, dict) or not idle:
        return None
    chara = idle.get('single_mode_chara_light') or idle.get('chara_info') or {}
    def utc(value):
        try:
            parsed = datetime.fromisoformat(str(value).replace('Z', '+00:00'))
            return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed
        except ValueError:
            return None
    start, end = utc(idle.get('start_time')), utc(idle.get('end_time'))
    return {'cardId': chara.get('card_id'), 'scenarioId': chara.get('scenario_id'),
        'startTime': start.isoformat() if start else None,
        'endTime': end.isoformat() if end else None,
        'scheduledEndReached': bool(end and datetime.now(timezone.utc) >= end),
        'completionConfirmed': False}


def preset_catalog(load: dict[str, Any], pre_start: dict[str, Any]) -> dict[str, Any]:
    return {
        "supportDecks": [{"deckId": d["deck_id"], "name": d.get("name", ""),
            "supportCardIds": list(d.get("support_card_id_array") or []),
            "complete": len(d.get("support_card_id_array") or []) == 5 and
                        all(d.get("support_card_id_array") or [])}
            for d in load.get("support_card_deck_array") or []],
        "agendas": [{"agendaId": d["deck_num"], "name": d.get("deck_name", ""),
                     "raceCount": len(d.get("race_array") or [])}
                    for d in (pre_start.get("reserved_race_info") or {}).get("reserved_race_array") or []],
        "lastSelectedDeckId": load.get("last_select_support_card_deck_id"),
        "createsPresets": False,
    }


def resolve_project_presets(project: dict[str, Any], load: dict[str, Any],
                            pre_start: dict[str, Any]) -> dict[str, Any]:
    options = project.get("runOptions") or {}
    wanted = options.get("supportDeckId")
    # Legacy projects used the game's selected preset. Preserve that behavior
    # explicitly until the user assigns a project-specific preset.
    if wanted is None:
        wanted = load.get("last_select_support_card_deck_id")
    decks = [d for d in load.get("support_card_deck_array") or [] if d.get("deck_id") == wanted]
    if len(decks) != 1:
        raise ApiNavigationError("The project's saved support preset is unavailable")
    cards = list(decks[0].get("support_card_id_array") or [])
    owned = {d.get("support_card_id") for d in load.get("support_card_list") or []}
    if len(cards) != 5 or len(set(cards)) != 5 or not all(c in owned for c in cards):
        raise ApiNavigationError("The saved support preset must contain five distinct owned cards")
    agendas = (pre_start.get("reserved_race_info") or {}).get("reserved_race_array") or []
    agenda_id = options.get("agendaId")
    agendas = [a for a in agendas if (a.get("deck_num") == agenda_id if agenda_id is not None
                                     else a.get("deck_name") == options.get("agenda"))]
    if len(agendas) != 1:
        raise ApiNavigationError("The project's saved agenda is missing or ambiguous")
    return {"supportDeckId": wanted, "supportCardIds": cards,
            "agendaId": agendas[0]["deck_num"], "agendaName": agendas[0].get("deck_name"),
            "savedRaceArray": copy.deepcopy(agendas[0].get("race_array") or []),
            "usesLastSelectedDeck": options.get("supportDeckId") is None}
