"""Build a personal portable archive from an explicit application/data allowlist."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile
import zipfile
from contextlib import closing

ROOT=Path(__file__).resolve().parents[1]
IGNORED={'.git','__pycache__','.pytest_cache','.next','.vinext','.wrangler','.openai','.cache'}
DATA_DIRS=('account-profiles','brain','janus','mercury','project-backups','run-details')
DATA_FILES=('catalog-cache.json','continuous-pilot.json','dashboard-data.json','discord-notifications.json',
            'legacy-rental-policy.json','tp-refill-settings.json','training-watch.json')


def walk(folder):
    for base,dirs,files in os.walk(folder):
        dirs[:]=[d for d in dirs if d not in IGNORED and not Path(base,d).is_junction()]
        for name in sorted(files):
            path=Path(base,name)
            if name.startswith('.env') or name.endswith(('.pyc','.pyo','.log','.tmp','.lock','-wal','-shm','.tsbuildinfo')) or name=='stop':continue
            if path.is_symlink():raise ValueError(f'Unexpected symbolic link: {path}')
            yield path


def stopped_continuous(data):
    value=json.loads(data)
    value.update(enabled=False,state='stopped',nextCheckAt=None,reconnectAt=None,
                 message='Personal VM copy: connect your account, then enable Pilot when ready.')
    return json.dumps(value,ensure_ascii=False,indent=2).encode('utf-8')


def package(destination,ui_dist):
    destination=destination.resolve();destination.parent.mkdir(parents=True,exist_ok=True)
    if destination.exists():raise ValueError('Choose a new archive name; existing packages are preserved')
    required=('UmaPilot.exe','.runtime/python/python.exe','.runtime/node/node-v24.14.0-win-x64/node.exe',
              'resources/master.mdb','Converter/node_modules/steam-user/package.json','ui/node_modules/vinext/dist/cli.js')
    for relative in required:
        if not (ROOT/relative).is_file():raise ValueError(f'Missing portable dependency: {relative}')
    if not (ui_dist/'server/BUILD_ID').is_file():raise ValueError('A completed dashboard build is required')
    files={}
    for directory in ('.runtime','Converter','assets','config','resources','src','vendor','launcher','scripts','updates'):
        for path in walk(ROOT/directory):files[path.relative_to(ROOT).as_posix()]=path
    for path in walk(ROOT/'ui'):
        relative=path.relative_to(ROOT)
        if relative.parts[1]=='dist':continue
        files[relative.as_posix()]=path
    for path in walk(ui_dist):files['ui/dist/'+path.relative_to(ui_dist).as_posix()]=path
    for path in walk(ROOT/'uma_api_capture/lookups'):files[path.relative_to(ROOT).as_posix()]=path
    for directory in DATA_DIRS:
        for path in walk(ROOT/'work'/directory):files[path.relative_to(ROOT).as_posix()]=path
    for name in DATA_FILES:
        path=ROOT/'work'/name
        if path.is_file():files['work/'+name]=path
    for name in ('UmaPilot.exe','START-UMA-PILOT.cmd','START-JANUS.cmd','START-MERCURY.cmd','CHECK-PORTABILITY.cmd',
                 'requirements-portable.txt','pyproject.toml'):
        files[name]=ROOT/name
    if (ROOT/'UmaPilotUpdater.exe').is_file():files['UmaPilotUpdater.exe']=ROOT/'UmaPilotUpdater.exe'
    for path in walk(ROOT/'docs'):files[path.relative_to(ROOT).as_posix()]=path
    readme=(ROOT/'docs/EXE-VM-QUICKSTART.md').read_bytes()
    partial=destination.with_suffix('.zip.partial')
    count=0;total=0;manifest=[]
    with tempfile.TemporaryDirectory(prefix='umapilot-package-') as temporary:
        with zipfile.ZipFile(partial,'w',zipfile.ZIP_DEFLATED,compresslevel=5,allowZip64=True) as archive:
            for relative,path in sorted(files.items()):
                if path.suffix in ('.sqlite','.db'):
                    snapshot=Path(temporary)/'snapshot.sqlite'
                    with closing(sqlite3.connect(path.resolve().as_uri()+'?mode=ro',uri=True)) as source, closing(sqlite3.connect(snapshot)) as target:
                        source.backup(target)
                        if relative=='work/janus/janus.sqlite':
                            row=target.execute('SELECT data FROM state WHERE id=1').fetchone()
                            data=json.loads(row[0])
                            for run in data['runs']:
                                if run['state'] in ('running','waiting'):
                                    run.update(state='attention',stage='Copied to another installation. Reconcile the current account before resuming.')
                            target.execute('UPDATE state SET data=? WHERE id=1',(json.dumps(data),))
                            target.commit()
                    content=snapshot.read_bytes();snapshot.unlink()
                else:content=path.read_bytes()
                if relative=='work/continuous-pilot.json':content=stopped_continuous(content)
                archive.writestr('UmaPilot/'+relative,content)
                manifest.append({'path':relative,'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()})
                count+=1;total+=len(content)
                if count%5000==0:print(f'Packed {count:,} files ({total/1024/1024:.0f} MiB)',flush=True)
            archive.writestr('UmaPilot/START-HERE.txt',readme)
            archive.writestr('UmaPilot/PACKAGE-MANIFEST.json',json.dumps({'kind':'personal','automaticUpdates':'updates/channel.json' in files,'files':manifest},indent=2))
    with zipfile.ZipFile(partial) as archive:
        bad=archive.testzip()
        if bad:raise ValueError('Archive verification failed: '+bad)
        state=json.loads(archive.read('UmaPilot/work/continuous-pilot.json')) if 'work/continuous-pilot.json' in files else {}
        if state.get('enabled'):raise ValueError('Automation must be off in the transferred copy')
    partial.replace(destination)
    checksum=hashlib.sha256(destination.read_bytes()).hexdigest()
    destination.with_suffix('.sha256').write_text(checksum+'  '+destination.name+'\n',encoding='utf-8')
    print(json.dumps({'archive':str(destination),'files':count,'uncompressedMiB':round(total/1024/1024,1),
                      'archiveMiB':round(destination.stat().st_size/1024/1024,1),'sha256':checksum}),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--ui-dist',type=Path,default=ROOT/'ui/dist')
    args=parser.parse_args();package(args.output,args.ui_dist)
