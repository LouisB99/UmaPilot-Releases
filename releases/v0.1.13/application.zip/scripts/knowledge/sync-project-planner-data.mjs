import { mkdir, readFile, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const here = path.dirname(fileURLToPath(import.meta.url))
const uiRoot = path.resolve(here, '..', '..', 'ui')
const sourceRoot = path.resolve(uiRoot, '..', 'work', 'sparkline-source', 'src', 'data', 'static')
const outputRoot = path.resolve(uiRoot, 'public', 'data', 'planner')

const readJson = async (name) => JSON.parse(await readFile(path.join(sourceRoot, name), 'utf8'))
const maxValue = (row) => Math.max(0, ...row.slice(1).filter((value) => Number.isFinite(value) && value >= 0))

async function main() {
  const manifest = await fetch('https://gametora.com/data/manifests/umamusume.json').then((response) => {
    if (!response.ok) throw new Error(`GameTora manifest returned ${response.status}`)
    return response.json()
  })
  const supportHash = manifest['support-cards']
  if (!supportHash) throw new Error('GameTora support-cards hash is missing')
  const supportUrl = `https://gametora.com/data/umamusume/support-cards.${supportHash}.json`
  const supportRaw = await fetch(supportUrl).then((response) => {
    if (!response.ok) throw new Error(`GameTora support snapshot returned ${response.status}`)
    return response.json()
  })

  const supports = supportRaw
    .filter((card) => card.release_en != null)
    .map((card) => {
      const effects = Object.fromEntries((card.effects ?? []).map((row) => [String(row[0]), maxValue(row)]))
      for (const effect of card.unique?.effects ?? []) {
        effects[String(effect.type)] = (effects[String(effect.type)] ?? 0) + Number(effect.value ?? 0)
      }
      return {
        id: card.support_id,
        charaId: card.char_id,
        name: [card.title_en, card.char_name].filter(Boolean).join(' '),
        rarity: card.rarity,
        type: card.type ?? null,
        release: card.release_en,
        effects,
        skillIds: [...new Set([...(card.hints?.hint_skills ?? []), ...(card.event_skills ?? [])])],
      }
    })
    .sort((a, b) => a.id - b.id)

  const files = {
    'characters.json': await readJson('characters.json'),
    'variants.json': await readJson('variants.json'),
    'relations.json': await readJson('relations.json'),
    'skills.json': await readJson('skills.json'),
    'supports.json': supports,
  }

  await mkdir(outputRoot, { recursive: true })
  for (const [name, value] of Object.entries(files)) {
    await writeFile(path.join(outputRoot, name), `${JSON.stringify(value)}\n`, 'utf8')
  }
  await writeFile(
    path.join(outputRoot, 'meta.json'),
    `${JSON.stringify({ generatedAt: new Date().toISOString(), supportSource: supportUrl, counts: Object.fromEntries(Object.entries(files).map(([name, value]) => [name, Array.isArray(value) ? value.length : Object.keys(value).length])) }, null, 2)}\n`,
    'utf8',
  )
  console.log(`Planner data ready in ${outputRoot}`)
  console.log(`Global supports: ${supports.length}`)
}

await main()
