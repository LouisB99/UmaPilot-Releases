"""Immutable knowledge generations. Source failure never blocks process startup.

Global relation points are not inheritance probabilities. The client-compatible
race rule is maintained in api_affinity; it is not inferred from community posts.
"""
from __future__ import annotations
import hashlib
import json
import shutil
import subprocess
import tempfile
import threading
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from umabot.data_sync import catalog_snapshot

FILES = {name: 'ui/public/data/planner/' + name + '.json' for name in ('characters','variants','relations','skills','supports','meta')}
FILES.update(sparks='ui/public/data/sparks.json', courses='ui/public/uma-tools/umalator-global/course_data.json', tracks='ui/public/uma-tools/umalator-global/tracknames.json', skillData='ui/public/uma-tools/umalator-global/skill_data.json')
RULESET = 'global-client-g1-group-3-v1'
MANIFEST = 'https://gametora.com/data/manifests/umamusume.json'


def now():
    return datetime.now(timezone.utc).isoformat()


def catalog_time(value):
    parsed = datetime.fromisoformat(value)
    return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed


class BrainKnowledge:
    def __init__(self, root: Path):
        self.root = root
        self.base = root / 'work/brain/knowledge'
        self.lock = threading.RLock()
        self.state = {'status': 'stale', 'checkedAt': None, 'error': None, 'ruleset': RULESET}
        self.data = None
        self.manifest = None
        self.catalog_stamp = None

    def publish(self, data, worker_hash):
        for key in FILES:
            if key not in data or not isinstance(data[key], (dict, list)) or not data[key]:
                raise ValueError('Invalid knowledge dataset: ' + key)
        if not all(isinstance(row,dict) and 'id' in row for row in data['variants']):
            raise ValueError('Invalid variant schema')
        character_ids = {row['id'] for row in data['characters']}
        if any(row.get('charaId') not in character_ids or not isinstance(row.get('aptitudes'),dict)
               or not isinstance(row.get('global'),bool) for row in data['variants']):
            raise ValueError('Invalid character references or availability')
        if not isinstance(data['courses'],dict) or not all(
                isinstance(row,dict) and row.get('distanceType') in (1,2,3,4)
                and row.get('surface') in (1,2) and row.get('distance',0)>0
                for row in data['courses'].values()):
            raise ValueError('Invalid simulator courses')
        if not isinstance(data['skillData'],dict) or not all(isinstance(row,dict) for row in data['skillData'].values()):
            raise ValueError('Invalid simulator skills')
        master = self.root/'resources/master.mdb'
        master_hash = hashlib.sha256(master.read_bytes()).hexdigest() if master.exists() else None
        version = hashlib.sha256(json.dumps({'data':data,'worker':worker_hash,'master':master_hash,'ruleset':RULESET},sort_keys=True).encode()).hexdigest()
        with self.lock:
            self.base.mkdir(parents=True, exist_ok=True)
            path = self.base / (version + '.json')
            try:
                intact = json.loads(path.read_text(encoding='utf-8')) == data
            except (OSError,ValueError):
                intact = False
            if not intact:
                temporary = path.with_suffix('.tmp')
                temporary.write_text(json.dumps(data), encoding='utf-8')
                temporary.replace(path)
            pointer = self.base / 'current.tmp'
            pointer.write_text(version, encoding='ascii')
            pointer.replace(self.base / 'current')
            self.data = data
            self.state.update(version=version, workerHash=worker_hash, masterHash=master_hash, updatedAt=data['meta'].get('generatedAt'), sources=['Bundled Global data', 'GameTora', 'Bundled Umalator Global'])

    def load(self):
        with self.lock:
            self._load()
            cached = catalog_snapshot(self.root).get('files', {})
            stamp = (cached.get('planner/meta.json') or {}).get('generatedAt')
            if stamp and stamp != self.catalog_stamp:
                current = (self.data['meta'] or {}).get('generatedAt')
                if not current or catalog_time(stamp) >= catalog_time(current):
                    data = dict(self.data)
                    for key, path in FILES.items():
                        name = path.removeprefix('ui/public/data/')
                        if name in cached:
                            data[key] = cached[name]
                    self.publish(data, self.state['workerHash'])
                self.catalog_stamp = stamp

    def _load(self):
        if self.data is not None:
            return
        worker_hash = hashlib.sha256((self.root/'ui/public/uma-tools/umalator-global/simulator.worker.js').read_bytes()).hexdigest()
        try:
            version = (self.base/'current').read_text(encoding='utf-8').strip()
            if len(version)!=64 or any(c not in '0123456789abcdef' for c in version):
                raise ValueError('Invalid generation')
            data = json.loads((self.base/(version+'.json')).read_text(encoding='utf-8'))
            # The simulator's embedded definitions and its public context data
            # must be upgraded together even when external sources are offline.
            for key in ('courses','tracks','skillData'):
                data[key]=json.loads((self.root/FILES[key]).read_text(encoding='utf-8'))
            self.publish(data, worker_hash)
            return
        except (OSError,ValueError):
            data = {key:json.loads((self.root/path).read_text(encoding='utf-8')) for key,path in FILES.items()}
        self.publish(data, worker_hash)

    def snapshot(self):
        self.load()
        with self.lock:
            return {**self.state, 'data': self.data}

    def status(self):
        self.load()
        return dict(self.state)

    def refresh(self):
        try:
            self.load()
            headers={'User-Agent':'UmaPilot Brain knowledge freshness check'}
            request=Request(MANIFEST,headers=headers)
            with urlopen(request, timeout=15) as response:
                manifest=json.load(response)
            if not isinstance(manifest,dict) or not manifest.get('character-cards'):
                raise ValueError('Unexpected source manifest schema')
            manifest_file=self.base/'source-manifest.json'
            old=json.loads(manifest_file.read_text(encoding='utf-8')) if manifest_file.exists() else None
            if old != manifest:
                node=self.root/'.runtime/node/node-v24.14.0-win-x64/node.exe'
                # Normalize in an isolated generation, never over the live data.
                with tempfile.TemporaryDirectory(prefix='brain-knowledge-') as folder:
                    stage=Path(folder)
                    parser=stage/'work/sparkline-source/scripts/fetch-data.mjs'
                    parser.parent.mkdir(parents=True)
                    shutil.copyfile(self.root/'scripts/knowledge/fetch-data.mjs',parser)
                    support=stage/'ui/scripts/sync-project-planner-data.mjs'
                    support.parent.mkdir(parents=True)
                    shutil.copyfile(self.root/'scripts/knowledge/sync-project-planner-data.mjs',support)
                    for script in (parser,support):
                        subprocess.run([str(node),str(script)],check=True,capture_output=True,timeout=300,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
                    data=dict(self.data)
                    for key,path in FILES.items():
                        candidate=stage/path
                        if candidate.exists():data[key]=json.loads(candidate.read_text(encoding='utf-8'))
                    data['sparks']=json.loads((stage/'work/sparkline-source/src/data/static/sparks.json').read_text(encoding='utf-8'))
                    self.publish(data,self.state['workerHash'])
                temp=manifest_file.with_suffix('.tmp');temp.write_text(json.dumps(manifest),encoding='utf-8');temp.replace(manifest_file)
            with self.lock:
                self.state.update(status='current', checkedAt=now(), error=None)
        except Exception as exc:
            # Record the failing source without exposing credentials or responses.
            with self.lock:
                self.state.update(status='refresh-failed',checkedAt=now(),error=f'Knowledge refresh failed ({type(exc).__name__}). Last valid local data remains available.')

    def start(self):
        threading.Thread(target=self.refresh,name='brain-knowledge',daemon=True).start()
