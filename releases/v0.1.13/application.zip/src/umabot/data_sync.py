from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[2]
MANAGED_FILES = (
    "ui/public/data/planner/characters.json",
    "ui/public/data/planner/variants.json",
    "ui/public/data/planner/relations.json",
    "ui/public/data/planner/skills.json",
    "ui/public/data/planner/supports.json",
    "ui/public/data/sparks.json",
    "ui/public/data/umas.json",
)
CATALOG_NAMES = tuple(name.removeprefix('ui/public/data/') for name in MANAGED_FILES) + ('planner/meta.json', 'sync-meta.json')


def catalog_snapshot(root: Path) -> dict:
    path = root / 'work/catalog-cache.json'
    if not path.is_file():
        return {}
    data = _read_json(path)
    if data.get('version') != 1 or not isinstance(data.get('files'), dict):
        raise ValueError('Invalid saved catalog cache')
    return data


def read_catalog(root: Path, name: str):
    if name not in CATALOG_NAMES:
        raise ValueError('Unknown public catalog')
    cached = catalog_snapshot(root).get('files', {})
    return cached[name] if name in cached else _read_json(root / 'ui/public/data' / name)


def _catalog_hash(root: Path, name: str):
    try:
        value = read_catalog(root, name.removeprefix('ui/public/data/'))
    except FileNotFoundError:
        return None
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def _read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    temporary.replace(path)


def _fetch_json(url: str) -> Any:
    request = Request(url, headers={"User-Agent": "Uma Pilot local data sync"})
    with urlopen(request, timeout=12) as response:
        return json.load(response)


def _site_available(url: str) -> bool:
    request = Request(url, headers={"User-Agent": "Uma Pilot local data sync"})
    with urlopen(request, timeout=12):
        return True


def _generate_uma_catalog(root: Path) -> None:
    source = root / "work/sparkline-source/src/data/static"
    characters = _read_json(source / "characters.json")
    variants = _read_json(source / "variants.json")
    catalog: dict[str, dict[str, Any]] = {}
    for character in characters:
        if character.get("global"):
            catalog[str(character["id"])] = {
                "name": ["", character["name"]],
                "outfits": {},
            }
    for variant in variants:
        character = catalog.get(str(variant.get("charaId")))
        if not character or not variant.get("global"):
            continue
        title = str(variant.get("title") or "Unknown outfit")
        character["outfits"][str(variant["id"])] = f"[{title}]"
    _write_json(root / "ui/public/data/umas.json", catalog)


def sync_local_database(
    root: Path = ROOT,
    *,
    runner: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run,
    fetch_json: Callable[[str], Any] = _fetch_json,
    site_available: Callable[[str], bool] = _site_available,
    node_executable: str | None = None,
) -> dict[str, Any]:
    """Refresh a separate catalog cache using only shipped parser tools."""
    root = root.resolve()
    before = {name: _catalog_hash(root, name) for name in MANAGED_FILES}
    bundled_node = root / '.runtime/node/node-v24.14.0-win-x64/node.exe'
    node = node_executable or (str(bundled_node) if bundled_node.is_file() else shutil.which("node"))
    if not node:
        raise RuntimeError("Node.js was not found; the local data parser cannot run.")

    scripts = (
        root / "scripts/knowledge/fetch-data.mjs",
        root / "scripts/knowledge/sync-project-planner-data.mjs",
    )
    for script in scripts:
        if not script.is_file():
            raise RuntimeError(f"Data sync script is missing: {script}")
    with tempfile.TemporaryDirectory(prefix='umapilot-catalog-') as folder:
        stage = Path(folder)
        destinations = (stage / 'work/sparkline-source/scripts/fetch-data.mjs',
                        stage / 'ui/scripts/sync-project-planner-data.mjs')
        for source_script, script in zip(scripts, destinations):
            script.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source_script, script)
            try:
                runner([node, str(script)], cwd=stage, check=True, capture_output=True,
                       text=True, encoding='utf-8', errors='replace', timeout=300,
                       creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            except subprocess.CalledProcessError as exc:
                detail = (exc.stderr or exc.stdout or 'Unknown parser error').strip().splitlines()
                raise RuntimeError(f'Data parser failed: {detail[-1] if detail else "Unknown parser error"}') from exc
            except subprocess.TimeoutExpired as exc:
                raise RuntimeError('Data download timed out; previous catalogs were kept.') from exc
        source = stage / 'work/sparkline-source/src/data/static'
        (stage / 'ui/public/data').mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source / 'sparks.json', stage / 'ui/public/data/sparks.json')
        _generate_uma_catalog(stage)
        source_meta = _read_json(source / 'meta.json')
        planner_meta = _read_json(stage / 'ui/public/data/planner/meta.json')
        files = {name: _read_json(stage / 'ui/public/data' / name)
                 for name in CATALOG_NAMES if name != 'sync-meta.json'}
        for name, value in files.items():
            if not isinstance(value, (list, dict)) or not value:
                raise ValueError(f'Invalid downloaded catalog: {name}; previous catalogs were kept.')
        changed = [name for name in MANAGED_FILES if before[name] !=
                   hashlib.sha256(json.dumps(files[name.removeprefix('ui/public/data/')], sort_keys=True).encode()).hexdigest()]

    try:
        latest = fetch_json(
            "https://api.github.com/repos/kachi-dev/uma-tools/commits"
            "?path=umalator-global&per_page=1"
        )
        commit = latest[0] if isinstance(latest, list) and latest else {}
        short_sha = str(commit.get("sha") or "")[:8]
        umalator_detail = (
            f"Upstream checked at {short_sha}; bundled simulator code was preserved."
            if short_sha else "Upstream reachable; bundled simulator code was preserved."
        )
        umalator_status = "checked"
    except Exception:
        umalator_status = "unavailable"
        umalator_detail = "Upstream check failed; the bundled simulator was preserved."

    try:
        guide_available = site_available("https://uma.guide/")
    except Exception:
        guide_available = False

    counts = planner_meta.get("counts") or {}
    result = {
        "lastSyncAt": datetime.now(timezone.utc).isoformat(),
        "changedFiles": changed,
        "counts": counts,
        "sources": [
            {
                "name": "GameTora",
                "status": "updated",
                "detail": (
                    "Characters, variants, skills, sparks, supports, races and relations "
                    f"parsed with manifest validation ({counts.get('skills.json', 0)} skills)."
                ),
            },
            {
                "name": "umapyoi",
                "status": (
                    "updated"
                    if source_meta.get("sources", {}).get("umapyoiColors")
                    else "unavailable"
                ),
                "detail": "Character colors and thumbnails refreshed when available.",
            },
            {
                "name": "uma.moe",
                "status": "live",
                "detail": (
                    "Trainer and guest records stay live through the existing API instead "
                    "of being duplicated locally."
                ),
            },
            {
                "name": "Umalator Global",
                "status": umalator_status,
                "detail": umalator_detail,
            },
            {
                "name": "uma.guide",
                "status": "checked" if guide_available else "unavailable",
                "detail": "Reference site checked; no undocumented bulk scraper is used.",
            },
        ],
    }
    files['sync-meta.json'] = result
    # One atomic cache replacement, outside every updater-managed path.
    _write_json(root / 'work/catalog-cache.json', {'version': 1, 'files': files})
    return result
