"""Credential-free receipt of the choices committed to a training start."""
import hashlib
import json
from pathlib import Path

from umabot.api_project import guest_lender_id, resolve_legacies
from umabot.setup_plan import build_setup_plan
from umabot.training_watch import timestamp


def launch_details(project, trainees, guests, load, choices, payload, *, allow_paid_rentals=False):
    plan = build_setup_plan(project, trainees, guests)
    parents = resolve_legacies(plan, load, choices, allow_paid_rentals=allow_paid_rentals)
    start = payload['single_mode_start_request_common']['start_chara']
    result = []
    for index, parent in enumerate(parents):
        record = parent['record']
        selected = (start['rental_succession_trained_chara']['trained_chara_id'] if parent['rented']
                    else start[f'succession_trained_chara_id_{index + 1}'])
        if selected != record['trained_chara_id']:
            raise ValueError('Parent receipt does not match the compiled launch')
        if parent['rented'] and start['rental_succession_trained_chara']['viewer_id'] != guest_lender_id(record):
            raise ValueError('Guest receipt does not match the compiled launch')
        result.append({'slot': index + 1, 'role': parent['role'], 'name': parent['name'],
            'cardId': record['card_id'], 'veteranId': str(selected), 'borrowed': parent['rented'],
            'trainerId': str(guest_lender_id(record)) if parent['rented'] else None,
            'rankScore': record.get('rank_score'), 'fallbackReason': parent['fallbackReason']})
    return {'projectName': project['name'], 'role': plan['targetRole'], 'parents': result,
        'guestAllowance': {
            'remainingBeforeStart': max(0, int((load.get('common_define') or {}).get('new_single_mode_trained_chara_rental_max_num') or 0) - int(load.get('single_mode_rental_succession_num') or 0)),
            'maximum': int((load.get('common_define') or {}).get('new_single_mode_trained_chara_rental_max_num') or 0),
            'paidRentalsAllowed': allow_paid_rentals,
        },
        'trainingFocus': plan['trainingFocus'], 'scenario': plan['scenario'],
        'strategy': (project.get('objectives') or {}).get('strategies', []),
        'supportDeckId': start['select_deck_id'], 'supportCardIds': start['support_card_ids'],
        'borrowedSupportId': start['friend_support_card_info']['support_card_id'],
        'borrowedSupportName': plan.get('borrowedSupportName'),
        'raceCount': len(payload['start_info']['race_array'])}


class RunDetails:
    def __init__(self, root: Path, account_key):
        self.account_key = account_key
        self.path = root / 'work/run-details' / (hashlib.sha256(str(account_key).encode()).hexdigest() + '.json')
        self.memory = None

    def save(self, training, details):
        if not self.account_key or not training or not training.get('cardId') or not training.get('startTime') or not details:
            return
        self.memory = {'cardId': training['cardId'], 'startTime': training['startTime'], 'details': details}
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temp = self.path.with_suffix('.tmp')
            temp.write_text(json.dumps(self.memory), encoding='utf-8')
            temp.replace(self.path)
        except OSError:
            # A receipt write failure must never turn a successful start into a retry.
            self.memory['details'] = {**details, 'storageWarning': 'Details available for this session only; local saving failed.'}

    def current(self, training):
        if not self.account_key or not training:
            return None
        try:
            record = self.memory or json.loads(self.path.read_text(encoding='utf-8'))
            if record['cardId'] == training.get('cardId') and timestamp(record['startTime']) == timestamp(training.get('startTime')):
                return record['details']
        except (OSError, ValueError, KeyError, TypeError):
            pass
        return None
