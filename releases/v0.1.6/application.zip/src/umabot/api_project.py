"""Resolve original dashboard projects against one live API account snapshot."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any

from umabot.api_navigation import ApiNavigationError, career_state, resolve_project_presets
from umabot.setup_plan import build_setup_plan, borrow_candidates, _base_id
from umabot.api_stickers import sticker_icon_type
from umabot.skill_policy import SkillPolicy, _normalized


def guest_lender_id(record: dict) -> int:
    """The choice's viewer_id is the lender; owner_viewer_id is provenance.

    Veteran IDs are scoped to a trainer. Never join a guest to the owned roster
    by trained_chara_id alone, or substitute the original creator for its lender.
    """
    return int(record.get('viewer_id') or record.get('owner_viewer_id') or 0)


def project_revision(project: dict) -> str:
    return hashlib.sha256(json.dumps(project, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def resolve_legacies(plan: dict, load: dict, choices: dict, *, allow_paid_rentals: bool = False) -> list[dict]:
    """Resolve the same saved-sticker and known-guest rules as the original runner."""
    sticker = plan.get('legacySticker', 'carrot')
    icon_type = sticker_icon_type(sticker)
    tagged = {r['trained_chara_id'] for r in load.get('trained_chara_favorite_array') or []
              if icon_type is not None and r.get('icon_type') == icon_type}
    decision = plan.get('borrowDecision')
    resolution = choices.get('_pilotBorrowResolution') or {}
    resolved_parent = next((p for p in plan['parents']
                           if p['role'] == resolution.get('parentRole')
                           and str(p['baseId']) == str(resolution.get('parentBaseId'))
                           and not p.get('approvedVeteranId')), None)
    candidates = borrow_candidates({'borrows': plan.get('borrowRecommendations', [])}, plan.get('knownGuests', []))
    same_request = decision and resolution.get('parentRole') == decision.get('parentRole') and resolution.get('requestedTrainerId') == str(decision.get('trainerId'))
    alternate_request = any(str(r.get('trainerId')) == resolution.get('requestedTrainerId')
                            and _base_id(r.get('umaCardId')) == _base_id(resolution.get('parentBaseId')) for r in candidates)
    if decision and resolved_parent and (same_request or alternate_request):
        decision = {**decision, 'parentRole': resolved_parent['role'], 'trainerId': resolution.get('trainerId'),
                    'unavailableReason': resolution.get('fallbackReason')}
    spent = int(load.get('single_mode_rental_succession_num') or 0)
    maximum = int((load.get('common_define') or {}).get('new_single_mode_trained_chara_rental_max_num') or 0)
    result = []
    for parent in plan['parents']:
        rented = False
        candidates = []
        fallback = None
        if parent.get('approvedVeteranId'):
            candidates = [v for v in load.get('trained_chara') or []
                if str(v.get('trained_chara_id')) == str(parent['approvedVeteranId'])
                and int(v.get('use_type') or 0) == 0
                and int(v.get('card_id', 0)) // 100 == int(parent['baseId'])]
        else:
            # Guest quota and the free-rental allowance are separate. Guests
            # are optional; paid rentals follow the user's shared policy.
            fallback = None
            wants_guest = decision and decision.get('parentRole') == parent['role']
            if not decision and plan.get('allowBorrowedLegacies'):
                fallback = 'No matching saved guest for the unfinished loop parents; refresh the borrow search'
            if wants_guest:
                if spent >= maximum:
                    fallback = 'Guest attempts unavailable; using an owned veteran'
                elif load.get('single_mode_succession_free_rental_time') and not allow_paid_rentals:
                    fallback = 'Free rental allowance unavailable; using an owned veteran'
                else:
                    candidates = [v for v in (choices.get('succession_trained_chara_data') or {}).get('succession_trained_chara_array') or []
                        if str(guest_lender_id(v)) == str(decision.get('trainerId'))
                        and int(v.get('card_id', 0)) // 100 == int(parent['baseId'])]
                    if len(candidates) == 1:
                        rented = True
                    else:
                        candidates = []
                        fallback = (decision.get('unavailableReason') or 'Configured guest unavailable') + '; using an owned veteran'
            if not rented:
                owned = [v for v in load.get('trained_chara') or []
                    if int(v.get('use_type') or 0) == 0
                    and int(v.get('card_id', 0)) // 100 == int(parent['baseId'])]
                # Match the original sticker-first, then unfiltered fallback.
                candidates = [v for v in owned if v.get('trained_chara_id') in tagged] or owned
                # Seed selection is deterministic; approved lineage above is exact.
                candidates = sorted(candidates, key=lambda v: (
                    int(v.get('rank_score') or 0), int(v.get('trained_chara_id') or 0)), reverse=True)[:1]
        if len(candidates) != 1:
            raise ValueError(f'Legacy selection for slot {parent["role"]} is missing or ambiguous')
        result.append({'role': parent['role'], 'name': parent['name'], 'rented': rented,
                       'fallbackReason': fallback,
                       'record': copy.deepcopy(candidates[0])})
    return result


def resolve_project(project: dict, trainees: list, guests: list, load: dict,
                    choices: dict, pre_start: dict, data_root: Path, *, allow_paid_rentals: bool = False) -> dict:
    """Produce a reviewable draft; never copy session fields into the result."""
    plan = build_setup_plan(project, trainees, guests)
    blockers: list[str] = []
    card_id = int(plan['targetCardId'])
    if career_state(load)['active']:
        blockers.append('An existing career must be completed or handed back first')
    if card_id not in {int(c['card_id']) for c in load.get('card_list') or []}:
        blockers.append('The project trainee is not owned by this account')
    scenarios = {'URA Finale': 1, 'Unity Cup': 2, 'Grand Concert': 3, 'Trackblazer': 4}
    scenario_id = scenarios.get(plan['scenario'])
    if scenario_id not in (load.get('single_mode_scenario_id_array') or []):
        blockers.append('The project scenario is not available or mapped')
    try:
        presets = resolve_project_presets(project, load, pre_start)
    except ApiNavigationError as exc:
        blockers.append(str(exc))
        presets = None
    supports = [s for s in (choices.get('friend_support_card_data') or {}).get('support_card_data_array') or []
                if s.get('support_card_id') == int(plan['borrowedSupportId'])]
    supports.sort(key=lambda s: (s.get('limit_break_count', 0), s.get('exp', 0)), reverse=True)
    if not supports:
        blockers.append('The requested borrowed support is absent from current career choices')
    policy = SkillPolicy(project, data_root)
    configured = []
    for name in (project.get('runOptions') or {}).get('skillBuyList') or []:
        candidates = policy.by_key.get(_normalized(name), [])
        configured.append({'name': name, 'skillIds': [int(r['id']) for r in candidates]})
        if not candidates:
            blockers.append(f'Priority skill cannot be resolved: {name}')
    owned = load.get('trained_chara') or []
    parents = []
    for spec in plan['parents']:
        matches = [v for v in owned if int(v.get('card_id', 0)) // 100 == int(spec['baseId'])]
        parents.append({'role': spec['role'], 'name': spec['name'], 'ownedCandidates': len(matches)})
    try:
        selected = resolve_legacies(plan, load, choices, allow_paid_rentals=allow_paid_rentals)
        for parent in parents:
            chosen = next(v for v in selected if v['role'] == parent['role'])
            parent['selection'] = 'configured-guest' if chosen['rented'] else 'owned-veteran'
            parent['fallbackReason'] = chosen['fallbackReason']
    except ValueError as exc:
        blockers.append(str(exc))
    blockers.append('Live launch compilation has not been checked')
    return {
        'mode': 'api-project-draft', 'projectId': project.get('id'),
        'projectName': project.get('name'), 'projectRevision': project_revision(project),
        'targetRole': plan['targetRole'], 'trainee': {'cardId': card_id, 'name': plan['targetName']},
        'scenario': {'scenarioId': scenario_id, 'name': plan['scenario']},
        'trainingFocus': plan['trainingFocus'], 'presets': presets,
        'borrowedSupport': {'supportCardId': int(plan['borrowedSupportId']), 'availableCandidates': len(supports)},
        'parents': parents, 'postCareerSkillBuyList': configured,
        'trainingPrioritySkills': copy.deepcopy((pre_start.get('last_idle_single_mode_start_info') or {}).get('priority_skill_array') or []),
        'automaticSkillCount': len(policy.automatic_keys),
        'requirements': copy.deepcopy(project.get('acceptance') or {}),
        'objectives': copy.deepcopy(project.get('objectives') or {}),
        'checkpoint': copy.deepcopy(project.get('checkpoint') or {}),
        'readyForStart': not blockers, 'blockers': blockers,
        'createsPresets': False, 'executionBackend': 'api',
    }
