"""Resolve a project recommendation to a verified live rental before launch.

Search/follow fields match the installed global client v31 metadata (2026-09-09).
Never removes follows or replays a failed mutation. Saved recommendations and
known guests are checked for eligible parents; live game choices are authoritative.
"""
import copy
from datetime import datetime, timezone

from umabot.api_navigation import ApiNavigationError
from umabot.api_project import guest_lender_id
from umabot.setup_plan import build_setup_plan, borrow_candidates, _borrow_decision


def prepare_guest(navigator, project, trainees, guests, load, choices, *, allow_paid_rentals=False):
    plan = build_setup_plan(project, trainees, guests)
    original = plan.get('borrowDecision')
    if not original:
        return choices
    excluded = []
    reasons = []
    while plan.get('borrowDecision'):
        choices = _prepare_parent(navigator, project, guests, load, choices, plan,
                                  allow_paid_rentals=allow_paid_rentals)
        resolution = choices.get('_pilotBorrowResolution') or {}
        if resolution.get('trainerId') or not resolution:
            return choices
        reasons.append(resolution.get('fallbackReason') or 'No matching live guest')
        excluded.append(plan['borrowDecision']['parentRole'])
        plan['borrowDecision'] = _borrow_decision(plan['parents'], project.get('analysis') or {}, guests, excluded)
    choices['_pilotBorrowResolution']['fallbackReason'] = '; '.join(dict.fromkeys(reasons))
    return choices


def _prepare_parent(navigator, project, guests, load, choices, plan, *, allow_paid_rentals=False):
    decision = plan.get('borrowDecision')
    if not decision:
        return choices
    parent = next((p for p in plan['parents'] if p['role'] == decision['parentRole']), None)
    if not parent or parent.get('approvedVeteranId'):
        return choices
    spent = int(load.get('single_mode_rental_succession_num') or 0)
    maximum = int((load.get('common_define') or {}).get('new_single_mode_trained_chara_rental_max_num') or 0)
    if spent >= maximum or (load.get('single_mode_succession_free_rental_time') and not allow_paid_rentals):
        return choices  # The existing resolver reports the precise resource fallback.
    base = int(parent['baseId'])
    candidates = [r for r in borrow_candidates(project.get('analysis') or {}, guests)
                  if int(r.get('umaCardId') or 0) // 100 == base
                  and str(r.get('trainerId') or '').isdigit() and int(r['trainerId']) > 0]
    candidates.sort(key=lambda r: (str(r['trainerId']) != str(decision['trainerId']), -float(r.get('totalScore') or 0)))
    unique = {}
    for candidate in candidates:
        unique.setdefault(str(candidate['trainerId']), candidate)
    candidates = list(unique.values())[:4]

    def matches(data, trainer):
        return [r for r in (data.get('succession_trained_chara_data') or {}).get('succession_trained_chara_array') or []
                if guest_lender_id(r) == trainer and int(r.get('card_id') or 0) // 100 == base]

    def resolved(data, trainer=None, reason=None):
        data = copy.deepcopy(data)
        data['_pilotBorrowResolution'] = {'parentRole': parent['role'], 'parentBaseId': base,
            'requestedTrainerId': str(decision['trainerId']), 'trainerId': str(trainer) if trainer else None,
            'fallbackReason': reason}
        if trainer:
            # Only a unique rental verified in the live game list is saved.
            live = matches(data, trainer)[0]
            recommendation = next(r for r in candidates if int(r['trainerId']) == trainer)
            fields = ('trainerName', 'umaName', 'totalScore', 'affinityScore', 'whiteScore',
                      'aptitudeScore', 'winCount', 'followerCount', 'matchedWhites',
                      'blueSparks', 'pinkSparks', 'lastUpdated')
            guest = {key: copy.deepcopy(recommendation[key]) for key in fields if key in recommendation}
            guest.update(trainerId=str(trainer), umaCardId=int(live['card_id']),
                         gameRankScore=int(live.get('rank_score') or 0), status='available',
                         source='bot', verifiedAt=datetime.now(timezone.utc).isoformat())
            support = next((s for s in (data.get('friend_support_card_data') or {}).get('support_card_data_array') or []
                            if str(s.get('viewer_id')) == str(trainer)), None)
            if support:
                guest.update(supportCardId=support.get('support_card_id'), supportLimitBreak=support.get('limit_break_count'))
            data['_pilotVerifiedGuest'] = guest
        return data

    # Prefer a suitable already-available recommendation before using a follow slot.
    for candidate in candidates:
        trainer = int(candidate['trainerId'])
        if len(matches(choices, trainer)) == 1:
            return resolved(choices, trainer)

    reasons = []
    for candidate in candidates:
        trainer = int(candidate['trainerId'])
        profile = navigator.request('friend/search', {'friend_viewer_id': trainer, 'deleted_response_type': 0})
        summary = profile.get('user_info_summary') or {}
        shared = summary.get('user_trained_chara') or {}
        if str(summary.get('viewer_id')) != str(trainer) or int(shared.get('card_id') or 0) // 100 != base:
            reasons.append(f'Trainer {trainer} no longer shares the required Uma')
            continue
        friend = profile.get('friend_info') or {}
        followed = str(friend.get('friend_viewer_id')) == str(trainer) and friend.get('state') in (1, 3)
        if not followed:
            count, limit = profile.get('own_follow_num'), (load.get('common_define') or {}).get('max_follow_num')
            if type(count) is not int or type(limit) is not int or limit <= 0:
                reasons.append('Follow capacity could not be verified')
                continue
            if count >= limit:
                reasons.append('Following list is full; no existing follows were removed')
                continue
            response = navigator.request('friend/follow', {'friend_viewer_id': trainer},
                                         authorized_effects=frozenset({'follow-guest'}))
            confirmed = response.get('friend_data') or {}
            if str(confirmed.get('friend_viewer_id')) != str(trainer) or confirmed.get('state') not in (1, 3):
                raise ApiNavigationError('Guest follow outcome was not confirmed; refresh before preparing again')
        choices = navigator.request('pre_single_mode/index')
        if len(matches(choices, trainer)) == 1:
            return resolved(choices, trainer)
        reasons.append(f'Trainer {trainer} is followed but has no unique matching rental in the game list')
    return resolved(choices, reason='; '.join(dict.fromkeys(reasons)) or 'No suitable guest recommendations are available')
