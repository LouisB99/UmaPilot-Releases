"""Apply the official mandatory goal races to an existing saved agenda."""
from __future__ import annotations
import sqlite3
from pathlib import Path


class RacePlanCatalog:
    def __init__(self, database: Path):
        self.database = database

    def compose(self, saved: list[dict], card_id: int, scenario_id: int) -> list[dict]:
        if scenario_id not in {1, 2, 3}:
            raise ValueError('This scenario’s agenda composition is not verified')
        with sqlite3.connect(self.database.resolve().as_uri() + '?mode=ro', uri=True) as db:
            db.row_factory = sqlite3.Row
            programs = {r['id']: dict(r) for r in db.execute('select * from single_mode_program')}
            routes = [dict(r) for r in db.execute(
                'select * from single_mode_route where chara_id=? and scenario_id in (0,?)',
                (card_id // 100, scenario_id))]
            if len(routes) != 1 or routes[0]['condition_set_id']:
                raise ValueError('The trainee has conditional goal routes that need explicit resolution')
            rows = [dict(r) for r in db.execute(
                'select * from single_mode_route_race where race_set_id=? and target_type=1 order by sort_id',
                (routes[0]['race_set_id'],))]
        def slot(race):
            program = programs.get(race.get('program_id'))
            if not program or race.get('year') not in {1, 2, 3}:
                raise ValueError('Saved agenda contains an unknown race')
            return race['year'], program['month'], program['half']

        saved_slots = {}
        for race in saved:
            key = slot(race)
            if key in saved_slots and saved_slots[key]['program_id'] != race['program_id']:
                raise ValueError('Saved agenda contains two races in the same time slot')
            saved_slots[key] = race
        goal_groups = {}
        for row in rows:
            if row['race_type'] != 0 or row['condition_type'] != 1 or row['condition_id'] not in programs:
                raise ValueError('The trainee has an unsupported goal condition')
            race = {'year': (row['turn'] - 1) // 24 + 1, 'program_id': row['condition_id']}
            goal_groups.setdefault(slot(race), []).append((row, race))
        goals = []
        for key, group in goal_groups.items():
            candidates = {race['program_id']: race for _, race in group}
            if len(candidates) > 1:
                # Brian has paired normal/harder versions of the SAME goal.
                # They differ only in opponent program_group. They must never
                # both be sent as two agenda entries for the same turn.
                definitions = [{k: v for k, v in programs[program].items() if k not in {'id', 'program_group'}} for program in candidates]
                if (card_id // 100 != 1016 or any(row.get('determine_race') != 3 for row, _ in group)
                        or len({row['sort_id'] for row, _ in group}) != 1
                        or any(definition != definitions[0] for definition in definitions[1:])):
                    raise ValueError('The trainee has ambiguous goal branches; no start request was sent')
                # Retain a branch already selected in the saved agenda;
                # otherwise use the first/base program variant for this goal.
                wanted = (saved_slots.get(key) or {}).get('program_id')
                goals.append(candidates[wanted] if wanted in candidates else candidates[min(candidates)])
            else:
                goals.append(next(iter(candidates.values())))
        required = {slot(race): race for race in goals}
        result = []
        seen = set()
        for race in sorted(saved, key=slot):
            selected = required.get(slot(race), race)
            key = (selected['year'], selected['program_id'])
            if key not in seen:
                result.append(dict(selected))
                seen.add(key)
        for race in goals:
            key = (race['year'], race['program_id'])
            if key not in seen:
                result.append(dict(race))
                seen.add(key)
        if len({slot(race) for race in result}) != len(result):
            raise ValueError('The composed agenda contains conflicting race times; no start request was sent')
        return result
