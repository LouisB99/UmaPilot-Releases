"""Account-bound continuous careers. Stores intent, never authentication data."""
import copy
import json
import threading
from datetime import datetime, timedelta, timezone

from umabot.project_repository import ProjectRepository
from umabot.training_watch import timestamp


class ContinuousPilot:
    def __init__(self, controller, root):
        self.controller = controller
        self.root = root
        self.path = root / 'work/continuous-pilot.json'
        self.lock = threading.RLock()
        self.timer = None
        self.data = json.loads(self.path.read_text()) if self.path.exists() else {
            'enabled': False, 'state': 'stopped', 'message': 'Continuous running is off',
            'generation': 0, 'completedCareers': 0,
        }
        # An interrupted mutation is never automatically replayed.
        if self.data.get('enabled'):
            if self.data['state'] in {'starting', 'finishing', 'refilling'}:
                self.update(enabled=False, state='attention', message='Service stopped during a career mutation. Reconcile the account before resuming.')
            else:
                self.update(state='waiting-connection', message='Reconnect the same saved account to resume')
                self.arm()

    def read(self):
        with self.lock:
            return copy.deepcopy(self.data)

    def update(self, **changes):
        with self.lock:
            self.data.update(changes)
            self.path.parent.mkdir(parents=True, exist_ok=True)
            temporary = self.path.with_suffix('.tmp')
            temporary.write_text(json.dumps(self.data, indent=2))
            temporary.replace(self.path)
            return self.read()

    def bundle(self):
        bundle = ProjectRepository(self.root / 'work/project-backups').load()
        project = next((p for p in bundle['store']['projects'] if p['id'] == bundle['store'].get('activeProjectId')), None)
        if project is None:
            raise ValueError('Select and save a dashboard project first')
        return bundle, project

    def configure(self, payload):
        if type(payload.get('enabled')) is not bool:
            raise ValueError('Choose whether continuous running is enabled')
        with self.controller.lock:
            if not payload['enabled']:
                if self.timer:
                    self.timer.cancel()
                self.controller._cancel_training_followup()
                return self.update(enabled=False, state='stopped', generation=self.data['generation'] + 1,
                    nextCheckAt=None, message='Continuous Pilot is off; automatic career actions are paused')
            if self.controller.active_job_id:
                raise ValueError('Wait for the current operation before enabling continuous running')
            session = self.controller._api_session_public()
            if session.get('status') != 'idle' or not session.get('accountKey'):
                raise ValueError('Connect the intended saved account first')
            bundle, project = self.bundle()
            if payload.get('projectId') != project['id']:
                raise ValueError('The selected project differs from the saved bot project')
            if project.get('status') != 'ongoing' or project.get('needsUser'):
                raise ValueError('The project must be ongoing with no unresolved requirements')
            if (project.get('runOptions') or {}).get('scenario') != 'Grand Concert':
                raise ValueError('Continuous completion currently supports Grand Concert Independent Training only')
            monitor = self.controller.training_plan
            if session.get('screen') == 'independent-training' and (not monitor or monitor.get('projectId') != project['id']):
                raise ValueError('The active career does not match the selected project; finish or reconcile it first')
            if monitor and monitor.get('state') == 'attention':
                from umabot.setup_plan import build_setup_plan
                plan = build_setup_plan(project, bundle['trainees'], bundle['guests'])
                training = session.get('training') or {}
                same_run = (
                    monitor.get('retryableReadFailure') is True
                    and session.get('screen') == 'independent-training'
                    and monitor.get('profileId') == session.get('accountKey')
                    and monitor.get('projectId') == project['id']
                    and str(monitor.get('cardId')) == str(training.get('cardId')) == str(plan['targetCardId'])
                    and monitor.get('role') == plan['targetRole']
                    and timestamp(monitor['startTime']) == timestamp(training.get('startTime'))
                )
                if not same_run:
                    raise ValueError('Reconcile the previous training check before resuming')
                self.controller.training_plan = self.controller.training_watch.update(
                    monitor['key'], state='scheduled', retryableReadFailure=False,
                    message='Read-only check resumed after reconnecting to the same career')
            result = self.update(enabled=True, state='ready', accountKey=session['accountKey'],
                projectId=project['id'], projectName=project['name'], profileId=session.get('profileId'), reconnectAttempts=0, reconnectAt=None, nextCheckAt=None,
                generation=self.data['generation'] + 1, message='Continuous running enabled')
            self.arm(1)
            return result

    def arm(self, seconds=30):
        with self.lock:
            if self.timer:
                self.timer.cancel()
            if not self.data['enabled']:
                return
            self.timer = threading.Timer(seconds, self.tick)
            self.timer.daemon = True
            self.timer.start()

    def tick(self):
        try:
            with self.controller.lock:
                current = self.read()
                if not current['enabled'] or self.controller.active_job_id:
                    return
                session = self.controller._api_session_public()
                if session.get('status') != 'idle':
                    if current['state'] != 'waiting-connection':
                        self.update(state='waiting-connection', message='Reconnect the same saved account to resume')
                    if current.get('profileId') and (not current.get('reconnectAt') or datetime.now(timezone.utc) >= timestamp(current['reconnectAt'])):
                        self.controller.create('continuous-reconnect', {'generation': current['generation'], 'profileId': current['profileId']})
                    return
                if session.get('accountKey') != current['accountKey']:
                    self.pause('Connected account changed; continuous running stopped')
                    return
                if session.get('screen') == 'independent-training':
                    self.controller._ensure_training_followup()
                    monitor = self.controller.training_plan
                    if not monitor or monitor.get('state') not in {'scheduled', 'checking'} or monitor.get('projectId') != current['projectId']:
                        self.pause('Active training cannot be matched to this project; review the career')
                    elif current['state'] != 'training':
                        self.update(state='training', message='Training monitored; the next career follows its verified result', nextCheckAt=None)
                    return
                if current.get('nextCheckAt') and datetime.now(timezone.utc) < timestamp(current['nextCheckAt']):
                    return
                self.controller.create('continuous-step', {'generation': current['generation']})
        except Exception:
            self.pause('Continuous controller stopped; inspect the account and project before resuming')
        finally:
            self.arm()

    def pause(self, message):
        with self.controller.lock:
            self.controller._cancel_training_followup()
            return self.update(enabled=False, state='attention', nextCheckAt=None, message=message)

    def check(self, generation):
        current = self.read()
        if not current['enabled'] or current['generation'] != generation:
            return None
        session = self.controller._api_session_public()
        if session.get('status') != 'idle' or session.get('accountKey') != current['accountKey']:
            raise ValueError('The continuous-run account is no longer connected')
        bundle, project = self.bundle()
        if project['id'] != current['projectId']:
            raise ValueError('The continuous-run project changed')
        return bundle, project

    def step(self, job, payload):
        generation = payload['generation']
        selected = self.check(generation)
        if selected is None:
            return {'stage': 'Continuous running stopped before launch'}
        bundle, project = selected
        if project.get('status') == 'completed':
            self.update(enabled=False, state='completed', nextCheckAt=None, message='Project complete; continuous running finished')
            return {'stage': 'Project complete; no further careers needed'}
        if project.get('status') != 'ongoing' or project.get('needsUser'):
            raise ValueError('Project is paused or has unresolved requirements')
        self.update(state='preparing', message='Resolving the next project career', nextCheckAt=None)
        fresh = self.controller._api_rpc({'type': 'refresh'})
        if fresh.get('screen') == 'independent-training':
            self.update(state='training', message='Existing training found; using its original deadline')
            return {'stage': 'Existing training is being monitored'}
        if fresh.get('screen') != 'main-menu':
            raise ValueError('Account is not at Home or in supported Independent Training')
        if (project.get('runOptions') or {}).get('scenario') != 'Grand Concert':
            raise ValueError('Continuous completion supports Grand Concert Independent Training only')
        prepared = self.controller._prepare_project(job, {'project': project, 'trainees': bundle['trainees'], 'guests': bundle['guests']})
        if self.check(generation) is None:
            return {'stage': 'Continuous running stopped before launch'}
        draft = prepared['draft']
        if not draft['readyForStart'] and draft.get('resourceRetrySeconds') and len(draft.get('blockers', [])) == 1 and '30 naturally available TP' in draft['blockers'][0]:
            from umabot.tp_refill import settings
            if settings(self.root)['enabled'] and self.check(generation) is not None:
                self.update(state='refilling', message='Restoring TP using the authorized refill settings')
                recovered = self.controller._api_rpc({'type': 'refill-tp'})['data']
                self.controller._event(job, 'main-menu', 'TP recovery: ' + (recovered.get('source') or recovered.get('message', 'Checked')), 1.0)
                if self.check(generation) is None:
                    return {'stage': 'Continuous running stopped after TP recovery'}
                self.update(state='preparing', message='Rechecking career setup after TP recovery')
                if recovered.get('refilled'):
                    bundle, project = self.bundle()
                    draft = self.controller._prepare_project(job, {'project': project, 'trainees': bundle['trainees'], 'guests': bundle['guests']})['draft']
                else:
                    draft['blockers'] = [recovered['message']]
        if not draft['readyForStart']:
            blockers = draft.get('blockers') or ['Project setup is incomplete']
            delay = draft.get('resourceRetrySeconds')
            if delay and len(blockers) == 1:
                deadline = (datetime.now(timezone.utc) + timedelta(seconds=delay)).isoformat()
                self.update(state='waiting-resources', nextCheckAt=deadline, message=blockers[0])
                return {'stage': 'Waiting for natural resources: ' + blockers[0]}
            raise ValueError('; '.join(blockers))
        # Stop may arrive while resolving the draft. Mark the commitment under
        # the same lock. Stop pauses subsequent automatic requests. Never hold
        # the controller lock across RPC (health reads also acquire it).
        with self.controller.lock:
            if self.check(generation) is None:
                return {'stage': 'Continuous running stopped before launch'}
            self.update(state='starting', message='Starting the next career')
        result = self.controller._start_project(job, {'authorizeStart': True,
            'launchToken': draft['launchToken'], 'projectRevision': draft['projectRevision']})
        if self.read()['enabled'] and self.read()['generation'] == generation:
            self.update(state='training', message='Training started; automatic completion scheduled')
        self.controller._event(job, 'independent-training', 'Continuous pilot started the next project career', 1.0)
        return result

    def before_finish(self):
        if self.read()['enabled']:
            self.update(state='finishing', message='Buying skills, saving the veteran, and evaluating the project')

    def after_job(self, job):
        if not self.read()['enabled']:
            return
        if job.command == 'continuous-reconnect':
            if job.status == 'failed':
                attempts = self.data.get('reconnectAttempts', 0) + 1
                if attempts >= 3:
                    self.pause('Saved account reconnection failed three times; check its login in Accounts')
                else:
                    self.update(state='waiting-connection', reconnectAttempts=attempts,
                        reconnectAt=(datetime.now(timezone.utc)+timedelta(seconds=60*5**(attempts-1))).isoformat(),
                        message='Saved account connection failed; a delayed retry is scheduled')
            elif self.controller._api_session_public().get('accountKey') != self.data['accountKey']:
                self.pause('Reconnected account does not match the continuous run')
            else:
                self.update(state='ready', reconnectAttempts=0, reconnectAt=None, message='Saved account reconnected; resuming the project')
                self.arm(1)
            return
        if job.command not in {'continuous-step', 'training-followup'}:
            return
        if job.status == 'failed':
            self.pause(job.error or 'Operation failed; review before resuming')
        elif job.command == 'training-followup' and (job.result or {}).get('projectOutcome'):
            self.update(state='ready', nextCheckAt=None, completedCareers=self.data.get('completedCareers', 0) + 1,
                message='Veteran verified and project updated; preparing the next career')
            self.arm(1)
        elif job.command == 'training-followup' and 'already at Home' in (job.result or {}).get('stage', ''):
            self.pause('Career was completed outside the pilot; reconcile its project result before continuing')
