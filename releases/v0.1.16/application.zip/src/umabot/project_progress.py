from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any
from umabot.project_lineage import pair_step, pair_roles, closed_lineage, record_veteran, schedule_seed_build
from umabot.advanced_loop import PAIR_METHODS, preparing, reconcile_preparation


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def build_end_career_context(
    project: dict[str, Any], trainees: list[dict[str, Any]]
) -> dict[str, Any]:
    """Return only the project data needed to save and advance one result."""
    loop_plan = project.get("loopPlan") or {}
    slots = loop_plan.get("slots") or []
    if not slots:
        raise ValueError("The project has no linked loop slots.")
    checkpoint = project.get("checkpoint") or {}
    role = str(
        checkpoint.get("role")
        or slots[int(loop_plan.get("currentSlot") or 0)].get("role")
        or "A"
    )
    target_slot = next((slot for slot in slots if str(slot.get("role")) == role), None)
    if not target_slot or not target_slot.get("traineeId"):
        raise ValueError(f"Loop slot {role} has no trainee assigned.")
    trainee = next(
        (item for item in trainees if item.get("id") == target_slot.get("traineeId")),
        None,
    )
    if trainee is None:
        raise ValueError(f"The trainee assigned to slot {role} is not in the owned roster.")
    run_options = project.get("runOptions") or {}
    return {
        "projectId": project.get("id"),
        "targetRole": role,
        "targetCardId": trainee.get("cardId"),
        "targetName": trainee.get("name"),
        "targetOutfit": trainee.get("outfit"),
        "legacySticker": run_options.get("legacySticker") or "carrot",
    }


def apply_career_outcome(
    project: dict[str, Any], role: str, passed: bool, summary: str, veteran: dict | None = None
) -> dict[str, Any]:
    """Return the project state for the next run after one completed career."""
    updated = deepcopy(project)
    plan = updated["loopPlan"]
    slots = plan["slots"]
    current = next((slot for slot in slots if str(slot.get("role")) == role), None)
    if current is None:
        raise ValueError(f"Completed career role {role} is not in the project loop")
    current["runs"] = int(current.get("runs") or 0) + 1

    if veteran is not None:
        record_veteran(updated, veteran, passed, role)
    for slot in slots:
        slot["lineageClosed"] = closed_lineage(updated, slot.get("approvedVeteranId"))
        slot["finalCriteriaPassed"] = slot["lineageClosed"]

    next_role = role
    phase = f"Rerunning slot {role}"
    next_step = f"Run slot {role} again: {summary}"
    method = plan.get("method") or "full-roster"
    preparation = preparing(project)
    if preparation:
        if role != project['checkpoint']['role']:
            raise ValueError('Career result differs from the preparation checkpoint')
        if passed:
            current['seedCriteriaPassed'] = True
    elif method in PAIR_METHODS:
        step = pair_step(project)
        expected_role, _ = pair_roles(project)
        if role != expected_role:
            raise ValueError("Career result differs from the pair-loop checkpoint")
        plan["pairStep"] = step
        plan["pairCycle"] = int(plan.get("pairCycle") or 1)
        if passed:
            current["seedCriteriaPassed"] = True
            repairing_seed = bool(plan.get('pairSeedPending'))
            plan['pairSeedPending'] = False
            plan["pairStep"] = step if repairing_seed else (step + 1) % 4
            if step == 3 and not repairing_seed:
                plan["pairCycle"] += 1
            next_role, _ = pair_roles(updated)
            phase = "Pair-closure build"
            next_step = f"Build slot {next_role} (step {plan['pairStep'] + 1}/4, cycle {plan['pairCycle']})"
    else:
        indexed_role = str(slots[int(plan.get("currentSlot") or 0)]["role"])
        expected_role = str((project.get("checkpoint") or {}).get("role") or indexed_role)
        if role != expected_role:
            raise ValueError("Career result differs from the full-roster checkpoint")
        plan["fullCycle"] = int(plan.get("fullCycle") or 1)
        if passed:
            current["seedCriteriaPassed"] = True
            current_index = next(i for i, slot in enumerate(slots) if slot['role'] == role)
            next_index = (current_index + 1) % len(slots)
            if next_index == 0:
                plan["fullCycle"] += 1
            next_role = str(slots[next_index]['role'])
            phase = "Full-roster rotation"
            next_step = f"Build slot {next_role} (step {next_index + 1}/{len(slots)}, cycle {plan['fullCycle']})"

    if method in PAIR_METHODS:
        required_roles = {"D", str(plan.get("closureRole") or "A")}
    else:
        required_roles = {str(slot.get("role")) for slot in slots}
    complete = not preparation and all(
        any(slot.get("role") == item and slot.get("lineageClosed")
            and slot.get("finalCriteriaPassed") for slot in slots)
        for item in required_roles
    )
    if complete:
        next_role = role
        if method in PAIR_METHODS:
            plan["pairStep"] = pair_step(project)
            plan["pairCycle"] = int(project["loopPlan"].get("pairCycle") or 1)
        else:
            plan["fullCycle"] = int(project["loopPlan"].get("fullCycle") or 1)
    next_index = next((index for index, slot in enumerate(slots) if slot.get("role") == next_role), None)
    if next_index is None:
        raise ValueError(f"Next project role {next_role} is not in the project loop")

    timestamp = _now()
    plan["currentSlot"] = next_index
    checkpoint = updated["checkpoint"]
    checkpoint.update(
        role=next_role,
        phase=phase,
        nextStep=next_step,
        completedCareers=int(checkpoint.get("completedCareers") or 0) + 1,
    )
    if complete:
        checkpoint.update(phase="Project complete", nextStep=(
            "Both final parents and their full two-generation lineages are approved" if method in PAIR_METHODS
            else "Every roster member and their full two-generation lineages are approved"))
    updated["status"] = "completed" if complete else "ongoing"
    updated["updatedAt"] = timestamp
    updated["lastRunAt"] = timestamp
    if passed and not complete:
        reconcile_preparation(updated)
        schedule_seed_build(updated)
    return updated
