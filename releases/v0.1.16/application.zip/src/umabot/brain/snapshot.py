from __future__ import annotations
from pathlib import Path
from umabot.api_affinity import AffinityCatalog
from umabot.project_evaluation import evaluate_project_result
from umabot.project_lineage import approved, closed_lineage, pair_roles, full_roster_parents
from umabot.advanced_loop import PAIR_METHODS


def evidence(project: dict, veterans: list[dict], master: Path):
    """Pure planning evidence; no game requests and no approvals are changed."""
    rows = {}
    for veteran in veterans:
        identifier = str(veteran['trained_chara_id'])
        rows[identifier] = {
            'acceptance': evaluate_project_result(project, veteran),
            'recordedApproval': approved(project, identifier),
            'closed': closed_lineage(project, identifier),
        }
    plan = project.get('loopPlan') or {}
    roles = [slot['role'] for slot in plan.get('slots', [])]
    recipe = [dict(target=role, parents=parents) for role, parents in
              ([pair_roles(project, step) for step in range(4)] if plan.get('method') in PAIR_METHODS
               else [(role, full_roster_parents(role, roles)) for role in roles])]
    catalog = AffinityCatalog(master)
    return {'veterans': rows, 'recipe': recipe, 'affinity': {
        'ruleset': 'global-client-g1-group-3-v1', 'points': catalog.points,
        'members': {k:sorted(v) for k,v in catalog.members.items()},
        'saddles': catalog.saddles, 'cards': catalog.cards,
    }}
