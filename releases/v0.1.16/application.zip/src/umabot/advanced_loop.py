"""Advanced pair closure: prepare four owned members, then close the final pair."""
from copy import deepcopy

from umabot.project_lineage import approved, record_veteran, pair_roles
from umabot.project_evaluation import evaluate_project_result

PAIR_METHODS = {'pair-closure', 'advanced-pair-closure'}


def preparing(project):
    plan = project.get('loopPlan') or {}
    return plan.get('method') == 'advanced-pair-closure' and plan.get('preparationComplete') is not True


def reconcile_preparation(project, veterans=None, trainees=None):
    """Only call at Home or after recording a result; never retarget an active career.

    When supplied, veterans must be the live owned snapshot, not a guest shortlist.
    Preserve actual history and approved IDs still present and passing checks.
    """
    plan = project.get('loopPlan') or {}
    if plan.get('method') != 'advanced-pair-closure':
        return False
    before = deepcopy(project)
    slots = plan.get('slots') or []
    if len(slots) != 4 or {s.get('role') for s in slots} != set('ABCD'):
        raise ValueError('Advanced pair closure requires four assigned slots A/B/C/D')
    if veterans is not None:
        owned = {str(v['trained_chara_id']): v for v in veterans if v.get('trained_chara_id') and not v.get('use_type')}
        cards = {str(t['id']): int(t['cardId']) for t in trainees or []}
        for slot in slots:
            card = cards.get(str(slot.get('traineeId')))
            if not card:
                raise ValueError(f"Assign an owned trainee to slot {slot['role']}")
            current = owned.get(str(slot.get('approvedVeteranId')))
            if current and int(current.get('card_id') or 0) == card and approved(project, slot.get('approvedVeteranId')) and evaluate_project_result(project, current)['passed']:
                continue
            slot.pop('approvedVeteranId', None)
            candidates = [v for v in owned.values() if int(v.get('card_id') or 0) == card
                          and evaluate_project_result(project, v)['passed']]
            if candidates:
                best = max(candidates, key=lambda v: (int(v.get('rank_score') or 0), int(v['trained_chara_id'])))
                record_veteran(project, best, True, slot['role'])
    missing = [s for s in sorted(slots, key=lambda s:s['role']) if not approved(project, s.get('approvedVeteranId'))]
    was_preparing = plan.get('preparationComplete') is not True
    if missing:
        plan['preparationComplete'] = False
        plan['pairSeedPending'] = False
        role = missing[0]['role']
        project['checkpoint'].update(role=role, phase='Preparing owned roster',
            nextStep=f"Prepare slot {role} ({4-len(missing)}/4 members approved); guests follow project settings")
    elif was_preparing:
        plan.update(preparationComplete=True, pairStep=0, pairCycle=1, pairSeedPending=False)
        role = 'C'
        project['checkpoint'].update(role=role, phase='Classic closure · prepared roster',
            nextStep='All four members passed. Build C using owned A + B; guest parents are disabled during closure')
    else:
        return project != before
    plan['currentSlot'] = next(i for i,s in enumerate(slots) if s['role'] == role)
    if project.get('status') == 'completed' and missing:
        project['status'] = 'ongoing'
    return project != before
