from __future__ import annotations

import atexit
import json
import os
import queue
import secrets
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Callable
from urllib.parse import parse_qs, urlsplit

from umabot.runtime_version import source_version
from umabot.connection_preference import ConnectionPreference

# Capture once, before loading the service: requests must describe running code,
# not newly installed files that this process has never loaded.
SERVICE_VERSION = source_version()

from umabot.api_career import ApiCareerBootstrap, build_career_request_manifest
from umabot.account_profiles import AccountProfileStore
from umabot.data_sync import sync_local_database
from umabot.game_state import CapturedGameStateBackend, LookupCatalog
from umabot.project_progress import apply_career_outcome, build_end_career_context
from umabot.project_repository import ProjectRepository
from umabot.dashboard_storage import DashboardStorage, StorageConflict
from umabot.capture_catalog import CaptureCatalog
from umabot.protocol_lab import CapturedReplayClient, SequentialCapturedReplayClient
from umabot.setup_plan import build_setup_plan
from umabot.steam_auth import SteamAuthManager
from umabot.training_watch import TrainingWatch, timestamp
from umabot.continuous import ContinuousPilot
from umabot.brain.knowledge import BrainKnowledge
from umabot.brain.repository import BrainRepository
from umabot.brain.snapshot import evidence as brain_evidence


ROOT = Path(__file__).resolve().parents[2]
HOST = "127.0.0.1"
PORT = 8767
BRAIN_KNOWLEDGE = BrainKnowledge(ROOT)
BRAIN_CACHE = BrainRepository(ROOT)


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(slots=True)
class Job:
    id: str
    command: str
    status: str = "queued"
    stage: str = "Queued"
    progress: int = 0
    created_at: str = field(default_factory=now)
    updated_at: str = field(default_factory=now)
    events: list[dict[str, Any]] = field(default_factory=list)
    result: dict[str, Any] | None = None
    error: str | None = None


class AutomaticPilotStopped(RuntimeError):
    """Automation was disabled before the next request was sent."""


class BotController:
    def __init__(self) -> None:
        self.jobs: dict[str, Job] = {}
        self.lock = threading.RLock()
        self.active_job_id: str | None = None
        self.latest_job_id: str | None = None
        self.training_timer: threading.Timer | None = None
        self.training_check_at: str | None = None
        self.training_watch = TrainingWatch(ROOT / "work/training-watch.json")
        self.training_plan = None
        self.training_timer_key = None
        self.api_session_process: subprocess.Popen[str] | None = None
        self.api_session_state: dict[str, Any] = {"status": "disconnected"}
        self.api_session_io_lock = threading.Lock()
        self.continuous = ContinuousPilot(self, ROOT)

    def _api_session_public(self) -> dict[str, Any]:
        with self.lock:
            process = self.api_session_process
            if process is not None and process.poll() is not None:
                self.api_session_process = None
                self.api_session_state = {"status": "disconnected"}
            return dict(self.api_session_state)

    def restore_connection(self):
        # Called once after the service binds its port. This restores only the
        # connection; ContinuousPilot retains sole control of career actions.
        with self.lock:
            if self.active_job_id or self._api_session_public().get('status') != 'disconnected':
                return
            profile_id = ConnectionPreference(ROOT).target(ACCOUNT_STORE, self.continuous.read().get('profileId'))
            if profile_id:
                self.create('verify-account', {'profileId': profile_id})

    def disconnect_account(self, profile_id=None):
        with self.lock:
            current = self.api_session_state.get('profileId')
            if profile_id is not None and current and current != ACCOUNT_STORE._validate_id(profile_id):
                raise ValueError('The connected session belongs to another profile')
            if self.active_job_id:
                raise RuntimeError('Wait for the current operation before disconnecting')
            self.continuous.configure({'enabled': False})
            result = self.close_api_session(profile_id)
            ConnectionPreference(ROOT).remember(None)
            return result

    def status(self) -> dict[str, Any]:
        session = self._api_session_public()
        if session.get('status') == 'idle':
            try:
                response = self._api_rpc({'type': 'status'}, timeout=3)
                session = self._api_session_public()
            except RuntimeError:
                session = self._api_session_public()
        with self.lock:
            return {'online': True, 'connected': session.get('status') == 'idle',
                'serial': 'official-api', 'screen': session.get('screen', 'disconnected'),
                'confidence': None, 'executionBackend': 'api',
                'activeJobId': self.active_job_id, 'latestJobId': self.latest_job_id,
                'continuous': self.continuous.read(), 'trainingCheckAt': self.training_check_at, 'trainingMonitor': self.training_plan, 'apiSession': session}

    def create(self, command: str, payload: dict[str, Any]) -> Job:
        with self.lock:
            if self.active_job_id:
                active = self.jobs.get(self.active_job_id)
                if active and active.status in {"queued", "running"}:
                    raise RuntimeError(f"Bot is already running {active.command}.")
            if self.continuous.read()['enabled'] and command in {'auto', 'prepare-project', 'start-project', 'end-career'}:
                raise ValueError('Stop continuous running before issuing a manual career command')
            for prior in list(self.jobs)[:-199]:
                if self.jobs[prior].status in {'complete', 'failed'}:
                    del self.jobs[prior]
            job = Job(id=uuid.uuid4().hex, command=command)
            self.jobs[job.id] = job
            self.active_job_id = job.id
            self.latest_job_id = job.id
        worker = threading.Thread(target=self._run, args=(job.id, payload), daemon=True)
        worker.start()
        return job

    def _ensure_training_followup(self):
        session = self._api_session_public()
        training = session.get('training') or {}
        profile = session.get('accountKey') or session.get('profileId') or session.get('sourceSession')
        if session.get('status') != 'idle' or not profile or not training.get('cardId'):
            with self.lock:
                if self.training_timer:
                    self.training_timer.cancel()
                self.training_timer = None
                self.training_timer_key = None
                self.training_check_at = None
                self.training_plan = None
            return
        try:
            bundle = ProjectRepository(ROOT / 'work/project-backups').load()
            project = next(p for p in bundle['store']['projects'] if p['id'] == bundle['store']['activeProjectId'])
            plan = build_setup_plan(project, bundle['trainees'], bundle['guests'])
            if int(plan['targetCardId']) != int(training['cardId']):
                return
            with self.lock:
                record = self.training_watch.ensure(profile, training, {**project, 'trainingRole': plan['targetRole'], 'traineeName': plan['targetName']})
                active = self.jobs.get(self.active_job_id)
                if record['state'] == 'checking' and (not active or active.command != 'training-followup'):
                    record = self.training_watch.update(record['key'], state='attention', message='Service restarted during a check; review the career before continuing')
                self.training_plan = record
                if not self.continuous.read()['enabled']:
                    self._cancel_training_followup()
                    return
                self.training_check_at = record['checkAt'] if record['state'] == 'scheduled' else None
                if record['state'] != 'scheduled' or self.training_timer_key == record['key']:
                    return
                self._arm_training_timer(record)
        except (ValueError, KeyError, OSError, StopIteration):
            # An incomplete or unrelated project must never finish this account's career.
            return

    def _cancel_training_followup(self):
        with self.lock:
            if self.training_timer:
                self.training_timer.cancel()
            self.training_timer = None
            self.training_timer_key = None
            self.training_check_at = None

    def _require_automatic_pilot(self, generation):
        current = self.continuous.read()
        if not current['enabled'] or current['generation'] != generation:
            raise AutomaticPilotStopped('Continuous Pilot is off; automatic career actions are paused')

    def _arm_training_timer(self, record, retry_seconds=None):
        if not self.continuous.read()['enabled']:
            self._cancel_training_followup()
            return
        if self.training_timer:
            self.training_timer.cancel()
        seconds = retry_seconds if retry_seconds is not None else max(0, (timestamp(record['checkAt']) - datetime.now(timezone.utc)).total_seconds())
        timer = threading.Timer(seconds, lambda: self._training_due(record['key']))
        timer.daemon = True
        self.training_timer = timer
        self.training_timer_key = record['key']
        timer.start()

    def _training_due(self, key):
        with self.lock:
            if self.training_timer_key != key:
                return
            self.training_timer = None
            self.training_timer_key = None
            current = self.continuous.read()
            if not current['enabled']:
                self.training_check_at = None
                return
            record = self.training_watch.read()['runs'][key]
            session = self._api_session_public()
            if record['state'] != 'scheduled':
                return
            if session.get('status') != 'idle' or (session.get('accountKey') or session.get('profileId') or session.get('sourceSession')) != record['profileId']:
                return  # Reconnect restores this same deadline, without rerolling.
            try:
                self.create('training-followup', {'watchKey': key, 'generation': current['generation']})
            except RuntimeError:
                self._arm_training_timer(record, retry_seconds=10)

    def _training_followup(self, job, payload):
        generation = payload.get('generation', self.continuous.read()['generation'])
        try:
            self._require_automatic_pilot(generation)
        except AutomaticPilotStopped as exc:
            return {'stage': str(exc)}
        key = payload['watchKey']
        record = self.training_watch.read()['runs'][key]
        session = self._api_session_public()
        if (session.get('accountKey') or session.get('profileId') or session.get('sourceSession')) != record['profileId']:
            raise ValueError('Training check belongs to a different account')
        if record['state'] != 'scheduled' or datetime.now(timezone.utc) < timestamp(record['checkAt']):
            raise ValueError('Training check is not due')
        self.training_plan = self.training_watch.update(key, state='checking')
        self.training_check_at = None
        completion_started = False
        try:
            bundle = ProjectRepository(ROOT / 'work/project-backups').load()
            if bundle['store']['activeProjectId'] != record['projectId']:
                raise ValueError('The training project changed; automatic completion paused')
            project = next(p for p in bundle['store']['projects'] if p['id'] == record['projectId'])
            plan = build_setup_plan(project, bundle['trainees'], bundle['guests'])
            if int(plan['targetCardId']) != record['cardId'] or plan['targetRole'] != record['role']:
                raise ValueError('The project checkpoint changed; automatic completion paused')
            fresh = self._api_rpc({'type': 'refresh'}, automatic_generation=generation)
            training = fresh.get('training') or {}
            if fresh.get('screen') == 'main-menu':
                result = {'stage': 'Training check complete; account is already at Home'}
            else:
                if training.get('cardId') != record['cardId'] or timestamp(training.get('startTime')) != timestamp(record['startTime']):
                    raise ValueError('Active career changed; automatic completion paused')
                if not training.get('scheduledEndReached'):
                    later = max(datetime.now(timezone.utc) + timedelta(minutes=1), timestamp(training['endTime']))
                    self.training_plan = self.training_watch.update(key, state='scheduled', checkAt=later.isoformat())
                    self.training_check_at = later.isoformat()
                    with self.lock:
                        self._arm_training_timer(self.training_plan)
                    return {'stage': 'Server still reports training; next check scheduled'}
                self._event(job, 'independent-training', 'Scheduled training check reached', 1.0)
                self._require_automatic_pilot(generation)
                self.continuous.before_finish()
                completion_started = True
                result = self._end_career(job, {'project': project, 'generation': generation})
            self.training_plan = self.training_watch.update(key, state='complete', message=result['stage'], completedAt=datetime.now().astimezone().isoformat())
            return result
        except AutomaticPilotStopped as exc:
            self.training_plan = self.training_watch.update(key, state='scheduled', message=str(exc))
            self._cancel_training_followup()
            return {'stage': str(exc)}
        except Exception:
            self.training_plan = self.training_watch.update(key, state='attention', retryableReadFailure=not completion_started, message='Automatic completion stopped; inspect the latest operation')
            raise

    def get(self, job_id: str) -> Job | None:
        with self.lock:
            return self.jobs.get(job_id)

    def save_project_backup(self, payload):
        with self.lock:
            continuous = self.continuous.read()
            if continuous['enabled']:
                saved = ProjectRepository(ROOT / 'work/project-backups').load()
                incoming = payload.get('store') or {}
                prior = next(p for p in saved['store']['projects'] if p['id'] == continuous['projectId'])
                current = next((p for p in incoming.get('projects', []) if p.get('id') == continuous['projectId']), None)
                if incoming.get('activeProjectId') != continuous['projectId'] or current != prior:
                    raise ValueError('Stop continuous running before changing its active project')
            monitor = self.training_plan
            ids = {p.get('id') for p in (payload.get('store') or {}).get('projects', []) if isinstance(p, dict)}
            if monitor and monitor['state'] in {'scheduled', 'checking', 'attention'} and monitor['projectId'] not in ids:
                raise ValueError('A training run still uses the saved project; a different browser cannot replace its backup')
            if (monitor and monitor['state'] in {'scheduled', 'checking', 'attention'}) or getattr(self, 'active_job_id', None):
                prior_store = ProjectRepository(ROOT / 'work/project-backups').load()['store']
                def topology(p):
                    plan = p.get('loopPlan') or {}
                    return plan.get('method'), plan.get('closureRole'), [(s.get('role'), s.get('traineeId')) for s in plan.get('slots', [])]
                for p in (payload.get('store') or {}).get('projects', []):
                    prior = next((old for old in prior_store['projects'] if old['id'] == p.get('id')), None)
                    if prior and topology(prior) != topology(p) and (getattr(self, 'active_job_id', None) or p.get('id') == monitor.get('projectId')):
                        raise ValueError('Finish the current career and stop Pilot before rearranging its members or changing its loop method')
            return ProjectRepository(ROOT / 'work/project-backups').save(payload)

    def _update(self, job: Job, **changes: Any) -> None:
        with self.lock:
            for key, value in changes.items():
                setattr(job, key, value)
            job.updated_at = now()

    def _event(self, job: Job, screen: str, action: str, score: float) -> None:
        with self.lock:
            job.events.append({"screen": screen, "action": action, "score": score, "at": now()})
            job.stage = f"{screen}: {action}"
            job.updated_at = now()

    def _run(self, job_id: str, payload: dict[str, Any]) -> None:
        job = self.jobs[job_id]
        initial_stage = {
            "sync-data": "Preparing local database sync",
            "verify-account": "Preparing the isolated account session",
        }.get(job.command, "Connecting to the official API")
        self._update(job, status="running", stage=initial_stage, progress=2)
        try:
            if job.command == 'finish-untracked':
                if self.continuous.read()['enabled']:
                    raise ValueError('Stop continuous running before clearing an unrelated career')
                response = self._api_rpc({'type': 'finish-untracked',
                    'authorizeFinish': payload.get('authorizeFinish'),
                    'expectedCardId': payload.get('expectedCardId'),
                    'expectedStartTime': payload.get('expectedStartTime')}, timeout=90)
                result = {'stage': 'Fan-farming veteran saved; account returned Home', **response['data']}
            elif job.command == "continuous-reconnect":
                current = self.continuous.read()
                if not current['enabled'] or current['generation'] != payload.get('generation'):
                    result = {'stage': 'Continuous reconnection cancelled'}
                else:
                    result = self._verify_account(job, payload)
            elif job.command == "continuous-step":
                result = self.continuous.step(job, payload)
            elif job.command == "training-followup":
                result = self._training_followup(job, payload)
            elif job.command == "auto":
                result = self._auto(job, payload)
            elif job.command == "review-career":
                result = self._review_career(job, payload)
            elif job.command == "end-career":
                result = self._end_career(job, payload)
            elif job.command == "prepare-project":
                result = self._prepare_project(job, payload)
            elif job.command == 'start-project':
                result = self._start_project(job, payload)
            elif job.command == "sync-data":
                result = self._sync_data(job)
            elif job.command == "handoff-client":
                result = self._handoff_client(job, payload)
            elif job.command == "verify-account":
                result = self._verify_account(job, payload)
            else:
                raise ValueError(f"Unknown command: {job.command}")
            if job.command in {'verify-account', 'continuous-reconnect'} and result.get('status') == 'idle':
                try:
                    ConnectionPreference(ROOT).remember(result['profileId'])
                except OSError:
                    self._event(job, 'account', 'Connected, but the reconnect preference could not be saved', 0.9)
            self._update(
                job,
                status="complete",
                stage=result.get("stage", "Complete"),
                progress=100,
                result=result,
            )
        except Exception as exc:
            failure = {"trace": traceback.format_exc(limit=8)}
            if job.result and job.result.get("followedGuest"):
                failure["followedGuest"] = job.result["followedGuest"]
            self._update(job, status="failed", stage="Stopped safely", error=str(exc), result=failure)
        finally:
            with self.lock:
                if self.active_job_id == job.id:
                    self.active_job_id = None
            self._ensure_training_followup()
            self.continuous.after_job(job)
            try:
                from umabot.discord_notifications import job_finished
                job_finished(ROOT, job)
            except Exception:
                pass  # Notifications must never interrupt career progression.

    def _sync_data(self, job: Job) -> dict[str, Any]:
        self._update(job, stage="Downloading and validating game data", progress=15)
        result = sync_local_database(ROOT)
        self._update(job, stage="Local database refreshed", progress=95)
        return {"stage": "Local database refreshed", **result}

    def _verify_account(self, job: Job, payload: dict[str, Any]) -> dict[str, Any]:
        """Open a parked main-menu session in a credential-isolated process."""
        profile_id = ACCOUNT_STORE._validate_id(str(payload.get("profileId") or ""))
        profile = ACCOUNT_STORE.get(profile_id)
        if profile is None or profile.status != "ready" or not profile.has_saved_session:
            raise ValueError("Select a Steam profile with a ready saved session")
        if profile.assigned_function != "pilot":
            raise ValueError("This Steam profile is assigned to Janus; assign it to Pilot before connecting")
        linked = [
            game
            for game in ACCOUNT_STORE.list_game_accounts(profile_id)
            if game.status == "linked-verified"
        ]
        if len(linked) > 1:
            raise ValueError("The Steam profile has multiple verified game accounts")
        with self.lock:
            active = self.api_session_process
            if active is not None and active.poll() is None:
                if self.api_session_state.get('profileId') != profile_id:
                    raise RuntimeError("Another account session is connected; disconnect it before switching")
                if self.api_session_state.get('status') == 'idle' and self.api_session_state.get('sessionValid') is True:
                    return {**self.api_session_state, 'stage': 'API session already connected', 'readOnly': True}
        if active is not None and active.poll() is None:
            # An invalid API session can leave its IPC worker alive. Retire only
            # this same profile's worker; never replay its last game operation.
            self._update(job, stage='Closing the expired account connection before reconnecting', progress=5)
            self.close_api_session(profile_id)
        with self.lock:
            if self.api_session_process is not None and self.api_session_process.poll() is None:
                raise RuntimeError('The account connection changed; wait for it before reconnecting')
            self.api_session_process = None
            self.api_session_state = {"status": "connecting", "profileId": profile_id}
        node = shutil.which("node")
        if not node:
            raise RuntimeError("Node.js is required for the Steam ticket worker")
        script = ROOT / "Converter/live_game_session_worker.py"
        worker = ROOT / "Converter/steam_ticket_worker.js"
        node_modules = ROOT / "Converter/node_modules"
        for required in (script, worker, node_modules):
            if not required.exists():
                raise RuntimeError("The local account verification runtime is incomplete")

        self._update(job, stage="Verifying saved Steam and Uma identities", progress=12)
        environment = os.environ.copy()
        environment["UMAPILOT_ALLOW_GAME_SESSION"] = "YES"
        python_paths = [str(ROOT / "src")]
        bundled_packages = ROOT / "work/tools/python-packages"
        if bundled_packages.is_dir():
            python_paths.append(str(bundled_packages))
        if environment.get("PYTHONPATH"):
            python_paths.append(environment["PYTHONPATH"])
        environment["PYTHONPATH"] = os.pathsep.join(python_paths)
        command = [
            sys.executable,
            str(script),
            "--node",
            node,
            "--worker",
            str(worker),
            "--account-vault",
            str(ROOT / "work/account-profiles"),
            "--profile-id",
            profile_id,
            "--node-modules",
            str(node_modules),
            "--lookup-root",
            str(ROOT / "uma_api_capture/lookups"),
            "--unity-version",
            "2022.3.62f2",
            "--transition-delay",
            "0.28",
        ]
        self._update(job, stage="Opening the account session", progress=28)
        try:
            process = subprocess.Popen(
                command,
                cwd=ROOT,
                env=environment,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
        except OSError as exc:
            with self.lock:
                self.api_session_state = {"status": "disconnected"}
            raise RuntimeError("Could not start the isolated game-session worker") from exc
        line_queue: queue.Queue[str] = queue.Queue(maxsize=1)
        assert process.stdout is not None
        reader = threading.Thread(
            target=lambda: line_queue.put(process.stdout.readline()), daemon=True
        )
        reader.start()
        try:
            line = line_queue.get(timeout=90)
        except queue.Empty as exc:
            process.terminate()
            process.wait(timeout=5)
            with self.lock:
                self.api_session_state = {"status": "disconnected"}
            raise RuntimeError("Account connection timed out and was stopped") from exc
        if not line:
            detail = process.stderr.read(400) if process.stderr else ""
            with self.lock:
                self.api_session_state = {"status": "disconnected"}
            raise RuntimeError(detail.strip() or "Account session worker stopped unexpectedly")
        try:
            verification = json.loads(line)
        except json.JSONDecodeError as exc:
            process.terminate()
            process.wait(timeout=5)
            with self.lock:
                self.api_session_state = {"status": "disconnected"}
            raise RuntimeError("Account verification returned an invalid local result") from exc
        if not isinstance(verification, dict):
            raise RuntimeError("Account verification returned an unexpected local result")
        if (verification.get('type') != 'ready' or verification.get('sessionValid') is not True or
                verification.get('status') != 'idle' or verification.get('readOnly') is not True or
                verification.get('requestCount') != 5):
            process.terminate()
            process.wait(timeout=5)
            with self.lock:
                self.api_session_state = {'status': 'disconnected'}
            reason = verification.get('connectionError') if verification.get('type') == 'error' else None
            raise RuntimeError(reason or 'Account connection did not establish a valid API session')
        public_state = {
            "status": "idle",
            "screen": verification.get("screen"),
            "profileId": profile_id,
            "gameAccountId": next(game.id for game in ACCOUNT_STORE.list_game_accounts(profile_id) if game.status == "linked-verified"),
            "connectedAt": now(),
            "readOnly": True,
            "requestCount": verification.get("requestCount", 0),
            "sessionValid": True,
            "snapshotSummary": verification.get("snapshotSummary"),
            "training": verification.get("training"),
            "accountKey": verification.get("accountKey"),
        }
        with self.lock:
            self.api_session_process = process
            self.api_session_state = public_state
        threading.Thread(
            target=self._watch_api_session,
            args=(process,),
            daemon=True,
        ).start()
        self._event(job, str(verification.get('screen')), "api_session_connected", 1.0)
        return {
            "stage": "API session connected",
            **public_state,
            "readOnly": True,
            "verification": verification,
        }

    def _watch_api_session(self, process: subprocess.Popen[str]) -> None:
        process.wait()
        with self.lock:
            if self.api_session_process is process:
                self.api_session_process = None
                self.api_session_state = {"status": "disconnected"}

    def api_account_snapshot(self, profile_id: str) -> dict[str, Any]:
        """Read the sanitized load/index snapshot already held by the worker.

        This is local IPC only. It cannot issue another game request.
        """
        validated_profile_id = ACCOUNT_STORE._validate_id(profile_id)
        with self.lock:
            process = self.api_session_process
            current_profile = str(self.api_session_state.get("profileId") or "")
        if process is None or process.poll() is not None:
            raise RuntimeError("The headless account session is not connected")
        if current_profile != validated_profile_id:
            raise ValueError("The connected session belongs to another profile")
        response = self._api_rpc({'type': 'snapshot'}, timeout=10)
        snapshot = response.get("data") if isinstance(response, dict) else None
        if (
            not isinstance(snapshot, dict)
            or response.get("type") != "snapshot"
            or snapshot.get("mode") != "live-read-only"
            or snapshot.get("sourceEndpoint") != "load/index"
        ):
            raise RuntimeError("The worker did not return a safe account snapshot")
        return snapshot

    def assign_account_function(self, profile_id: str, function: str):
        with self.lock:
            profile = ACCOUNT_STORE.get(profile_id)
            if profile is None:
                raise ValueError('Steam profile not found')
            if profile.assigned_function == function:
                return profile.public()
            pilot = self.continuous.read()
            session = self.api_session_state
            if self.active_job_id or (pilot.get('enabled') and pilot.get('profileId') == profile_id):
                raise ValueError('Stop the current task before changing its assigned function')
            if session.get('profileId') == profile_id and self.api_session_process is not None and self.api_session_process.poll() is None:
                raise ValueError('Disconnect this account session before changing its assigned function')
            if profile.status in {'starting', 'guard-required', 'verifying', 'waiting-approval'}:
                raise ValueError('Finish Steam sign-in before changing its assigned function')
            from .profile_lease import ProfileLease
            lease = ProfileLease(ROOT, profile_id)
            try:
                return ACCOUNT_STORE.assign_function(profile_id, function).public()
            finally:
                lease.close()

    def remove_account(self, profile_id: str) -> dict[str, Any]:
        """Stop this profile's live work before deleting its saved credentials."""
        normalized = ACCOUNT_STORE._validate_id(profile_id)
        with self.lock:
            if self.active_job_id:
                raise RuntimeError('Wait for the current operation to finish before removing an account')
            owns_session = self.api_session_state.get('profileId') == normalized
            owns_pilot = self.continuous.read().get('profileId') == normalized
            if owns_session or owns_pilot:
                self.continuous.configure({'enabled': False})
            if owns_session:
                self.close_api_session(normalized)
            return STEAM_AUTH.remove(normalized)

    def close_api_session(self, profile_id: str | None = None) -> dict[str, Any]:
        with self.lock:
            if self.training_timer:
                self.training_timer.cancel()
            self.training_timer = None
            self.training_timer_key = None
        with self.lock:
            process = self.api_session_process
            current_profile = str(self.api_session_state.get("profileId") or "")
        if process is None or process.poll() is not None:
            with self.lock:
                self.api_session_process = None
                self.api_session_state = {"status": "disconnected"}
            return {"status": "disconnected"}
        if profile_id is not None and current_profile != ACCOUNT_STORE._validate_id(profile_id):
            raise ValueError("The connected session belongs to another profile")
        try:
            with self.api_session_io_lock:
                if process.stdin is not None:
                    process.stdin.write('{"type":"close"}\n')
                    process.stdin.flush()
                process.wait(timeout=20)
        except (BrokenPipeError, OSError, subprocess.TimeoutExpired):
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)
        with self.lock:
            if self.api_session_process is process:
                self.api_session_process = None
            self.api_session_state = {"status": "disconnected"}
        return {"status": "disconnected"}

    def _auto(self, job: Job, payload: dict[str, Any]) -> dict[str, Any]:
        fresh = self._api_rpc({'type': 'refresh'})
        self._event(job, str(fresh.get('screen')), 'Account state refreshed through API', 1.0)
        if fresh.get('screen') == 'independent-training':
            if (fresh.get('training') or {}).get('scheduledEndReached'):
                return self._end_career(job,payload)
            return {'stage': 'Independent Training is active', 'careerActive': True,
                    'executionBackend': 'api', 'snapshot': fresh.get('data')}
        if fresh.get('screen') == 'normal-career':
            raise ValueError('The active normal career has not been mapped for API execution')
        return self._prepare_project(job, payload)

    def _review_career(self, job: Job, payload: dict[str, Any]) -> dict[str, Any]:
        fresh = self._api_rpc({'type': 'refresh'})
        return {'stage': 'Career state refreshed', 'screen': fresh.get('screen'),
                'executionBackend': 'api', 'snapshot': fresh.get('data'),
                'completionAvailable': False}

    def _end_career(self, job: Job, payload: dict[str, Any], **kwargs) -> dict[str, Any]:
        from umabot.api_outcome import record_completion
        def request(control):
            if getattr(job, 'command', None) == 'training-followup':
                generation = payload['generation']
                self._require_automatic_pilot(generation)
                return self._api_rpc(control, automatic_generation=generation)
            return self._api_rpc(control)
        bundle=ProjectRepository(ROOT/'work/project-backups').load()
        project=next(p for p in bundle['store']['projects'] if p['id']==bundle['store']['activeProjectId'])
        requested=payload.get('project')
        if requested is not None and requested!=project:
            raise ValueError('The active project changed; refresh before completing')
        request({'type':'collect-career','authorizeComplete':True})
        purchases=[]
        for _ in range(80):
            plan=request({'type':'plan-skills','project':project})['data']
            if not plan['skills']: break
            self._update(job,stage='Buying '+plan['phase']+' skills through API',progress=30)
            bought=request({'type':'buy-skills','project':project,'authorizeSkillPoints':True})['data']
            purchases.append(bought)
        else:
            raise ValueError('Skill purchase bound reached; completion was not sent')
        self._update(job,stage='Saving and verifying the veteran through API',progress=70)
        completed=request({'type':'finish-career','project':project,'authorizeFinish':True})['data']
        result=record_completion(ROOT,completed)
        outcome = result['projectOutcome']
        if outcome['passed'] and outcome.get('sticker') not in (None, 'not-set'):
            try:
                mark = request({'type': 'mark-project-veteran', 'veteranId': outcome['veteranId'],
                    'sticker': outcome['sticker'], 'authorizeSticker': True})
                outcome['stickerApplied'] = mark['data']['stickerApplied']
            except RuntimeError as exc:
                # The approved veteran ID was durably recorded before this
                # optional annotation. Never lose the result or repeat finish.
                result['stickerWarning'] = f'Project result saved; sticker requires reconciliation: {exc}'
                self._event(job, 'main-menu', result['stickerWarning'], 0.9)
        result['skillPurchase']={'batches':purchases}
        return result

    def _prepare_project(self, job: Job, payload: dict[str, Any]) -> dict[str, Any]:
        project = payload.get('project')
        if not isinstance(project, dict) or not isinstance(payload.get('trainees'), list):
            raise ValueError('The active project and trainee roster are required')
        bundle = ProjectRepository(ROOT / 'work/project-backups').load()
        if bundle['store'].get('activeProjectId') != project.get('id'):
            raise ValueError('The active dashboard project changed; refresh before proceeding')
        saved = next(p for p in bundle['store']['projects'] if p['id'] == project['id'])
        if saved != project:
            raise ValueError('Project backup is still updating; retry when the local backup is saved')
        # Rebuild only at Home. A saved opt-in must never retarget a career
        # already running (including one awaiting collection after a restart).
        from umabot.project_lineage import schedule_seed_build
        from umabot.advanced_loop import reconcile_preparation
        from copy import deepcopy
        revised = deepcopy(saved)
        if saved['loopPlan'].get('method') == 'advanced-pair-closure':
            fresh = self._api_rpc({'type': 'refresh'})
            if fresh.get('screen') == 'main-menu':
                snapshot = fresh.get('data') or {}
                if not isinstance(snapshot.get('veterans'), list):
                    raise ValueError('The live owned veteran roster is unavailable; advanced preparation cannot be verified')
                reconcile_preparation(revised, snapshot['veterans'], bundle['trainees'])
                if revised != saved:
                    saved.clear()
                    saved.update(revised)
                    saved['updatedAt'] = now()
                    ProjectRepository(ROOT / 'work/project-backups').save(bundle)
                    project = saved
        if schedule_seed_build(revised):
            fresh = self._api_rpc({'type': 'refresh'})
            if fresh.get('screen') == 'main-menu':
                saved.clear()
                saved.update(revised)
                saved['updatedAt'] = now()
                ProjectRepository(ROOT / 'work/project-backups').save(bundle)
                project = saved
        scenario = {'Grand Concert': 3, 'URA Finale': 1, 'Unity Cup': 2, 'Trackblazer': 4}.get(
            (project.get('runOptions') or {}).get('scenario', 'Grand Concert'))
        self._update(job, stage='Resolving the saved project against live account data', progress=30)
        response = self._api_rpc({'type': 'project-draft', 'authorizePrepare': True,
            'scenarioId': scenario, 'project': saved, 'trainees': bundle['trainees'],
            'guests': bundle['guests']})
        draft = response['data']
        if draft.get('verifiedGuest'):
            ProjectRepository(ROOT / 'work/project-backups').upsert_verified_guest(draft['verifiedGuest'])
        return {'stage': 'Project ready to launch' if draft['readyForStart'] else 'Project resolved; launch requirements remain',
                'executionBackend': 'api', 'launchBlocked': not draft['readyForStart'],
                'draft': draft}

    def _start_project(self, job: Job, payload: dict) -> dict:
        from umabot.api_project import project_revision
        bundle = ProjectRepository(ROOT / 'work/project-backups').load()
        saved = next(p for p in bundle['store']['projects'] if p['id'] == bundle['store']['activeProjectId'])
        if payload.get('projectRevision') != project_revision(saved):
            raise ValueError('The active project changed; prepare it again before starting')
        response = self._api_rpc({'type': 'start-project', 'authorizeStart': payload.get('authorizeStart'),
            'launchToken': payload.get('launchToken'), 'projectRevision': payload.get('projectRevision')})
        result = response['data']
        self._api_rpc({'type': 'refresh'})
        return {'stage': 'Independent Training started', 'executionBackend': 'api', **result}

    def _api_rpc(self, control: dict, timeout: float = 40, *, automatic_generation=None) -> dict:
        with self.api_session_io_lock:
            process = self.api_session_process
            if process is None or process.poll() is not None:
                raise RuntimeError('Connect an API session or hand off the official client first')
            if process.stdin is None or process.stdout is None:
                raise RuntimeError('API session channel is unavailable')
            try:
                with self.lock:
                    if automatic_generation is not None:
                        self._require_automatic_pilot(automatic_generation)
                    process.stdin.write(json.dumps(control, separators=(',', ':')) + '\n')
                    process.stdin.flush()
                replies: queue.Queue[str] = queue.Queue(maxsize=1)
                # Retry progress is not the command result. Keep waiting without
                # resending the command, with a hard cap even if progress repeats.
                deadline = time.monotonic() + timeout + 90
                while True:
                    threading.Thread(target=lambda: replies.put(process.stdout.readline()), daemon=True).start()
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        raise queue.Empty()
                    response = json.loads(replies.get(timeout=min(timeout, remaining)))
                    if not isinstance(response, dict):
                        raise ValueError('Invalid local response')
                    if response.get('type') != 'api-retry':
                        break
                    with self.lock:
                        job = self.jobs.get(self.active_job_id)
                        if job:
                            self._event(job, 'account refresh', str(response.get('message') or 'Retrying account refresh'), 0)
            except (OSError, ValueError, queue.Empty):
                process.terminate()
                process.wait(timeout=5)
                with self.lock:
                    self.api_session_state = {'status': 'disconnected'}
                raise RuntimeError('API session stopped after a local IPC failure; the command was not replayed') from None
            with self.lock:
                self.api_session_state.update({key: response[key] for key in
                    ('status', 'screen', 'requestCount', 'sessionValid', 'readOnly', 'training', 'readRoutes', 'accountKey') if key in response})
            if response.get('type') == 'error':
                raise RuntimeError(str(response.get('error') or 'API operation stopped'))
            if response.get('type') != control.get('type'):
                process.terminate()
                raise RuntimeError('API session response did not match the requested command')
            self._ensure_training_followup()
            return response

    def _handoff_client(self, job: Job, payload: dict) -> dict:
        with self.lock:
            if self.api_session_process is not None and self.api_session_process.poll() is None:
                raise RuntimeError('An API session is already connected')
        catalog = CaptureCatalog(ROOT / 'uma_api_capture/captures')
        environment = os.environ.copy()
        environment['UMAPILOT_ALLOW_GAME_SESSION'] = 'YES'
        environment['PYTHONPATH'] = os.pathsep.join([str(ROOT / 'src'), str(ROOT / 'work/tools/python-packages')])
        process = subprocess.Popen([sys.executable, str(ROOT / 'Converter/capture_handoff_worker.py'),
            '--root', str(ROOT), '--session', catalog.directory.name], cwd=ROOT, env=environment,
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            encoding='utf-8', creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        replies: queue.Queue[str] = queue.Queue(maxsize=1)
        threading.Thread(target=lambda: replies.put(process.stdout.readline()), daemon=True).start()
        try:
            ready = json.loads(replies.get(timeout=30))
            if ready.get('type') != 'ready' or ready.get('sessionValid') is not True:
                raise ValueError('Handoff did not establish a valid session')
        except (ValueError, queue.Empty):
            if process.poll() is None:
                process.terminate()
            process.wait(timeout=5)
            # Worker emits a value-free diagnostic, not raw authentication errors.
            diagnostic = ''
            if process.stderr:
                try:
                    details = json.loads(process.stderr.read(8192))
                    name = details.get('exceptionType', '')
                    if isinstance(name, str) and name.isidentifier():
                        diagnostic = f' ({name})'
                except (ValueError, OSError):
                    pass
            raise RuntimeError('Handoff failed' + diagnostic + '; resume the official game and capture a fresh response') from None
        with self.lock:
            self.api_session_process = process
            self.api_session_state = {**ready, 'source': 'official-client-handoff',
                'connectedAt': now(), 'sourceSession': catalog.directory.name}
        threading.Thread(target=self._watch_api_session, args=(process,), daemon=True).start()
        return {'stage': 'Official client handed off to the API', **self.api_session_state}


CONTROLLER = BotController()
atexit.register(CONTROLLER.close_api_session)
ACCOUNT_STORE = AccountProfileStore(ROOT / "work/account-profiles")
STEAM_AUTH = SteamAuthManager(ROOT, ACCOUNT_STORE)
LOCAL_SESSION_TOKEN = secrets.token_urlsafe(32)


class Handler(BaseHTTPRequestHandler):
    server_version = "UmaPilot/0.1"

    def _headers(self, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "http://localhost:3100")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, X-UmaPilot-Session")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()

    def _write(self, body: dict[str, Any], status: int = 200) -> None:
        self._headers(status)
        self.wfile.write(json.dumps(body, ensure_ascii=False).encode("utf-8"))

    def do_OPTIONS(self) -> None:  # noqa: N802
        origin = self.headers.get("Origin")
        if origin not in {None, "http://localhost:3100"}:
            self._write({"error": "Origin not allowed"}, 403)
            return
        self._headers(204)

    def _require_local_session(self) -> bool:
        origin = self.headers.get("Origin")
        token = self.headers.get("X-UmaPilot-Session")
        if origin != "http://localhost:3100" or not secrets.compare_digest(
            token or "", LOCAL_SESSION_TOKEN
        ):
            self._write({"error": "Local dashboard authorization failed"}, 403)
            return False
        return True

    def do_GET(self) -> None:  # noqa: N802
        parsed = urlsplit(self.path)
        path = parsed.path
        if path.startswith('/catalog/'):
            from umabot.data_sync import read_catalog
            try:
                self._write(read_catalog(ROOT, path.removeprefix('/catalog/')))
            except (ValueError, FileNotFoundError):
                self._write({'error': 'Catalog not found'}, 404)
            return
        if path.startswith('/brain/'):
            if not self._require_local_session(): return
            try:
                if path == '/brain/knowledge': self._write(BRAIN_KNOWLEDGE.snapshot())
                elif path == '/brain/status': self._write(BRAIN_KNOWLEDGE.status())
                elif path.startswith('/brain/cache/'): self._write({'value': BRAIN_CACHE.read(path.rsplit('/',1)[1])})
                else: self._write({'error':'Not found'},404)
            except (ValueError,OSError) as exc:
                self._write({'error':str(exc)},503)
            return
        if path in {"/api-state/presets", "/api-state/contracts"}:
            try:
                catalog = CaptureCatalog(ROOT / "uma_api_capture/captures")
                self._write(catalog.presets() if path.endswith("presets") else catalog.contracts())
            except (OSError, ValueError) as exc:
                self._write({"error": str(exc)}, 503)
            return
        if path == '/dashboard/storage':
            if not self._require_local_session():
                return
            try:
                self._write(DashboardStorage(ROOT).read())
            except (ValueError, OSError):
                self._write({'error': 'Local dashboard files could not be read'}, 500)
            return
        if path == "/projects/backup":
            if not self._require_local_session():
                return
            try:
                self._write(ProjectRepository(ROOT / "work/project-backups").load())
            except FileNotFoundError:
                self._write({"error": "No local project backup yet"}, 404)
            return
        if path == "/accounts/session":
            origin = self.headers.get("Origin")
            if origin not in {None, "http://localhost:3100"}:
                self._write({"error": "Origin not allowed"}, 403)
                return
            self._write({"sessionToken": LOCAL_SESSION_TOKEN})
            return
        if path == "/accounts":
            self._write({"accounts": STEAM_AUTH.list_public()})
            return
        if path.startswith("/protocol-lab"):
            try:
                client = CapturedReplayClient(ROOT / "uma_api_capture/captures")
                if path == "/protocol-lab/flow":
                    state: Any = client.flow()
                elif path == "/protocol-lab/contracts":
                    state = client.contracts()
                elif path == "/protocol-lab/replay":
                    query = parse_qs(parsed.query)
                    endpoint = (query.get("endpoint") or [""])[0]
                    if not endpoint:
                        raise ValueError("endpoint query parameter is required")
                    try:
                        ordinal = int((query.get("ordinal") or ["-1"])[0])
                    except ValueError as exc:
                        raise ValueError("ordinal must be an integer") from exc
                    state = client.replay_summary(endpoint, ordinal=ordinal)
                elif path == "/protocol-lab/bootstrap":
                    lookups = LookupCatalog(ROOT / "uma_api_capture/lookups")
                    state = ApiCareerBootstrap(
                        SequentialCapturedReplayClient(client),
                        lookups.indexes["scenarios"],
                    ).run()
                elif path == "/protocol-lab/career-manifest":
                    query = parse_qs(parsed.query)
                    raw_target = (query.get("targetCardId") or [None])[0]
                    target_card_id = int(raw_target) if raw_target else None
                    state = build_career_request_manifest(
                        ROOT / "uma_api_capture/captures",
                        ROOT / "uma_api_capture/lookups",
                        target_card_id=target_card_id,
                    )
                elif path == "/protocol-lab":
                    state = client.summary()
                else:
                    self._write({"error": "Not found"}, 404)
                    return
                self._write(state)
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                self._write({"error": str(exc)}, 503)
            return
        if self.path.startswith("/api-state"):
            try:
                backend = CapturedGameStateBackend(
                    ROOT / "uma_api_capture/captures",
                    ROOT / "uma_api_capture/lookups",
                )
                if self.path == "/api-state/veterans":
                    state = {
                        "mode": "captured-read-only",
                        "records": backend.owned_veterans(),
                    }
                elif self.path == "/api-state/career-choices":
                    state = backend.career_choices()
                    state["mode"] = "captured-read-only"
                elif self.path == "/api-state":
                    state = backend.summary()
                else:
                    self._write({"error": "Not found"}, 404)
                    return
                self._write(state)
            except (OSError, ValueError, json.JSONDecodeError) as exc:
                self._write({"error": str(exc)}, 503)
            return
        if path == '/settings/discord':
            if not self._require_local_session():
                return
            from umabot.discord_notifications import settings
            self._write(settings(ROOT))
            return
        if path == '/settings/refills':
            from umabot.tp_refill import settings
            self._write(settings(ROOT))
            return
        if path == '/settings/training':
            self._write(CONTROLLER.training_watch.settings())
            return
        if path == "/updates/status":
            from umabot.update_status import read_status
            self._write(read_status(ROOT))
            return
        if path == '/diagnostics/pilot-start':
            if not self._require_local_session():
                return
            try:
                self._write(json.loads((ROOT / 'work/diagnostics/last-pilot-start.json').read_text(encoding='utf-8')))
            except (OSError, ValueError):
                self._write({'error': 'No start diagnostic yet. It is recorded when Pilot attempts to start a career.'}, 404)
            return
        if path == "/portable-status":
            from umabot.portable_status import report
            self._write({**report(), 'serviceVersion': SERVICE_VERSION})
            return
        if self.path == "/health":
            self._write(CONTROLLER.status())
            return
        if self.path.startswith("/jobs/"):
            job = CONTROLLER.get(self.path.rsplit("/", 1)[-1])
            if job is None:
                self._write({"error": "Job not found"}, 404)
            else:
                self._write(asdict(job))
            return
        self._write({"error": "Not found"}, 404)

    def do_POST(self) -> None:  # noqa: N802
        parsed = urlsplit(self.path)
        path = parsed.path
        if path.startswith('/brain/') and not self._require_local_session(): return
        is_account_action = path.startswith("/updates/") or path.startswith("/settings/") or path.startswith("/commands/") or path.startswith("/api-session/") or path.startswith("/projects/") or path.startswith("/accounts/") or path.startswith(
            "/game-accounts/"
        )
        if is_account_action and not self._require_local_session():
            return
        length = int(self.headers.get("Content-Length", "0"))
        body_limit = 16 * 1024 * 1024 if path in {"/projects/backup", "/dashboard/storage"} or path.startswith(("/commands/", '/brain/')) else 32_768
        if length < 0 or length > body_limit:
            self._write({"error": "Request body is too large"}, 413)
            return
        try:
            payload = json.loads(self.rfile.read(length) or b"{}")
            if path == '/updates/check':
                from umabot.update_status import request_check
                self._write(request_check(ROOT, force=payload.get('force') is True), 202)
                return
            if path.startswith('/brain/cache/'):
                self._write(BRAIN_CACHE.write(path.rsplit('/',1)[1],payload));return
            if path == '/brain/evidence':
                from umabot.portable_paths import master_database
                self._write(brain_evidence(payload['project'],payload['veterans'],master_database()));return
            if path == '/dashboard/storage':
                try:
                    with CONTROLLER.lock:
                        result = DashboardStorage(ROOT).write(payload, CONTROLLER.save_project_backup)
                    self._write(result)
                except StorageConflict as exc:
                    self._write({'error': str(exc)}, 409)
                return
            if path == '/settings/continuous':
                self._write(CONTROLLER.continuous.configure(payload))
                return
            if path == '/settings/discord':
                from umabot.discord_notifications import settings
                self._write(settings(ROOT, payload))
                return
            if path == '/settings/discord/test':
                from umabot.discord_notifications import test
                self._write(test(ROOT, payload.get('id')))
                return
            if path == '/settings/refills':
                from umabot.tp_refill import settings
                self._write(settings(ROOT, payload))
                return
            if path == '/settings/training':
                self._write(CONTROLLER.training_watch.settings(payload))
                return
            if path.startswith('/api-session/'):
                action = path.rsplit('/', 1)[-1]
                if CONTROLLER.continuous.read()['enabled'] and action in {'connect-client', 'start-project', 'buy-skills', 'finish-career', 'career-presets', 'plan-skills'}:
                    raise ValueError('Stop continuous running before manual career operations')
                if action == 'test-tp-bottle':
                    if CONTROLLER.continuous.read()['enabled'] or CONTROLLER.active_job_id:
                        raise ValueError('Pause continuous running and wait for the active operation before testing a bottle')
                    self._write(CONTROLLER._api_rpc({'type': action, 'authorizeOneBottle': payload.get('authorizeOneBottle') is True}))
                elif action == 'connect-client':
                    self._write(asdict(CONTROLLER.create('handoff-client', {})), 202)
                elif action == 'start-project':
                    self._write(asdict(CONTROLLER.create('start-project', payload)), 202)
                elif action in {'plan-skills', 'buy-skills', 'finish-career'}:
                    bundle = ProjectRepository(ROOT / 'work/project-backups').load()
                    project = next(p for p in bundle['store']['projects'] if p['id'] == bundle['store']['activeProjectId'])
                    self._write(CONTROLLER._api_rpc({'type':action, 'project':project,
                        'authorizeSkillPoints':payload.get('authorizeSkillPoints') is True,
                        'authorizeFinish':payload.get('authorizeFinish') is True}))
                elif action == 'disconnect':
                    if CONTROLLER.continuous.read()['enabled']:
                        CONTROLLER.continuous.configure({'enabled': False})
                    self._write(CONTROLLER.disconnect_account())
                elif action in {'refresh', 'snapshot', 'read-navigation', 'career-presets'}:
                    self._write(CONTROLLER._api_rpc({**payload, 'type': action}))
                else:
                    self._write({'error': 'Not found'}, 404)
                return
            if path == "/projects/backup":
                self._write(CONTROLLER.save_project_backup(payload))
                return
            if path == "/accounts/login":
                value = STEAM_AUTH.start(
                    str(payload.get("label") or "Steam profile"),
                    str(payload.get("accountName") or ""),
                    str(payload.get("password") or ""),
                )
                self._write(value, 202)
                return
            account_parts = path.strip("/").split("/")
            if len(account_parts) == 3 and account_parts[0] == "accounts":
                profile_id, action = account_parts[1], account_parts[2]
                if action == "steam-guard":
                    self._write(STEAM_AUTH.submit_guard(profile_id, str(payload.get("code") or "")))
                    return
                if action == "cancel-login":
                    self._write(STEAM_AUTH.cancel(profile_id))
                    return
                if action == "assignment":
                    self._write(CONTROLLER.assign_account_function(profile_id, str(payload.get("assignedFunction") or "")))
                    return
                if action == "remove":
                    self._write(CONTROLLER.remove_account(profile_id))
                    return
                if action == "verify-connection":
                    job = CONTROLLER.create(
                        "verify-account", {"profileId": profile_id}
                    )
                    self._write(asdict(job), 202)
                    return
                if action == "account-snapshot":
                    self._write(CONTROLLER.api_account_snapshot(profile_id))
                    return
                if action == "disconnect-session":
                    self._write(CONTROLLER.disconnect_account(profile_id))
                    return
                if action == "data-link":
                    game = ACCOUNT_STORE.save_data_link(
                        profile_id,
                        label=str(payload.get("label") or "Game account"),
                        trainer_id=str(payload.get("trainerId") or ""),
                        link_password=str(payload.get("linkPassword") or ""),
                    )
                    self._write(game.public(), 201)
                    return
            if len(account_parts) == 3 and account_parts[0] == "game-accounts":
                game_account_id, action = account_parts[1], account_parts[2]
                if action == "remove":
                    ACCOUNT_STORE.delete_game_account(game_account_id)
                    self._write({"removed": True, "id": game_account_id})
                    return
            command = {
                "/commands/auto": "auto",
                "/commands/review-career": "review-career",
                "/commands/end-career": "end-career",
                "/commands/prepare-project": "prepare-project",
                "/commands/start-project": "start-project",
                "/commands/finish-untracked": "finish-untracked",
                "/commands/sync-data": "sync-data",
            }.get(path)
            if command is None:
                self._write({"error": "Not found"}, 404)
                return
            job = CONTROLLER.create(command, payload)
            self._write(asdict(job), 202)
        except (ValueError, RuntimeError, KeyError) as exc:
            self._write({"error": str(exc)}, 409)

    def log_message(self, _format: str, *_args: Any) -> None:
        return


def main() -> None:
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    BRAIN_KNOWLEDGE.start()
    CONTROLLER.restore_connection()
    print(f"Uma Pilot bot service listening on http://{HOST}:{PORT}", flush=True)
    server.serve_forever()


if __name__ == "__main__":
    main()
