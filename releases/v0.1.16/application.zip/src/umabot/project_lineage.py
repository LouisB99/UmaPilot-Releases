"""Loop recipes and approval evidence tied to actual veteran identities."""
from __future__ import annotations
from copy import deepcopy


def full_roster_parents(role: str, roles: list[str]) -> list[str]:
    if len(roles) == 4 and set(roles) == set('ABCD'):
        return {'A': ['C', 'D'], 'B': ['A', 'D'],
                'C': ['A', 'B'], 'D': ['B', 'C']}[role]
    if role not in roles or len(roles) < 2:
        raise ValueError('Full-roster loop requires an assigned role and at least two members')
    # Preserve the existing generalized recipe for custom roster sizes.
    others = [item for item in roles if item != role]
    index = roles.index(role)
    return [others[index % len(others)], others[(index + 1) % len(others)]]


def pair_step(project: dict) -> int:
    plan = project.get('loopPlan') or {}
    stored = plan.get('pairStep')
    if isinstance(stored, int) and 0 <= stored < 4:
        return stored
    role = (project.get('checkpoint') or {}).get('role')
    if role == 'C': return 0
    if role == 'D': return 2
    closure = plan.get('closureRole') or 'A'
    slot = next((s for s in plan.get('slots', []) if s.get('role') == closure), {})
    return 3 if slot.get('seedCriteriaPassed') else 1


def pair_roles(project: dict, step: int | None = None) -> tuple[str, list[str]]:
    plan = project.get('loopPlan') or {}
    closure = plan.get('closureRole') or 'A'
    anchor = 'A' if closure == 'B' else 'B'
    if step is None and plan.get('pairSeedPending'):
        return anchor, ['C', closure]
    partner = next((slot for slot in plan.get('slots', []) if slot.get('role') == 'D'), {})
    # The anchor seeds the first closure career while D is still unbuilt.
    # Reusing the validated D on later passes preserves the work already done.
    second_parent = 'D' if approved(project, partner.get('approvedVeteranId')) else anchor
    return [('C', ['A', 'B']), (closure, ['C', second_parent]),
            ('D', ['C', closure]), (closure, ['C', 'D'])][pair_step(project) if step is None else step]


def approved(project: dict, veteran_id: object) -> bool:
    record = (project.get('lineageRecords') or {}).get(str(veteran_id)) or {}
    return bool(record.get('approved') is True
                and record.get('criteria') == (project.get('acceptance') or {}))


def schedule_seed_build(project: dict) -> bool:
    """Insert an opted-in repair at a safe career boundary, retaining the resume step.

    Call only when there is no career to collect, or just after recording its result.
    The seed needs approved parents, not already closed two-generation trees.
    """
    plan = project.get('loopPlan') or {}
    if (plan.get('method') != 'pair-closure' or not plan.get('buildSeedParent')
            or plan.get('pairSeedPending') or project.get('status') == 'completed'):
        return False
    closure = plan.get('closureRole') or 'A'
    seed = 'A' if closure == 'B' else 'B'
    slots = {s['role']: s for s in plan.get('slots', [])}
    if approved(project, slots.get(seed, {}).get('approvedVeteranId')):
        return False
    if not all(approved(project, slots.get(r, {}).get('approvedVeteranId')) for r in ('C', closure)):
        return False
    plan['pairStep'] = pair_step(project)
    plan['pairSeedPending'] = True
    plan['currentSlot'] = next(i for i, s in enumerate(plan['slots']) if s['role'] == seed)
    project['checkpoint'].update(role=seed, phase='Build missing seed parent',
        nextStep=f"Build slot {seed} using C + {closure}; then resume pair-closure step {plan['pairStep'] + 1}/4")
    return True


def closed_lineage(project: dict, veteran_id: object, depth: int = 2) -> bool:
    """Require approval of this specific veteran, both parents and four grandparents."""
    if not approved(project, veteran_id): return False
    if depth == 0: return True
    record = project['lineageRecords'][str(veteran_id)]
    parents = record.get('parentIds') or []
    return len(parents) == 2 and all(closed_lineage(project, p, depth - 1) for p in parents)


def record_veteran(project: dict, veteran: dict, passed: bool, role: str) -> None:
    veteran_id = str(veteran['trained_chara_id'])
    project.setdefault('lineageRecords', {})[veteran_id] = {
        'veteranId': veteran_id, 'cardId': veteran.get('card_id'), 'role': role,
        'approved': passed, 'criteria': deepcopy(project.get('acceptance') or {}),
        'parentIds': [str(veteran.get(f'succession_trained_chara_id_{index}') or '') for index in (1, 2)],
    }
    if passed:
        slot = next(s for s in project['loopPlan']['slots'] if s['role'] == role)
        slot['approvedVeteranId'] = veteran_id
