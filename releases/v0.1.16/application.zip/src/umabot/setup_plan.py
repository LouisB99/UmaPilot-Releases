from __future__ import annotations

from typing import Any
from umabot.project_lineage import pair_roles, full_roster_parents, approved
from umabot.advanced_loop import PAIR_METHODS, preparing


def _base_id(value: Any) -> int:
    try:
        number = int(value or 0)
    except (TypeError, ValueError):
        return 0
    return number // 100 if number >= 10000 else number


def borrow_candidates(analysis, guests):
    # A saved guest remains useful when the shortlist is stale or was rebuilt.
    # Live availability is always verified by prepare_guest before launch.
    rows = {}
    for item in [*(analysis.get('borrows') or []), *guests]:
        key = (str(item.get('trainerId') or ''), _base_id(item.get('umaCardId')))
        if key[0] and key[1] and item.get('status') != 'unavailable':
            rows.setdefault(key, item)
    return list(rows.values())


def _borrow_decision(
    parents: list[dict[str, Any]],
    analysis: dict[str, Any],
    guests: list[dict[str, Any]],
    excluded_roles=(),
) -> dict[str, Any] | None:
    recommendations = borrow_candidates(analysis, guests)
    fits = analysis.get("veteranFits") or []
    if len(parents) != 2 or not recommendations:
        return None

    parent_scores = []
    for parent in parents:
        base_id = _base_id(parent.get("baseId"))
        matching = [
            fit for fit in fits
            if _base_id(fit.get("baseId")) == base_id
            or (not fit.get("baseId") and fit.get("name") == parent.get("name"))
        ]
        parent_scores.append({
            "role": parent.get("role"),
            "baseId": base_id,
            "name": parent.get("name"),
            "projectScore": max((float(fit.get("score") or 0) for fit in matching), default=0),
        })

    # min() is stable, so an exact tie consistently borrows the first parent.
    eligible = [score for score, parent in zip(parent_scores, parents)
                if not parent.get('approvedVeteranId') and parent.get('role') not in excluded_roles
                and any(_base_id(item.get('umaCardId')) == score['baseId'] for item in recommendations)]
    if not eligible:
        return None
    weakest = min(eligible, key=lambda item: item["projectScore"])
    candidates = [
        item for item in recommendations
        if _base_id(item.get("umaCardId")) == weakest["baseId"]
    ]
    if not candidates:
        return None
    candidates.sort(key=lambda item: float(item.get("totalScore") or 0), reverse=True)

    known_ids = {
        str(guest.get("trainerId")) for guest in guests
        if guest.get("status") != "unavailable"
    }
    known = next(
        (item for item in candidates if str(item.get("trainerId")) in known_ids),
        None,
    )
    selected = known or candidates[0]
    trainer_id = str(selected.get("trainerId") or "")
    known_guest = next(
        (guest for guest in guests if str(guest.get("trainerId")) == trainer_id),
        None,
    )
    game_rank_score = int(
        selected.get("gameRankScore")
        or (known_guest or {}).get("gameRankScore")
        or 0
    )
    return {
        "parentRole": weakest["role"],
        "parentBaseId": weakest["baseId"],
        "parentName": weakest["name"],
        "ownedParentScores": parent_scores,
        "trainerId": trainer_id,
        "trainerName": selected.get("trainerName"),
        "umaCardId": selected.get("umaCardId"),
        "umaName": selected.get("umaName"),
        "guestScore": float(selected.get("totalScore") or 0),
        "totalScore": float(selected.get("totalScore") or 0),
        "affinityScore": float(selected.get("affinityScore") or 0),
        "whiteScore": float(selected.get("whiteScore") or 0),
        "aptitudeScore": float(selected.get("aptitudeScore") or 0),
        "winCount": int(selected.get("winCount") or 0),
        "followerCount": selected.get("followerCount"),
        "matchedWhites": selected.get("matchedWhites") or [],
        "blueSparks": selected.get("blueSparks") or [],
        "pinkSparks": selected.get("pinkSparks") or [],
        "lastUpdated": selected.get("lastUpdated"),
        "gameRankScore": game_rank_score,
        "alreadyKnown": trainer_id in known_ids,
        "action": "use-known-guest" if trainer_id in known_ids else "follow-and-use",
    }


def build_setup_plan(
    project: dict[str, Any],
    trainees: list[dict[str, Any]],
    guests: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    guests = guests or []
    loop_plan = project.get("loopPlan") or {}
    slots = loop_plan.get("slots") or []
    if not slots:
        raise ValueError("The project has no linked loop slots.")
    checkpoint = project.get("checkpoint") or {}
    role = str(
        checkpoint.get("role")
        or slots[int(loop_plan.get("currentSlot") or 0)].get("role")
        or "A"
    )
    target_slot = next((slot for slot in slots if slot.get("role") == role), None)
    if not target_slot or not target_slot.get("traineeId"):
        raise ValueError(f"Loop slot {role} has no trainee assigned.")
    trainee = next(
        (item for item in trainees if item.get("id") == target_slot.get("traineeId")),
        None,
    )
    if not trainee:
        raise ValueError(f"The trainee assigned to slot {role} is not in the owned roster.")
    method = loop_plan.get("method") or "full-roster"
    closure = loop_plan.get("closureRole") or "A"
    preparation = preparing(project)
    advanced_closure = method == 'advanced-pair-closure' and not preparation
    if method in PAIR_METHODS and not preparation:
        expected_role, parents = pair_roles(project)
        if role != expected_role:
            raise ValueError("Pair-loop phase differs from the saved checkpoint")
    else:
        parents = full_roster_parents(role, [str(slot.get("role")) for slot in slots])
    parent_specs = []
    for parent_role in parents:
        parent_slot = next(
            (slot for slot in slots if str(slot.get("role")) == parent_role),
            None,
        )
        if not parent_slot or not parent_slot.get("traineeId"):
            raise ValueError(f"Parent slot {parent_role} has no trainee assigned.")
        parent = next(
            (item for item in trainees if item.get("id") == parent_slot.get("traineeId")),
            None,
        )
        if not parent:
            raise ValueError(
                f"The trainee assigned to parent slot {parent_role} is not in the owned roster."
            )
        parent_specs.append({
            "role": parent_role,
            "approvedVeteranId": parent_slot.get("approvedVeteranId") if not preparation and approved(project, parent_slot.get("approvedVeteranId")) else None,
            "preferredVeteranId": parent_slot.get("approvedVeteranId") if preparation and approved(project, parent_slot.get("approvedVeteranId")) else None,
            "traineeId": parent.get("id"),
            "baseId": parent.get("baseId"),
            "cardId": parent.get("cardId"),
            "name": parent.get("name"),
            "outfit": parent.get("outfit"),
        })
    run_options = project.get("runOptions") or {}
    allow_borrowed = bool(
        run_options.get("allowBorrowedLegacies")
        or (project.get("borrowSearch") or {}).get("enabled")
    )
    if advanced_closure:
        if not all(approved(project, s.get('approvedVeteranId')) for s in slots):
            raise ValueError('Advanced preparation is no longer valid; refresh the four owned members before closure')
        allow_borrowed = False
    analysis = project.get("analysis") or {}
    recommendations = (analysis.get("borrows") or []) if allow_borrowed else []
    borrow_decision = (
        _borrow_decision(parent_specs, analysis, guests) if allow_borrowed else None
    )
    return {
        "projectId": project.get("id"),
        "loopPhase": 'preparation' if preparation else 'closure' if method in PAIR_METHODS else 'full-roster',
        "targetRole": role,
        "targetTraineeId": trainee.get("id"),
        "targetBaseId": trainee.get("baseId"),
        "targetCardId": trainee.get("cardId"),
        "targetName": trainee.get("name"),
        "targetOutfit": trainee.get("outfit"),
        "parentRoles": parents,
        "parents": parent_specs,
        "trainingFocus": run_options.get("trainingFocus"),
        "supportDeckId": run_options.get("supportDeckId"),
        "agendaId": run_options.get("agendaId"),
        "agenda": run_options.get("agenda"),
        "scenario": run_options.get("scenario") or "Grand Concert",
        "legacySticker": run_options.get("legacySticker") or "carrot",
        "applyStickerOnAdvance": True,
        "borrowedSupportId": run_options.get("borrowedSupportId") or 30052,
        "borrowedSupportName": (
            run_options.get("borrowedSupportName") or "[From the Ground Up] Light Hello"
        ),
        "allowBorrowedLegacies": allow_borrowed,
        "borrowRecommendations": recommendations,
        "knownGuests": guests if allow_borrowed else [],
        "borrowDecision": borrow_decision,
        "seedStage": int(checkpoint.get("completedCareers") or 0) == 0,
    }
